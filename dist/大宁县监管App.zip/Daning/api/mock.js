/*
本地模拟接口请求, 仅demo演示用.
实际项目以您服务器接口返回的数据为准,无需本地处理分页.
请参考官方写法: http://www.mescroll.com/uni.html?v=20200210#tagUpCallback
* */

import api from "@/api/api.js";
// 模拟数据
// 搜索商品
export function apiSearch(pageNum, pageSize, data, keyword) {
	return new Promise((resolute, reject) => {
		//延时一秒,模拟联网
		setTimeout(() => {
			try {
				api.getFromlist(data, (res) => {
					var curPageData;
					if (res.code && res.code == "100001") {
						curPageData = []
					} else {
						curPageData = res;
					}
					// 模拟搜索
					let list = []
					if (!keyword || keyword == "全部") {
						// 模拟搜索全部商品
						for (let i = (pageNum - 1) * pageSize; i < pageNum * pageSize; i++) {
							if (i === curPageData.length) break
							list.push(curPageData[i])
						}
					} else {
						// 模拟关键词搜索
						if (keyword == "母婴") keyword = "婴"; // 为这个关键词展示多几条数据
						for (let i = 0; i < curPageData.length; i++) {
							if (curPageData[i].pdName.indexOf(keyword) !== -1) {
								list.push(curPageData[i])
							}
						}
					}
					//模拟接口请求成功
					console.log("page.num=" + pageNum + ", page.size=" + pageSize + ", curPageData.length=" + list.length +
						", keyword=" + keyword);
					resolute(list);

				});

			} catch (e) {
				//模拟接口请求失败
				reject(e);
			}
		}, 1000)
	})
}
//行政执法历史记录
export function apiHistory(pageNum, pageSize, data, keyword) {
	return new Promise((resolute, reject) => {
		//延时一秒,模拟联网
		setTimeout(() => {
			try {
				api.getFromlistA(data, (res) => {
					var curPageData;
					if (res.code && res.code == "100001") {
						curPageData = []
					} else {
						curPageData = res;
					}
					resolute(curPageData);

				});
			} catch (e) {
				//模拟接口请求失败
				reject(e);
			}
		}, 1000)
	})
}



export function apiNotice(pageNum, pageSize, name, keyword) {
	var url;
	if (keyword == '新闻') {
		url = 'http://h5.shouyunchina.com:8002/DNServices/getNewsListServlet'
	} else if (keyword == '公告') {
		url = 'http://h5.shouyunchina.com:8002/DNServices/getAnnounceServlet'
	}
	return new Promise((resolute, reject) => {
		//延时一秒,模拟联网
		setTimeout(() => {
			try {
				uni.request({
					url: url,
					method: "POST",
					data: name,
					success: (res) => {
						let curPageData = res.data;
						// 模拟搜索
						let list = []
						if (!keyword || keyword == "全部") {
							console.log(2)
							// 模拟搜索全部商品
							for (let i = (pageNum - 1) * pageSize; i < pageNum * pageSize; i++) {
								if (i === curPageData.length) break
								list.push(curPageData[i])
							}
						} else {
							// 模拟关键词搜索
							console.log(222)
							if (keyword == "母婴") keyword = "婴"; // 为这个关键词展示多几条数据
							for (let i = 0; i < curPageData.length; i++) {
								if (curPageData[i].TITLE.indexOf(keyword) !== -1) {
									list.push(curPageData[i])
								}
							}
						}

						//模拟接口请求成功
						console.log("page.num=" + pageNum + ", page.size=" + pageSize + ", curPageData.length=" + list.length +
							", keyword=" + keyword);
						resolute(curPageData);
					},
				})

			} catch (e) {
				//模拟接口请求失败
				reject(e);
			}
		}, 1000)
	})
}



// 新闻公告
export function apiCoor(pageNum, pageSize, id, keyword) {
	return new Promise((resolute, reject) => {
		//延时一秒,模拟联网
		setTimeout(() => {
			try {
				uni.request({
					url: 'http://h5.shouyunchina.com:8002/DNServices/colSummaryServlet',
					data: {
						pageIndex: pageNum,
						pageSize: pageSize,
						app: 1,
						state: keyword,
						memberID: id,
						isDelete: 0
					},
					success: (res) => {
						let curPageData = res.data.data;
						//模拟接口请求成功
						console.log("page.num=" + pageNum + ", page.size=" + pageSize + ", curPageData.length=" + curPageData.length +
							", keyword=" + keyword);
						resolute(curPageData);
					},
				})

			} catch (e) {
				//模拟接口请求失败
				reject(e);
			}
		}, 1000)
	})
}


// 新闻公告
export function Cooritem(pageNum, pageSize, id, keyword) {
	return new Promise((resolute, reject) => {
		//延时一秒,模拟联网
		setTimeout(() => {
			try {
				uni.request({
					url: 'http://h5.shouyunchina.com:8002/DNServices/transferDetailsServlet',
					data: {
						type: keyword,
						processID: '-8891269070812328096',
					},
					success: (res) => {
						console.log(res)
						let curPageData = res.data.data;
						//模拟接口请求成功
						resolute(curPageData);
					},
				})

			} catch (e) {
				//模拟接口请求失败
				reject(e);
			}
		}, 1000)
	})
}




// 新闻公告
export function apiCanvas(keyword, data) {
	return new Promise((resolute, reject) => {
		//延时一秒,模拟联网
		setTimeout(() => {
			try {
				var url;
				if (keyword == '1') {
					url = 'http://183.203.90.25:8001/daning/lawdatacount?area=5193833739236756707'
				}

				uni.request({
					url: url,
					data: data,
					success: (res) => {
						console.log(res)
						let curPageData = res.data.data;
						resolute(curPageData);
					},
				})

			} catch (e) {
				//模拟接口请求失败
				reject(e);
			}
		}, 1000)
	})
}
