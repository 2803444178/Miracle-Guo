//token获取
const apiUrl = "http://183.203.90.25:8002/v1/seeyon";
// 首页统计分类
let indexStatistics = function(type, levelID, sCallback) {
	uni.request({
		url: "http://h5.shouyunchina.com:8002/DNServices/homePageServlet",
		data: {
			type: type,
			levelID: levelID
		},
		success: (res) => {
			if (res) {
				sCallback && sCallback(res.data)
			}
		},
		fail: (err) => {
			console.log(err)
		}
	});
}


let GetNowtoken = function(name, sCallback) {
	uni.showLoading({
		title: "加载中"
	})
	uni.request({
		url: "http://183.203.90.25:8002/v1/seeyon/token",
		method: "POST",
		data: {
			loginName: name
		},
		success: (res) => {
			if (res && res.data) {
				let id = res.data.id;
				sCallback && sCallback(id)
			}
		},
		fail: (err) => {
			console.log(err)
		}
	});
}

let getToken = function(url, dataobj, type, sCallback) {
	uni.request({
		url: url,
		method: type,
		header: {
			'content-type': 'application/json' //自定义请求头信息
		},
		data: dataobj,
		success: (res) => {
			sCallback && sCallback(res.data)
		},
		fail: (err) => {
			console.log(err)
		}
	});
}

// 获取档案列表
let getArchives = function(dataobj, sCallback, eCallback) {
	uni.request({
		url: "http://h5.shouyunchina.com:8002/DNServices/getEntListServlet",
		method: "GET",
		data: dataobj,
		success: (res) => {
			sCallback && sCallback(res.data)
		},
		fail: (err) => {
			coensole.log(err)
			eCallback && eCallback(res.data)
		}
	});
}

// 获取案件来源列表
let getFromlist = function(dataobj, sCallback, eCallback) {
	uni.request({
		url: "http://h5.shouyunchina.com:8002/DNServices/enforceRecordServlet",
		method: "GET",
		data: dataobj,
		success: (res) => {
			sCallback && sCallback(res.data)
		},
		fail: (err) => {
			coensole.log(err)
			eCallback && eCallback(res.data)
		}
	});
}

// 获取案件来源相关联的列表记录
let getFromlistA = function(dataobj, sCallback, eCallback) {
	console.log(dataobj)
	uni.request({
		url: "http://h5.shouyunchina.com:8002/DNServices/caseSourceServlet",
		method: "GET",
		data: dataobj,
		success: (res) => {
			sCallback && sCallback(res.data)
		},
		fail: (err) => {
			coensole.log(err)
			eCallback && eCallback(res.data)
		}
	});
}

// 获取案件来源信息
let getFrominfo = function(id, sCallback, eCallback) {
	uni.request({
		url: "http://h5.shouyunchina.com:8002/DNServices/businessInfoServlet",
		method: "GET",
		data: {
			id: id
		},
		success: (res) => {
			sCallback && sCallback(res.data)
		},
		fail: (err) => {
			coensole.log(err)
			eCallback && eCallback(res.data)
		}
	});
}




//企业信息等接口
const apiUrle = "http://h5.shouyunchina.com:8002/DNServices";
/* 模板获取 */
let getFormdata = function(key, templateCode, senderLoginName, sCallback, eCallback) {
	//从本地获取数据，如果无在请求
	try {
		// 先获取上次编辑的状态有木有完成;
		const lastvalue = uni.getStorageSync(key);
		if (lastvalue) {
			uni.hideLoading();
			let {
				data: {
					values: values
				}
			} = lastvalue;
			let fields = [];
			if (values) {
				values.forEach((row, i) => {
					fields[row.name] = values[i];
				})
			}
			console.log('-----------')
			console.log(lastvalue)
			sCallback && sCallback(lastvalue, fields)
		} else {
			const value = uni.getStorageSync(templateCode);
			if (value) {
				console.log(value)
				uni.hideLoading();
				let {
					data: {
						values: values
					}
				} = value;
				let fields = [];
				if (values) {
					values.forEach((row, i) => {
						fields[row.name] = values[i];
						fields[row.name].value = '';
					})
				}
				sCallback && sCallback(value, fields)
			} else {
				uni.request({
					url: "http://h5.shouyunchina.com:8002/DNServices/dealBlankTableServlet",
					method: "GET",
					data: {
						templateCode: templateCode,
						senderLoginName: senderLoginName
					},
					success: (res) => {
						console.log(res)
						if (res) {
							uni.hideLoading();
							uni.setStorage({
								key: templateCode,
								data: res.data,
								success: function() {
									console.log('success');
								}
							});
							let {
								data: {
									values: values
								}
							} = res.data;
							let fields = [];
							if (values) {
								values.forEach((row, i) => {
									fields[row.name] = values[i];
									fields[row.name].value = '';
								})
							}
							sCallback && sCallback(res.data, fields)
						}

					},
					fail: (err) => {
						uni.showToast({
							title: "加载超时，请重试"
						})
						console.log(err)
						eCallback && eCallback(res.data)
					}
				});
			}
		}

	} catch (e) {
		// error
	}
}


/* 模板详情流程 */
let getFormscree = function(id, recordId, sCallback, eCallback) {
	uni.showLoading({
		title: "加载中"
	})
	uni.request({
		url: "http://h5.shouyunchina.com:8002/DNServices/businessInfoServlet",
		method: "GET",
		data: {
			recordId: recordId,
			id: id
		},
		success: async (res) => {
			if (res) {
				uni.hideLoading()
				let {
					data: {
						values: values
					}
				} = res;
				sCallback && sCallback(res.data)
			}
		},
		fail: (err) => {
			console.log(err)
			eCallback && eCallback(res.data)
		}
	});
}

/*表单模板发起流程 */
let postFormdata = function(data, sCallback, eCallback) {
	uni.showModal({
		title: '提示',
		content: '提交后不可修改，请确认信息!',
		success: function(res) {
			if (res.confirm) {
				uni.showLoading({
					title: "提交中"
				})
				uni.request({
					url: "http://h5.shouyunchina.com:8002/DNServices/startFlowsServlet",
					method: "POST",
					data: data,
					success: (res) => {
						sCallback && sCallback(res.data)
					},
					fail: (err) => {
						console.log(err)
						eCallback && eCallback(res.data)
					}
				});
			} else if (res.cancel) {
				console.log('用户点击取消');
			}
		}
	});
}

/* 签名上传 */
let Getsign = function(dataobj, name, url, token, getdata) {
	uni.uploadFile({
		url: 'http://183.203.90.25:8888/seeyon/rest/attachment?token=' + token +
			'&applicationCategory=0&extensions=&firstSave=true', //仅为示例，非真实的接口地址
		filePath: url,
		name: 'file',
		success: (res) => {
			let obj = JSON.parse(res.data);
			if (res.statusCode == 200 && res.statusCode) {
				uni.showToast({
					title: "签名成功",
					icon: "none"
				})
				dataobj.attachments.push(obj.atts[0].fileUrl + '');
				for (let i in dataobj.data.values) {
					if (dataobj.data.values[i].name == name) {
						dataobj.data.values[i].value = obj.atts[0].fileUrl + '';
					}
				}
				getdata(dataobj);
			} else {
				uni.showToast({
					title: "签名上传失败",
					icon: "none"
				})
			}
		}
	});
}


// 返回对应的表页面名称
let screen = function(fromname, dataname) {
	if (fromname.includes('现场检查笔录') == true) {
		dataname('201917', '201917l')
	}
	if (fromname.includes('立案') == true) {
		dataname('201919', '201919l')
	} else if (fromname.includes('当事人送达地址确认书') == true) {
		dataname('xzzf09', 'xzzf09l')
	} else if (fromname.includes('询问通知书') == true) {
		dataname('xzzf10', 'xzzf10l')
	} else if (fromname.includes('询问调查笔录') == true) {
		dataname('xzzf11', 'xzzf11l')
	} else if (fromname.includes('解除先行登记保存证据通知书') == true) {
		dataname('xzzf16', 'xzzf16l')
	} else if (fromname.includes('先行登记保存证据通知书') == true) {
		dataname('xzzf15', 'xzzf15l')
	} else if (fromname.includes('施行强制措施决定书') == true) {
		dataname('xzzf17', 'xzzf17l')
	} else if (fromname.includes('延长行政强制措施期限决定书') == true) {
		dataname('xzzf18', 'xzzf18l')
	} else if (fromname.includes('解除行政强制措施决定书') == true) {
		dataname('xzzf19', 'xzzf19l')
	} else if (fromname.includes('场所设施财物清单') == true) {
		dataname('xzzf20', 'xzzf20l')
	} else if (fromname.includes('抽样记录') == true) {
		dataname('xzzf21', 'xzzf21l')
	} else if (fromname.includes('责令改正通知书') == true) {
		dataname('201918', '201918l')
	} else if (fromname.includes('责令退款通知书') == true) {
		dataname('xzzf26', 'xzzf26l')
	} else if (fromname.includes('当场行政处罚决定书') == true) {
		dataname('xzzf34', 'xzzf34l')
	} else if (fromname.includes('送达回证') == true) {
		dataname('xzzf39', 'xzzf39l')
	}
}


let getassignment = function(data, sCallback, eCallback) {
	uni.request({
		url: "http://h5.shouyunchina.com:8002/DNServices/dealBlankTableServlet",
		data: data,
		success: (res) => {
			sCallback && sCallback(res.data)
		},
		fail: (err) => {
			eCallback && eCallback(err)
		}
	});
}
/* 行政执法表之间的逻辑关系 */
let relation = {
	'xzzf10': [{
		from: '企业ID',
		to: '企业ID'
	}, {
		from: '案件来源登记号',
		to: '登记号'
	}, {
		from: '市场监管局名称',
		to: '当事人姓名'
	}],
	'xzzf18': [{
		from: '企业ID',
		to: '企业ID'
	}, {
		from: '案件来源登记号',
		to: '登记号'
	}, {
		from: '市场监管局名称',
		to: '当事人姓名'
	}],
	'xzzf20': [{
		from: '企业ID',
		to: '企业ID'
	}, {
		from: '案件来源登记号',
		to: '登记号'
	}],
	'xzzf19': [{
		from: '企业ID',
		to: '企业ID'
	}, {
		from: '案件来源登记号',
		to: '登记号'
	}, {
		from: '市场监管局名称',
		to: '当事人姓名'
	}],
	'xzzf11': [{
		from: '企业ID',
		to: '企业ID'
	}, {
		from: '案件来源登记号',
		to: '登记号'
	}],
	'xzzf15': [{
		from: '企业ID',
		to: '企业ID'
	}, {
		from: '案件来源登记号',
		to: '登记号'
	}],
	'xzzf16': [{
		from: '被通知单位',
		to: '当事人姓名'
	}, {
		from: '企业ID',
		to: '企业ID'
	}, {
		from: '案件来源登记号',
		to: '登记号'
	}],
	'201918': [{
		from: '单位名称',
		to: '当事人姓名'
	}, {
		from: '企业ID',
		to: '企业ID'
	}, {
		from: '案件来源登记号',
		to: '登记号'
	}],
	'xzzf26': [{
		from: '单位名称',
		to: '当事人姓名'
	}, {
		from: '企业ID',
		to: '企业ID'
	}, {
		from: '案件来源登记号',
		to: '登记号'
	}],
	'xzzf34': [{
		from: '受送达人',
		to: '当事人姓名'
	}, {
		from: '送达地点',
		to: '当事人住所'
	}, {
		from: '企业ID',
		to: '企业ID'
	}, {
		from: '案件来源登记号',
		to: '登记号'
	}],
	'xzzf17': [{
		from: '当事人',
		to: '当事人姓名'
	}, {
		from: '住所',
		to: '当事人住所'
	}, {
		from: '联系电话',
		to: '当事人联系电话'
	}, {
		from: '其他联系地址',
		to: '当事人其他联系方式'
	}, {
		from: '企业ID',
		to: '企业ID'
	}, {
		from: '案件来源登记号',
		to: '登记号'
	}],
	'xzzf34': [{
		from: '当事人',
		to: '当事人姓名'
	}, {
		from: '住所',
		to: '当事人住所'
	}, {
		from: '联系电话',
		to: '当事人联系电话'
	}, {
		from: '其他联系地址',
		to: '当事人其他联系方式'
	}, {
		from: '企业ID',
		to: '企业ID'
	}, {
		from: '案件来源登记号',
		to: '登记号'
	}],
	'xzzf21': [{
		from: '当事人',
		to: '当事人姓名'
	}, {
		from: '住所',
		to: '当事人住所'
	}, {
		from: '联系电话',
		to: '当事人联系电话'
	}, {
		from: '其他联系方式',
		to: '当事人其他联系方式'
	}, {
		from: '企业ID',
		to: '企业ID'
	}, {
		from: '案件来源登记号',
		to: '登记号'
	}],
	'201919': [{
		from: '企业ID',
		to: '企业ID'
	}, {
		from: '案件来源登记号',
		to: '登记号'
	}, {
		from: '住所',
		to: '当事人住所'
	}],
	'201917': [{
			from: '当事人1',
			to: '当事人姓名'
		}, {
			from: '住所',
			to: '当事人住所'
		}, {
			from: '联系电话',
			to: '当事人联系电话'
		}, {
			from: '其他联系方式',
			to: '当事人其他联系方式'
		},
		{
			from: '企业ID',
			to: '企业ID'
		},
		{
			from: '案件来源登记号',
			to: '登记号'
		}
	],
	'xzzf09': [{
			from: '收件人',
			to: '当事人姓名'
		}, {
			from: '送达地址',
			to: '当事人住所'
		}, {
			from: '收件人联系电话',
			to: '当事人联系电话'
		},
		{
			from: '企业ID',
			to: '企业ID'
		},
		{
			from: '案件来源登记号',
			to: '登记号'
		}
	]
}

let initFields = function(fields, relatedForm, templateName) {
	if (relation[templateName]) {
		relation[templateName].forEach(row => {
			console.log(fields[row['from']])
			if (relatedForm[row['to']]) {
				console.log(fields[row['from']])
				fields[row['from']].value = relatedForm[row['to']]
			}
		})
	}
	return fields
}



// 数据导出
export default {
	getToken,
	apiUrl,
	apiUrle,
	getassignment,
	getFormdata, //获取模板
	postFormdata,
	Getsign,
	getArchives,
	getFromlist,
	GetNowtoken,
	indexStatistics,
	getFromlistA,
	getFrominfo,
	screen,
	getFormscree,
	initFields, // 初始化表单API
}
