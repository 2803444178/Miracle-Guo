<template>
	<view class="content" style="padding: 0 20upx;">
		<view v-for="(item,index) in list" :key="index" @tap="godetails(item.PROCESS_ID)" class="filelist"
		 hover-class="filelist--hover">
			<view class="name">
				{{item.SUBJECT}}
			</view>
			<view class="time">
				{{item.CREATE_DATE}}
			</view>
		</view>
	</view>
</template>

<script>
	export default {
		props: {
			list: {
				type: Array,
				default () {
					return []
				}
			}
		},
		methods: {
			godetails: function(id,) {
				uni.navigateTo({
					url: "Coordetail?id=" + id  + ""
				})
			},
		}
	}
</script>

<style>
	.filelist {
		display: flex;
		font-size: 28upx;
		justify-content: space-between;
		align-items: center;
		padding: 20upx 0;
	}

	.filelist--hover {
		background-color: #f1f1f1;
	}

	.name {
		width: 72%;
	}

	.time {
		flex: 1;
		text-align: center;
	}


	.commonbtn {
		width: 440upx;
		height: 65upx;
		line-height: 65upx;
		margin-top: 70upx;
		background: #4b559d;
		font-size: 30upx;
	}
</style>
