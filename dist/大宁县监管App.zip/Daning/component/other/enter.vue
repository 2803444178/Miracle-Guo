<template>
	<view class="itembox">
		<view v-for="(item,index) in list" :key="index">
			<view class="itemli" @tap="godetail(item)">
				<view class="itemtitle">
					<text v-if="item.qylx == '食品销售'" class="xiao">销</text>
					<text v-else-if="item.qylx == '餐饮服务'" class="can">餐</text>
					<text v-else class="sheng">生</text>
					{{item.qyname}}
				</view>
				<view class="itemliembox">
					
					<view class="itemliem">
						联系电话：{{item.frtel? item.frtel : '无'}}
					</view>
					<view class="itemliem">
						企业地址：{{item.qydz? item.qydz: '无'}}
					</view>
				
				</view>
				<view class="itembottom">
					<text>建档时间：{{item.cdate? item.cdate.replace(/.........[0-9]*$/,'') : '无'}}</text>
					<text>详情></text>
				</view>
			</view>
		</view>
	</view>
</template>

<script>
	import commonInfo from "../../common/common.js";
	export default {
		props: {
			list: { // 数据列表
				type: Array,
				default () {
					return []
				}
			},
			foodtype: { // 数据列表
				type: String,
				default () {
					return []
				}
			}
		},
		methods: {
			godetail: function(item) {
				commonInfo.userinfo.qyinfo = item;
				uni.navigateTo({
					url: "/pages/Enterprise/Filedetails/Filedetails?item=" + JSON.stringify(item) + ""
				})
			}
		}
	}
</script>

<style>
	.itembox {
		padding: 10upx 0 40upx;
		background: #fff;
	}

	.itemli {
		width: 700upx;
		margin: 0 auto;
		border-radius: 20upx;
		margin-bottom: 40upx;
		box-shadow: 0px 0px 4px #c0c0c0;;
	}

	.itemtitle {
		font-weight: 600;
		color: #333;
		height: 70upx;
		padding: 10upx 20upx;
		font-size: 28upx;
	}

	.itemtitle text {
		color: #FFFFFF;

		width: 50upx;
		height: 50upx;
		font-size: 28upx;
		display: inline-block;
		text-align: center;
		line-height: 50upx;
		border-radius: 50%;
		margin-right: 10upx;
	}

	.itemtitle .xiao {
		background: #b296eb;
	}

	.itemtitle .sheng {
		background: #699ee2;
	}

	.itemtitle .can {
		background: #74d7a9;
	}

	.itemliembox {
		padding: 10upx 20upx;
		border-bottom: 1px solid #dfdfdf;
		border-top: 1px solid #dfdfdf;
	}

	.itemliem {
		color: #333;
		font-size: 24upx;
		padding: 8upx 0;
	}

	.itembottom {
		padding: 14upx 20upx;
		font-size: 24upx;
		color: #7c7c7c;
		display: flex;
		justify-content: space-between;
		align-items: center;
	}
</style>
