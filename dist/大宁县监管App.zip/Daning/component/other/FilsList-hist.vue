<template>
	<view>
		<view v-for="(item,index) in list" :key="index" class="filelist" hover-class="filelist--hover">
			<view class="name">
				{{item.SUBJECT}}
			</view>
			<view class="state">
				检查进度：{{item.STATE}}
				<text class="statebtn" @tap="details(item.SUBJECT,item.ID,item.FORM_RECORDID)">查看详情</text>
			</view>
		</view>
	</view>
</template>

<script>
	import commonInfo from "@/common/common.js"
	import api from "@/api/api.js"
	export default {
		props: {
			list: {
				type: Array,
				default () {
					return []
				}
			}
		},
		methods: {
			details: function(name, id, recordId) {
				let value = name.replace(/[^\u4e00-\u9fa5|,]+/, '');;
				console.log(value)
				api.screen(value, (res, resi) => {
					console.log(res)
					if (res) {
						uni.navigateTo({
							url: "" + res + "/" + resi + "?id=" + id + "&&name=" + value + "&&recordId=" + recordId + ""
						})
					}
				});
			},
		}
	}
</script>

<style>
	.filelist {
		font-size: 28upx;
		padding: 20upx 40upx;
		position: relative;
		margin-bottom: 20upx;
		background: #fff;
		border-radius: 10upx;
		border: 1px #d6d6d6 solid;
	}

	.filelist--hover {
		background-color: #f1f1f1;
	}

	.iconfont {
		width: 50upx;
		height: 100%;
		font-size: 46upx;
		color: #4b559d;
		position: absolute;
		right: 0;
		top: 0;
		display: flex;
		align-items: center;
		justify-content: center;
	}

	.name {
		line-height: 50upx;
		margin-bottom: 10upx;
	}

	.state {
		text-align: left;
		position: relative;
		line-height: 50upx;
		flex: 1;
	}

	.statebtn {
		padding: 0 10upx;
		border: 1px #d6d6d6 solid;
		position: absolute;
		right: 0;
		background: #4b559d;
		color: #FFFFFF;
		border-radius: 10upx;
	}


	
</style>
