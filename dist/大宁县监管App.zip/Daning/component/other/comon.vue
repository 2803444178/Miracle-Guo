<template>
	<view class="content" style="padding: 0 20upx;">
		<view v-for="(item,index) in list" class="itemac" :key="index">
			<view class="itemtop">
				<view class="title">
					{{item.qyname}}
				</view>
				<view class="remake">
					检查时间：{{item.cdate? item.cdate.replace(/.........[0-9]*$/,'') : '无'}}
				</view>
			</view>
			<view class="itembottom">
				<view class="bottomli" @tap="gofill(item)">
					行政处罚
				</view>
				<view class="line">

				</view>
				<view class="bottomli" @tap="gorecord(item)">
					记录列表
				</view>
			</view>
		</view>
	</view>
</template>

<script>
	import commonInfo from "@/common/common.js"
	export default {
		
		props: {
			list: { // 数据列表
				type: Array,
				default () {
					return []
				}
			},
			entType: { // 数据列表
				entType: String,
				default () {
					return []
				}
			},

		},
		methods: {
			gorecord: function(item) {
				commonInfo.userinfo.qyinfo = item;
				uni.navigateTo({
					url:"/pages/Enterprise/Filedetails/FileListA/FileListA"
				})
			},
			gofill: function(item) {
				commonInfo.userinfo.qyinfo = item;
				console.log(item)
				
				uni.navigateTo({
					url:"/pages/punish/punish?type=" + JSON.stringify(item) + ""
				})
				
			}
		}
	}
</script>

<style>
	.content {
		padding: 20upx;
	}

	.itemac {
		width: 100%;
		border-radius: 20upx;
		background: #fff;
		padding: 15upx 10upx;
		margin-bottom: 20upx;
		box-shadow: 0px 2upx 2px #888888;
	}

	.title {
		font-weight: 600;
		color: #333;
		font-size: 32upx;
		display: flex;
		overflow: hidden;
		text-overflow: ellipsis;
		white-space: nowrap;
	}

	.itemtop {
		border-bottom: 2upx solid #d3d3d3;
		padding-left: 20upx;
		padding-bottom: 15upx;
	}

	.remake {
		height: 40upx;
		line-height: 40upx;
		font-size: 24upx;
		color: #6d6d6d;
		display: flex;
		margin-top: 10upx;
		display: flex;
		justify-content: space-between;
	}

	.itembottom {
		height: 70upx;
		display: flex;
		font-size: 24upx;
		color: #6D6D6D;
		justify-content: space-between;
		padding: 0 20upx;
		align-items: center;
	}

	.bottomli {
		width: 49%;
		text-align: center;
	}

	.line {
		width: 2px;
		height: 60%;
		background: #c3c3c3;
	}

	.outline {
		font-size: 18upx;
		color: #4b559d;
		border: #4b559d 1upx solid;
		width: 160upx;
		margin-left: 20upx;
		display: flex;
		align-items: center;
		justify-content: center;
		font-weight: 600;
		border-radius: 10upx;
	}

	.outline.yellow {
		color: #e9c42e;
		border: #e9c42e 1upx solid;
	}

	.outline.red {
		color: #ff2727;
		border: #ff2727 1upx solid;
	}
</style>
