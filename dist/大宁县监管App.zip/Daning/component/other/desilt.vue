<template>
	<view class="content">
		<view v-for="(item,index) in list" :key="index" class="item">
			<view class="title">
				<view class="time">
					申报时间：<text class="timeun">{{item['申报时间'].replace(/00.00.00.0*$/,'')}}</text>
				</view>
				<text class="bb" @tap="godecl(item.ID)">查看详情</text>
			</view>
			<view class="bottom">
				<view class="bottomitem">
					申报人：
					<text style="color: #6D6D6D;">{{item['申报人']}}</text>
				</view>
				<view class="bottomitem">
					协管员：
					<text style="color: #6D6D6D;">{{item['协管员']}}</text>
				</view>
				<view class="bottomitem">
					申报事由：
					<text style="color: #6D6D6D;">{{item['申报事由']}}</text>
				</view>
				<view class="bottomitem">
					联系电话：
					<text style="color: #6D6D6D;">{{item['联系电话']}}</text>
				</view>
			</view>
		</view>
	</view>
</template>

<script>
	export default {
		props: {
			list: { // 数据列表
				type: Array,
				default () {
					return []
				}
			}
		},
		
		methods: {
			godecl: function(id) {
				uni.navigateTo({
					url:"../declare/declhistory?id=" + id + ""
				})
			}
		}
	}
</script>

<style>
	.content {
		padding: 20upx;
	}

	.item {
		width: 100%;
		background: #fff;
		padding: 5upx 20upx 5upx;
		box-shadow: 0px 2upx 2px #888888;
		border-radius: 10upx;
		margin-bottom: 20upx;
	}

	.title {
		height: 70upx;
		border-bottom: 1upx solid #C1C1C1;
		font-size: 28upx;
		display: flex;
		justify-content: space-between;
		align-items: center;
		color: #333333;
	}

	.timeun {
		color: #6d6d6d;
	}

	.bb {
		font-weight: 600;
	}

	.bottom {
		display: flex;
		flex-wrap: wrap;
		margin-top: 20upx;
	}

	.bottomitem {
		width: 50%;
		color: #333;
		font-size: 28upx;
		margin-bottom: 20upx;
		overflow: hidden;
		text-overflow: ellipsis;
		white-space: nowrap;
	}
</style>
