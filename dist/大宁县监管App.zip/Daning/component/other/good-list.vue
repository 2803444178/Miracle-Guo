<template>
	<view class="content">
		<view v-for="(item,index) in list" :key="index" class="item" @tap="details(item.ID,newtype,item.TITLE)" hover-class="itemactive">
			<view class="title">
				{{item.TITLE}}
			</view>
			<view class="iconfont icon-you right"  style="font-size: 24px;"></view>
		</view>
	</view>
</template>

<script>
	export default {
		props: {
			list: { // 数据列表
				type: Array,
				default () {
					return []
				}
			},
			newtype: {
				type: String,
				default () {
					return []
				}
			}
		},
		onLoad:function(){
			console.log(this.newtype)
		},
		
		methods: {
			details: function(id, newtype,tielet) {
				uni.navigateTo({
					url:"/pages/news/newsdetails?id=" + id + "&newtype=" + newtype + "&title=" + tielet + ""
				})
				
			}
		}
	}
</script>

<style>
	.item {
		padding: 30upx 10upx;
		border-bottom: 1upx solid #C1C1C1;
		position: relative;
	}

	.title {
		width: 90%;
		font-size: 30upx;
		display: -webkit-box;
		-webkit-box-orient: vertical;
		-webkit-line-clamp: 2;
		overflow: hidden;
	}

	.time {
		font-size: 28upx;
	}

	.time text {
		margin-left: 100upx;
	}

	.right {
		position: absolute;
		right: 20upx;
		top: 40%;
	}

	.itemactive {
		background: #CCCCCC;
	}
</style>
