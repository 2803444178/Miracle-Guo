import Vue from 'vue'
import App from './App'
// 注册全局组件
import MescrollBody from "@/component/mescroll-uni/mescroll-body.vue"
import MescrollUni from "@/component/mescroll-uni/mescroll-uni.vue"
import wPicker from "@/component/w-picker/w-picker.vue";
Vue.component('mescroll-body', MescrollBody)
Vue.component('mescroll-uni', MescrollUni)
Vue.component('w-picker', wPicker)

//注册全局方法
Vue.prototype.qytype = function(res) {
	if (res == "食品销售") {
		return '201916'
	} else if (res == "餐饮服务") {
		return 'bd0001'
	} else {
		return ''
	}
}

Vue.config.productionTip = false

App.mpType = 'app'

const app = new Vue({
	...App
})
app.$mount()

// 判断登录状态
try {
	const value = uni.getStorageSync('setUserData');
	if (value) {
		//有登录信息
		console.log("已登录用户：", value);
	} else {
		uni.navigateTo({
			url: "pages/login/login"
		})
	}
} catch (e) {
	// error
}
