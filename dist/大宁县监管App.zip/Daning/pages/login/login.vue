<template>
	<view class="content">
		<view class="title">
			大宁县智慧市场管理
		</view>
		<view class="remake">
			移动端
		</view>
		<view class="zai-form">
			<form @submit="submit">
				<input class="zai-input" name="username" placeholder="请输入用户名" />
				<input class="zai-input" type="number" password="true" name="password" placeholder="请输入密码" />
				<button form-type="submit" class="zai-btn">立即登录</button>
			</form>
		</view>
	</view>
</template>

<script>
	import url from "../../common/common.js"
	var apiurl
	export default {
		data() {
			return {
				isRotate: false, //是否加载旋转
			}
		},
		onLoad: function() {
			console.log(url)
			apiurl = url.apiUrl;
		},
		methods: {
			submit: function(e) {
				console.log(e.mp.detail.value)
				uni.showLoading({
					title: '登录中'
				})
				uni.request({
					url: apiurl + '/login', //仅为示例，并非真实接口地址。
					method: 'POST',
					data: {
						username: e.mp.detail.value.username,
						password: e.mp.detail.value.password,
					},
					success: (res) => {
						if (res.statusCode == 200) {
							uni.hideLoading()
							uni.showToast({
								title: "登录成功",
								icon: 'none'
							})
							try {
								uni.setStorageSync('setUserData', e.mp.detail.value); //存入缓存
							} catch (e) {
								// error
							}
							setTimeout(function() {
								uni.reLaunch({
									url: '../index/index',
								});
							}, 300)
						}
					},
					fail: function(err) {
						uni.showToast({
							title: "请检查网络后重试",
							icon: 'none'
						})
					},
					complete: function(res) {
						if (res.statusCode == 200) {
							console.log(res.data.message)
						} else if (res.data && res.data.message) {
							console.log(res.data.message)
							uni.showToast({
								title: "用户名密码错误 ",
								icon: 'none'
							})
						}
					}
				});

			},
		}
	}
</script>

<style>
	.content {
		background: url(http://a.tianlutang120.com/test/bg.png) no-repeat;
		background-size: 100% 100%;
		position: absolute;
		width: 100%;
		height: 100%;
		padding-top: 100upx;
	}

	.title {
		font-weight: 600;
		color: #fff;
		text-align: center;
		margin-bottom: 20upx;
	}

	.remake {
		font-weight: 600;
		color: #fff;
		text-align: center;
	}

	.zai-form {
		margin-top: 300upx;
	}

	.zai-input {
		width: 65%;
		padding: 15upx 40upx;
		font-size: 28upx;
		border: 1px solid #c8c8c8;
		border-radius: 40upx;
		margin: 60upx auto;
	}

	.input-placeholder,
	.zai-input {
		color: #94afce;
	}


	.zai-btn {
		width: 75%;
		background: #4b559d;
		padding: 0 40upx;
		color: #fff;
		border: 0;
		border-radius: 100upx;
		font-size: 34upx;
		font-weight: 600;
		height: 70upx;
		text-align: center;
		line-height: 70upx;
	}

	.zai-btn:after {
		border: 0;
	}

	/*按钮点击效果*/
	.zai-btn.button-hover {
		transform: translate(1upx, 1upx);
	}
</style>
