<template>
	<view>
		<view class="success">
			<view class="iconfont icon-chenggong "></view>
			<view class="tiiit">成功</view>
			<view class="bntbox">
				<button class="btn" @tap="back">
					返回
				</button>
				<button class="btn" @tap="history">
					查看记录
				</button>
			</view>
		</view>
	</view>
</template>

<script>
	export default {
		data() {
			return {

			}
		},
		methods: {
			back: function() {
				uni.navigateBack({
					delta: 5
				})
			},
			history: function() {
				uni.navigateBack({
					delta: 5
				})
				setTimeout(function() {
					uni.navigateTo({
						url: "../index/Enterprise/Filedetails/FileList/FileList"
					})
				}, 1000)
			}

		}
	}
</script>

<style>
	.success {
		padding: 200upx 30upx;
	}

	.iconfont {
		font-size: 250upx;
		text-align: center;
	}

	.tiiit {
		text-align: center;
	}

	.bntbox {
		width: 100%;
		display: flex;

	}

	.btn {
		width: 40%;
		height: 60upx;
		line-height: 60upx;
		margin-top: 70upx;
		background: #4b559d;
		font-size: 30upx;
		color: #fff;
	}
</style>
