<template>
	<view class="content" v-if="info">
		<scroll-view class="scroll" scroll-y>
			<view class="scroll-content">
				<view class="introduce-section">
					<text class="title">{{info.CONTENT_NAME || info.TITLE}}</text>
					<view class="introduce">
						<text>{{info.CREATE_DATE }}</text>
					</view>
					<rich-text style="font-size: 30upx;" :nodes="flow"></rich-text>
				</view>
			</view>
		</scroll-view>
	</view>
</template>

<script>
	import commonInfo from "@/common/common.js"
	export default {
		data() {
			return {
				loading: true,
				detailData: {},
				newsList: [],
				evaList: [],
				info: '',
				flow: ''
			}
		},
		onLoad(res) {
			var that = this;
			var id = res.id
			uni.setNavigationBarTitle({
				title: res.title
			})
			let memberId = commonInfo.userinfo.info.memberId;
			var url;
			if (res.newtype == "公告") {
				url = 'http://h5.shouyunchina.com:8002/DNServices/getAnnounceInfoServlet?memberId="' + memberId + '&&id=' + id + ''
			} else {
				url = 'http://h5.shouyunchina.com:8002/DNServices/getNewsInfoServlet?memberId="' + memberId + '&&id=' + id + ''
			}
			uni.showLoading({
				title:"加载中"
			})
			uni.request({
				url: url,
				method: "POST",
				data: {
					id: id,
					memberId: memberId
				},
				success: function(res) {
					console.log(res)
					uni.hideLoading()
					if (res.data) {
						that.info = res.data;
						let title = res.data.CONTENT_NAME || res.data.TITLE;
						var richtext = that.flow;
						const regex = new RegExp('<img', 'gi');
						richtext = richtext.replace(regex, `<img style="width: 100%;"`);
						that.flow = res.data.CONTENT || res.data.BODY_CONTENT;
						that.loading = false;
					} else {
						that.info = null
					}

				},
				fail:function(err){
					uni.showToast({
						title:"请求超时",
						icon:"none"
					})
				}
			})
		},
	}
</script>

<style lang="scss">
	page {
		height: 100%;

	}

	img {
		width: 100% !important;
	}



	.content {
		display: flex;
		flex-direction: column;
		height: 100%;
		background: #fff;
		padding: 0;
	}

	.video-wrapper {
		height: 422upx;

		.video {
			width: 100%;
			height: 100%;
		}
	}

	.status_bar {
		height: var(--status-bar-height);
		width: 100%;
		background: #4b559d;
	}

	.headbox {
		background: #4b559d;
		text-align: center;
		padding: 20upx;
		color: #fff;
		font-weight: normal;
	}

	.scroll {
		flex: 1;
		position: relative;
		background-color: #f8f8f8;
		height: 0;
	}

	.scroll-content {
		display: flex;
		flex-direction: column;
	}

	/* 简介 */
	.introduce-section {
		display: flex;
		flex-direction: column;
		padding: 20upx 30upx;
		background: #fff;
		line-height: 1.5;

		.title {
			font-size: 36upx;
			color: #303133;
			margin-bottom: 16upx;
			font-weight: 600;
		}

		.introduce {
			display: flex;
			font-size: 26upx;
			color: #909399;
			margin-bottom: 35upx;

			text {
				margin-right: 16upx;
			}
		}
	}

	/* 点赞等操作 */
	.actions {
		display: flex;
		justify-content: space-around;
		align-items: center;
		line-height: 1.3;
		padding: 10upx 40upx 20upx;

		.action-item {
			display: flex;
			flex-direction: column;
			align-items: center;
			justify-content: center;
			font-size: 24upx;
			color: #999;
		}

		.yticon {
			display: flex;
			align-items: center;
			justify-content: center;
			width: 60upx;
			height: 60upx;
			font-size: 52upx;

			&.reverse {
				position: relative;
				top: 6upx;
				transform: scaleY(-1);
			}

			&.active {
				color: #ec706b;
			}
		}

		.icon-fenxiang2 {
			font-weight: bold;
			font-size: 36upx;
		}

		.icon-shoucang {
			font-size: 44upx;
		}
	}

	.s-header {
		padding: 20upx 30upx;
		font-size: 30upx;
		color: #303133;
		background: #fff;
		margin-top: 16upx;

		&:before {
			content: '';
			width: 0;
			height: 40upx;
			margin-right: 24upx;
			border-left: 6upx solid #ec706b;
		}
	}

	/* 推荐列表 */
	.rec-section {
		background-color: #fff;

		.rec-item {
			display: flex;
			padding: 20upx 30upx;
			position: relative;

			&:after {
				content: '';
				position: absolute;
				left: 30upx;
				right: 0;
				bottom: 0;
				height: 0;
				border-bottom: 1px solid #eee;
				transform: scaleY(50%);
			}
		}

		.left {
			flex: 1;
			padding-right: 10upx;
			overflow: hidden;
			position: relative;
			padding-bottom: 52upx;

			.title {
				display: -webkit-box;
				-webkit-box-orient: vertical;
				-webkit-line-clamp: 2;
				overflow: hidden;
				font-size: 32upx;
				color: #303133;
				line-height: 44upx;
				font-weight: 600;
			}

			.bot {
				position: absolute;
				left: 0;
				bottom: 4upx;
				font-size: 26upx;
				color: #909399;
			}

			.time {
				margin-left: 20upx;
			}
		}

		.right {
			width: 220upx;
			height: 140upx;
			flex-shrink: 0;
			position: relative;

			.img {
				width: 100%;
				height: 100%;
			}

		}
	}

	/* 评论 */
	.evalution {
		display: flex;
		flex-direction: column;
		background: #fff;
		padding: 20upx 0;
	}

	.eva-item {
		display: flex;
		padding: 20upx 30upx;
		position: relative;

		image {
			width: 60upx;
			height: 60upx;
			border-radius: 50px;
			flex-shrink: 0;
			margin-right: 24upx;
		}

		&:after {
			content: '';
			position: absolute;
			left: 30upx;
			bottom: 0;
			right: 0;
			height: 0;
			border-bottom: 1px solid #eee;
			transform: translateY(50%);
		}

		&:last-child:after {
			border: 0;
		}
	}

	.eva-right {
		display: flex;
		flex-direction: column;
		flex: 1;
		font-size: 26upx;
		color: #909399;
		position: relative;

		.zan-box {
			display: flex;
			align-items: base-line;
			position: absolute;
			top: 10upx;
			right: 10upx;

			.yticon {
				margin-left: 8upx;
			}
		}

		.content {
			font-size: 28upx;
			color: #333;
			padding-top: 20upx;
		}
	}

	/* 底部 */
	.bottom {
		flex-shrink: 0;
		display: flex;
		align-items: center;
		height: 90upx;
		padding: 0 30upx;
		box-shadow: 0 -1px 3px rgba(0, 0, 0, .04);
		position: relative;
		z-index: 1;

		.input-box {
			display: flex;
			align-items: center;
			flex: 1;
			height: 60upx;
			background: #f2f3f3;
			border-radius: 100px;
			padding-left: 30upx;

			.icon-huifu {
				font-size: 28upx;
				color: #909399;
			}

			.input {
				padding: 0 20upx;
				font-size: 28upx;
				color: #303133;
			}
		}

		.confirm-btn {
			font-size: 30upx;
			padding-left: 20upx;
			color: #0d9fff;
		}
	}
</style>
