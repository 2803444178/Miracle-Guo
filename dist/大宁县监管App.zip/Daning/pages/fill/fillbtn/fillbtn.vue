<template>
	<view>
		<view class="container">
			<form @submit="formSubmit">
				<view class="radiom">
					<view class="lefttitle">
						检查结果
					</view>
					<radio-group class="uni-flex" name="gender">
						<label class="radioitem">
							<radio value="8361367595765681198">符合</radio>
						</label>
						<label class="radioitem">
							<radio value="-2066416451667277405">基本符合</radio>
						</label>
						<label class="radioitem">
							<radio value="6571312966818286323">不符合</radio>
						</label>
					</radio-group>
				</view>
				<view class="radiom">
					<view class="lefttitle">
						结果处理
					</view>
					<radio-group class="uni-flex" name="gend">
						<label class="radioitem">
							<radio value="986401131406182056">通过</radio>
						</label>
						<label class="radioitem">
							<radio value="-233736429269465346">书面整改</radio>
						</label>
						<label class="radioitem">
							<radio value="-8708609701263029876">停业整顿</radio>
						</label>
					</radio-group>
				</view>

				<view class="radiom">
					<view class="lefttitle">
						说明
					</view>
					<view class="uni-textarea uni-flex">
						<textarea name="explain" auto-height></textarea>
					</view>
				</view>
				<view class="radiom">
					<view class="lefttitle">
						执法定位
					</view>
					<view class="uni-textarea uni-flex">
						{{address}}
					</view>
				</view>
				<view class="radiom">
					<view class="lefttitle">
						人员签名
					</view>
					<view class="writebox">
						<view class="grace-idcard-items qian">
							<view class="grace-idcard-uper-btn" @tap="gocanvas('zhi')">
								{{signImage?'':'点击输写签名'}}
								<image :src="signImage" class="qianfa" mode="aspectFill"></image>
							</view>
							<view class="" style="text-align: center;">
								检查人员
							</view>
						</view>
						<view class="grace-idcard-items qian ">
							<view class="grace-idcard-uper-btn" @tap="gocanvas('fa')">
								<image :src="signImagee" class="qianfa" style="z-index: 111; width: 100%; height: 100%;" mode="widthFix"></image>
								{{signImagee?'':'点击输写签名'}}
							</view>
							<view class="" style="text-align: center;">
								法人或负责人
							</view>
						</view>
					</view>
				</view>
				<view class="radiom">
					<view class="lefttitle">
						添加附件
					</view>
					<view class="writebox">
						<view class="grace-idcard-items uni-flex">
							<view class="grace-idcard-uper-btn" @tap="addimage()">
								点击添加附件
							</view>
							<view class="grace-idcard-preview" v-for="(item,index) in attachmentsimg" :key="index">
								<image :src="item ? item :'../../static/idcard1.png' " @tap="gocanvas('fa')" mode="aspectFit"></image>
							</view>
						</view>
					</view>
				</view>
				<button form-type="submit" class="btn" hover-class="btn-hover">提交</button>
			</form>
		</view>

	</view>
</template>

<script>
	import url from "@/common/common.js"
	import api from "@/api/api.js"
	var apiurl
	var _self;
	var formlist = [];
	var content = null;
	var touchs = [];
	var canvasw = 0;
	var canvash = 0;
	var typee
	//获取系统信息
	uni.getSystemInfo({
		success: function(res) {
			canvasw = res.windowWidth;
			canvash = canvasw * 9 / 16;
		},
	})
	export default {
		data() {
			return {
				timeTemp: 1558662393,
				address: url.userinfo.adrssinfo.address,
				adressid: '',
				obj: "",
				signImage: '',
				signImagee: '',
				qianming: "",
				attachments: [], //附件ID
				attachmentsimg: [] //附件图片
			}
		},
		onLoad: function(res) {
			_self = this;
			apiurl = url.apiUrl;
			//确保定位成功
			let tokenurl = api.apiUrle + '/addLocationServlet';
			url.userinfo.adrssinfo.loginName = url.userinfo.name
			let dataobj = url.userinfo.adrssinfo;
			let tokentype = 'POST'
			api.getToken(tokenurl, dataobj, tokentype, (res) => {
				if (res && res.code == '0') {
					this.adressid = res.message;
				}
			});
			/* 页面初始化，清除canvas的历史操作 */
			uni.removeStorage({
				key: 'signImage',
			})
			uni.removeStorage({
				key: 'signImagee',
			})
			this.obj = res;

		},
		// 签名当作附件上传
		onShow: function() {
			var allobj = url.userinfo.daily.data.values;
			if (url.userinfo.zhiperson == true) {
				const value = uni.getStorageSync('signImage');
				this.signImage = value;
				uni.showLoading({
					title:"上传中"
				})
				uni.uploadFile({
					url: 'http://183.203.90.25:8888/seeyon/rest/attachment?token=' + url.userinfo.token +
						'&applicationCategory=0&extensions=&firstSave=false', //仅为示例，非真实的接口地址
					filePath: value,
					name: 'file',
					success: (res) => {
						let obj = JSON.parse(res.data);
						if (res.statusCode == 200 && res.statusCode) {
							uni.hideLoading()
							uni.showToast({
								title: "上传成功"
							})
							url.userinfo.zhiperson = false;
							for (let i in allobj) {
								if (allobj[i].name == "执法人员签名") {
									allobj[i].value = obj.atts[0].fileUrl;
									this.attachments.push(obj.atts[0].fileUrl)
								}
							}
						} else {
							uni.showToast({
								title: "签名上传失败"
							})
							url.userinfo.zhiperson = false
						}

					}
				});
			} else if (url.userinfo.faperson == true) {
				const valuee = uni.getStorageSync('signImagee');
				uni.showLoading({
					title:"上传中"
				})
				if (valuee) {
					this.signImagee = valuee;
					uni.uploadFile({
						url: 'http://183.203.90.25:8888/seeyon/rest/attachment?token=' + url.userinfo.token +
							'&applicationCategory=0&extensions=&firstSave=true', //仅为示例，非真实的接口地址
						filePath: valuee,
						name: 'file',
						success: (res) => {
							let obj = JSON.parse(res.data);
							if (res.statusCode) {
								uni.hideLoading()
								uni.showToast({
									title: "上传成功"
								})
								url.userinfo.faperson = false;
								for (let i in allobj) {
									if (allobj[i].name == "法人负责人签字") {
										allobj[i].value = obj.atts[0].fileUrl;
										this.attachments.push(obj.atts[0].fileUrl)
									}
								}
							} else {
								uni.showToast({
									title: "签名上传失败"
								})
								url.userinfo.faperson = false
							}

						}
					});
				}
			}
		},
		methods: {
			back: function() {
				uni.navigateBack()
			},
			gocanvas: function(res) {
				uni.navigateTo({
					url: 'canvas/canvas?res=' + res + ''
				});
			},
			addimage: function() {
				var allobj = url.userinfo.daily.data.values.column;
				uni.chooseImage({
					success: (chooseImageRes) => {
						uni.showLoading({
							title: "上传中"
						})
						const tempFilePaths = chooseImageRes.tempFilePaths;
						for (let i in tempFilePaths) {
							this.attachmentsimg.push(chooseImageRes.tempFilePaths[i]);
							uni.uploadFile({
								url: 'http://183.203.90.25:8888/seeyon/rest/attachment?token=' + url.userinfo.token +
									'&applicationCategory=0&extensions=&firstSave=true', //仅为示例，非真实的接口地址
								filePath: tempFilePaths[i],
								name: 'file',
								success: (uploadFileRes) => {
									console.log(uploadFileRes)
									console.log(tempFilePaths.length)
									console.log(i)
										uni.hideLoading()
										uni.showToast({
											title: "上传成功"
										})
										var obj = JSON.parse(uploadFileRes.data);
										this.attachments.push(obj.atts[0].fileUrl);
								}
							});
						}

					}
				});
			},
			formSubmit: function(res) {
				var formData = res.detail.value;
				//签名 附件 定位不能为空。确保全部有值的情况下发起协同
				if (this.adressid) {
					if (!formData.gend || !formData.gender) {
						uni.showToast({
							title: "检查结果和处理不可为空",
							icon: "none"
						})
						return false;
					}
					let allobj = url.userinfo.daily.data.values;
					for (let i in allobj) {
						if (allobj[i].name == "说明") {
							allobj[i].value = formData.explain
						} else if (allobj[i].name == "检查结果") {
							allobj[i].value = formData.gender
						} else if (allobj[i].name == "结果处理") {
							allobj[i].value = formData.gend
						} else if (allobj[i].name == "执法定位") {
							allobj[i].value = this.adressid;
						}
						if (!allobj[i].value) {
							allobj[i].value = []
						}
					}

					url.userinfo.daily.attachments = this.attachments;
					console.log(url.userinfo.daily)
					//发起协同
					let dataobj = url.userinfo.daily;
					uni.showLoading({
						title: "提交中"
					})
					api.postFormdata(dataobj,(res)=>{
						if (res && res.code == '0') {
							uni.hideLoading();
							uni.showToast({
								title: "提交成功",
								icon: "success"
							})
							setTimeout(function() {
								uni.navigateTo({
									url: "../../success/success"
								})
							}, 600);
						}
					})
				}
			},
		}
	}
</script>

<style>
	@import url("../../../common/uni.css");

	page {
		background: #fff;
	}

	.qianfa {
		z-index: 111;
		width: 100%;
		height: 100%;
		position: absolute;
		left: 0;
		top: 0;
	}

	content {
		width: 100%;
		height: 500px;
	}

	.grace-idcard-items {
		background: #FFFFFF;
		padding: 30upx 0;
		display: flex;
		border-radius: 10upx;
		align-items: flex-start;
		flex-wrap: wrap;
	}

	.writebox {
		display: flex;
		padding-left: 20upx;
		justify-content: space-between;
		width: 100%;
		flex: 1;
	}

	.grace-idcard-items.qian {
		display: flex;
		justify-content: center;
		flex-direction: column;
		align-items: center;
	}

	.grace-idcard-uper-btn {
		width: 240upx;
		background: #fff;
		padding-bottom: 10upx;
		border-radius: 10upx;
		text-align: center;
		height: 240upx;
		line-height: 240upx;
		color: #858585;
		border: 1upx solid #dcdcdc;
		position: relative;
	}

	.grace-idcard-uper-btn .img {
		width: 100upx;
		height: 100upx;
		margin: 0 auto;
		margin-top: 30upx;
	}

	.grace-idcard-uper-btn .img image {
		width: 100upx;
		height: 100upx;
	}

	.grace-idcard-uper-btn .text {
		width: 100%;
		margin-top: 10upx;
		text-align: center;
		line-height: 2em;
	}

	.grace-idcard-preview {
		width: 240upx;
		padding: 0 20rpx;
		height: 240upx;
	}

	.grace-idcard-preview image {
		width: 100%;
		height: 100%;
	}

	.firstCanvas {
		background-color: #ddd;
		width: 100%;
		height: 200px;
	}

	.contents image {
		width: 100%;
		height: 200px;
		background-color: orange;
	}

	#signatureImg {
		background-color: #ddd;
	}

	.faname {
		margin: 0 24upx;
		border-bottom: 1px solid #4b559d;

	}

	.uni-textarea {
		margin: 0 24upx;
		box-sizing: border-box;
		border-bottom: 1px solid #333;
		width: auto;
	}

	.uni-textarea uni-textarea {

		padding: 0;
		width: 100%;
	}

	uni-radio-group {
		width: 100%;
		height: 100%;
		display: flex;
		justify-content: space-between;
		align-items: center;
	}

	.tishi.left {
		text-align: left;
		padding: 0 24upx;
		margin: 0 0;
	}

	.radioitem {
		height: 100%;
		display: flex;
		justify-content: center;
		align-items: center;
		font-size: 28upx;
	}

	.radiom {
		display: flex;
		align-items: center;
	}

	.uni-flex {
		flex: 1;
		display: flex;
		flex-wrap: wrap;
	}

	.lefttitle {
		min-width: 100upx;
		font-size: 14px;
		line-height: 16px;
		color: #333;
		margin: 20px 12px;
		font-weight: 600;
		position: relative;
	}

	.container {
		padding: 30upx 25upx 0;
	}

	.title {
		text-align: center;
		font-size: 36upx;
		color: #333333;
		font-weight: 600;
	}

	.tishi {
		text-align: center;
		font-size: 26upx;
		margin: 40upx 0;
		color: #333333;
	}


	.btn {
		width: 440upx;
		height: 60upx;
		line-height: 60upx;
		margin-top: 70upx;
		background: #4b559d;
		font-size: 30upx;
		color: #fff;
	}

	.btn-hover {
		color: hsla(0, 0%, 100%, .6);
	}
</style>
