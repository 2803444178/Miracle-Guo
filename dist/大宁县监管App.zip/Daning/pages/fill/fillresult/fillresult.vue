<template>
	<view>
		<view class="content">
			<form @submit="submit">
				<view class="title">
					检查内容
				</view>
				<view class="totcontent" v-if="obj">
					<input type="text" name="date" style="opacity: 0;" :value="timeTemp|timeFormat" />
					<view class="tiiit">
						<view class="initem">{{nickname}}</view>
						检察人员根据《中华人民共和国食品安全法》及实施条例、
						《食品生产经营日常监督检查管理办法的规定》，于
						<view class="initem">{{timeTemp|timeFormat}}</view>
						对你单位进行了监督检查，
						本次监督检查按照表开展，共检查了
						<view class="initem">{{obj.arr.length + obj.pro.length}}</view>
						项内容，其中：
					</view>
					<view class="tiiit">
						<view class="title">
							重点项：<view class="initem listiem">{{obj.arr.length}}</view>项
						</view>
						<view class="title tfle">
							项目序号分别是：<view class="initem listiem">
								<text class="lie" v-for="(item,index) in obj.arr" :key="index">
									{{item}}
								</text>
							</view>
						</view>
						<view class="title">
							发现问题：<view class="initem listiem">{{obj.arrpro.length}}</view>项
						</view>
						<view class="title tfle">
							项目序号分别是：<view class="initem listiem"><text class="lie" v-for="(item,index) in obj.arrpro" :key="index">
									{{item}}
								</text></view>
						</view>
					</view>
					<view class="tiiit">
						<view class="title">
							一般项：<view class="initem listiem">{{obj.pro.length}}</view>项
						</view>
						<view class="title tfle">
							项目序号分别是：<view class="initem listiem">
								<text class="lie" v-for="(item,index) in obj.pro" :key="index">
									{{item}}
								</text></view>
						</view>
						<view class="title">
							发现问题：<view class="initem ">{{obj.propro.length}}</view>项
						</view>
						<view class="title tfle">
							项目序号分别是：<view class="initem listiem">
								<text class="lie" v-for="(item,index) in obj.propro" :key="index">
									{{item}}
								</text>
							</view>
						</view>
					</view>
				</view>
				<button class="btn" hover-class="btn-hover" form-type="submit">下一步</button>
			</form>
		</view>
	</view>
</template>

<script>
	import url from "@/common/common.js"
	export default {
		data() {
			return {
				obj: null,
				nickname: '',
				timeTemp: 1558662393,
			}
		},
		onLoad: function(res) {
			var timestamp = new Date().getTime();
			this.timeTemp = timestamp;
			/* 从全局变量中取 */
			let allobj = url.userinfo.daily.data.values;
			this.nickname = url.userinfo.name;
			this.obj = url.userinfo.total;
			
			console.log(this.obj)
			for (let i in allobj) {
				if (allobj[i].name == "一般项数") {
					allobj[i].value = this.obj.pro.length
				} else if (allobj[i].name == "一般项序号") {
					allobj[i].value = this.obj.pro.join(',')
				} else if (allobj[i].name == "一般项发现问题项数") {
					allobj[i].value = this.obj.propro.length
				} else if (allobj[i].name == "一般项发现问题序号") {
					allobj[i].value = this.obj.propro.join(',')
				} else if (allobj[i].name == "重点项数") {
					allobj[i].value = this.obj.arr.length
				} else if (allobj[i].name == "重点项序号") {
					allobj[i].value = this.obj.arr.join(',')
				} else if (allobj[i].name == "重点问题中发现问题项数") {
					allobj[i].value = this.obj.arrpro.length
				} else if (allobj[i].name == "重点项中发现问题项序号") {
					allobj[i].value = this.obj.arrpro.join(',')
				}
			}
		},
		methods: {
			back: function() {
				uni.navigateBack()
			},
			submit: function(e) {
				let allobj = url.userinfo.daily.data.values;
				for (let i in allobj) {
					if (allobj[i].name == "检查日期") {
						allobj[i].value = e.detail.value.date
					} else if (allobj[i].name == "检查时间") {
						allobj[i].value = e.detail.value.date
					}
				}
				uni.navigateTo({
					url: "../fillbtn/fillbtn"
				})
			}
		},
		filters: {
			timeFormat: function(arg, type = 'YYYY-MM-DD h:m:s') {
				if (arg.toString().length == 10) {
					arg = arg * 1000;
					//如果date为13位不需要乘1000
					//[js时间戳长度是13位]，php，java等时间戳长度为10位
				}
				var date = new Date(arg)
				var year = date.getFullYear(); //获取年
				var mouth = (date.getMonth() + 1 < 10 ? '0' + (date.getMonth() + 1) : date.getMonth() + 1); //月
				var day = (date.getDate() < 10 ? '0' + (date.getDate()) : date.getDate()); //日
				var hour = (date.getHours() < 10 ? '0' + date.getHours() : date.getHours()); //时
				var minute = (date.getMinutes() < 10 ? '0' + date.getMinutes() : date.getMinutes()); //分
				var second = (date.getSeconds() < 10 ? '0' + date.getSeconds() : date.getSeconds()); //秒
				var week; //星期
				if (date.getDay() == 0) week = "星期日"
				if (date.getDay() == 1) week = "星期一"
				if (date.getDay() == 2) week = "星期二"
				if (date.getDay() == 3) week = "星期三"
				if (date.getDay() == 4) week = "星期四"
				if (date.getDay() == 5) week = "星期五"
				if (date.getDay() == 6) week = "星期六"
				if (type == 'YYYY-MM-DD h:m:s') {
					return year + '-' + mouth + '-' + day + ' ' + hour + ':' + minute + ':' + second;
				}
				if (type == 'YYYY-MM-DD') {
					return year + '-' + mouth + '-' + day;
				}
				if (type == 'MM-DD') {
					return mouth + '-' + day;
				}
				if (type == 'MM-DD WEEK') {
					return mouth + '-' + day + ' ' + week;
				}
			}
		},
	}
</script>

<style>
	page {
		background: #fff;
	}

	.status_bar {
		height: var(--status-bar-height);
		width: 100%;
		background: #4b559d;
	}

	.headbox {
		background: #4b559d;
		text-align: center;
		padding: 20upx;
		color: #fff;
		font-weight: normal;
	}

	.content {
		padding: 20upx 40upx;
	}

	.totcontent {
		padding: 10upx 0;
		font-size: 28upx;
		margin-bottom: 5upx;
		line-height: 70upx;
		text-indent: 2em;
	}

	.title {
		font-size: 28upx;
		text-indent: 0;
	}

	.title.tfle {
		display: flex;
		flex-wrap: wrap;
	}

	.title.tfle .initem {
		flex: 1;
		text-align: justify;
		overflow-wrap: break-word;
	}

	.tiiit {
		margin-bottom: 100upx;
	}

	.listiem {
		margin: 5upx 0;
		text-align: justify;
	}

	.listiem .lie {
		margin: 0 5upx;
	}

	.initem {
		border-bottom: 0.2px solid #0a0a0a;
		font-size: 28upx;
		color: #656565;
		display: inline-block;
		min-width: 160upx;
		padding: 0 10upx;
		text-indent: 0;
		text-align: center;
	}

	.btn {
		width: 440upx;
		height: 60upx;
		line-height: 60upx;
		margin-top: 70upx;
		background: #4b559d;
		font-size: 30upx;
		color: #fff;
	}

	.btn-hover {
		color: hsla(0, 0%, 100%, .6);
	}
</style>
