<template>
	<view>
		<view class="continaer" v-if="fromdata">
			<view class="list">
				<view v-for="(item,index) in fromdata" :key="index" class="listitem" @click="togglePopup('bottom', 'share',item,index)">
					<text class="circle">{{index+1}}</text>
					{{item}}
				</view>
			</view>
			<button @tap="frombutton" hover-class="btn-hover" class="commonbtn">提交</button>
		</view>
		<!-- 底部分享弹窗 -->
		<uni-popup :show="showshare" :type="type" @change="change">
			<view class="titleitem">
				检查内容
				<view class="iconfont icon-cuowu xiala iconii" @click="close('share')"></view>
			</view>
			<view class="itemcontinaer">
				<scroll-view scroll-y="true" style="height:100%;width: 100%;overflow: hidden;">
					<view class="itembox">
						<view v-for="(item,index) in contentdata" :key="index">
							<view class="iteltitle" :data-id="item.cheacked">
								<text v-if="item.level == 'important'">*</text> {{item.index}}
							</view>
							<view class="itemcontent">
								{{item.message}}
							</view>
							<radio-group v-if="item.rule== 'checkbox'" :data-index="index" class="itemcheack">
								<label class="radio itemcheack" @tap="radioChange(form['是'+item.index])">
									<view>
										<label>
											<checkbox class="radioitem" :checked="form['是'+item.index].value == '1'" />
										</label>
									</view>
									<view>是</view>
								</label>
								<label class="radio itemcheack" @tap="radioChange(form['否'+item.index])">
									<label>
										<checkbox class="radioitem" :checked="form['否'+item.index].value == '1'" />
									</label>
									<view>否</view>
								</label>
							</radio-group>
							<view class="section">
								<view class="section__title">备注：</view>
								<input v-model="form['备注'+item.index].value" class="section__input" name="备注" placeholder="备注"></input>
							</view>
						</view>
					</view>
				</scroll-view>
			</view>
		</uni-popup>
	</view>
</template>

<script>
	import uniPopup from '@/component/uni-popup/uni-popup.vue'
	import url from "@/common/common.js"
	import commonInfo from "@/common/common.js"
	import api from "@/api/api.js"
	var apiurl
	export default {
		components: {
			uniPopup
		},
		data() {
			return {
				showshare: false,
				type: '',
				fromdata: null,
				contentdata: '',
				form: {},
				category: [],
				template: {},
				totalarr: [],
			}
		},
		onLoad: function() {
			let templateCode = this.qytype(commonInfo.userinfo.qyinfo.qylx);
			let senderLoginName = commonInfo.userinfo.name;
			if (templateCode == '201916') {
				uni.setNavigationBarTitle({
					title: '食品销售日常监督检查要点表'
				})
			} else if (templateCode == 'bd0001') {
				uni.setNavigationBarTitle({
					title: '餐饮服务日常监督检查要点表'
				})
			}
			
			uni.showLoading({
				title: "加载中"
			})
			api.getFormdata('', templateCode, senderLoginName, (res, form) => {
				url.userinfo.daily = res;
				//s数组去重
				function unique(arr) {
					return Array.from(new Set(arr))
				}
				console.log(form)
				console.log(res)
				this.form = form;
				this.template = res;
				let {
					data: {
						values: values
					}
				} = res;

				let fromvalue = values.filter(row => {
					return row.category;
				});

				let str = [];
				for (let i in fromvalue) {
					if (fromvalue[i].message && i < (fromvalue.length / 2)) {
						str.push(fromvalue[i])
					}
				}

				let sttr = [];
				for (let i in str) {
					sttr.push(str[i].category)
				}
				let arr = unique(sttr)
				this.fromdata = arr;
			});
		},
		methods: {
			togglePopup(type, open, item, index) {
				let res = this.template;
				let {
					data: {
						values: values
					}
				} = res;
				let contentdata = values.filter(row => {
					return row.category === item;
				});
				let str = [];
				for (let i in contentdata) {
					if (contentdata[i].message && i < (contentdata.length / 2)) {
						str.push(contentdata[i])
					}
				}
				this.contentdata = str;
				this.type = type
				this['show' + open] = true
			},
			radioChange(evt) {
				let str = this.totalarr;
				if (evt.value == '') {
					evt.value = 1;
					str.push(evt);
				} else {
					evt.value = '';
					for (let i in str) {
						if (str[i].name == evt.name) {
							console.log(i)
							str.splice(i, 1)
						}
					}
				}
				this.totalarr = str;
			},
			frombutton: function() {
				url.userinfo.daily = this.template;
				let str = this.totalarr
				let toarr = [];
				let arr = [];
				let arrpro = [];
				let pro = [];
				let propro = [];
				for (let i in str) {
					toarr.push(str[i].index);
					// 一般项和重点项
					if (str[i].level == 'normal') {
						arr.push(str[i].index);
					} else {
						pro.push(str[i].index);
					}
					// 一般项和重点项问题项
					if (str[i].level == "normal" && str[i].name.includes('否')) {
						arrpro.push(str[i].index);
					} else if (str[i].level == "important" && str[i].name.includes('否')) {
						propro.push(str[i].index);
					}
				}
				url.userinfo.total.totalarr = toarr;
				url.userinfo.total.arr = arr;
				url.userinfo.total.arrpro = arrpro;
				url.userinfo.total.pro = pro;
				url.userinfo.total.propro = propro;
				let allobj = this.template.data.values;
				for (let i in allobj) {
					if (allobj[i].name == "检查内容项") {
						allobj[i].value = url.userinfo.total.totalarr.length
					} else if (allobj[i].name == "重点项") {
						allobj[i].value = url.userinfo.total.pro.length
					} else if (allobj[i].name == "重点项项目序号") {
						allobj[i].value = url.userinfo.total.pro
					} else if (allobj[i].name == "重点项发现问题项") {
						allobj[i].value = url.userinfo.total.propro.length
					} else if (allobj[i].name == "重点项发现问题项项目序号") {
						allobj[i].value = url.userinfo.total.propro
					} else if (allobj[i].name == "一般项") {
						allobj[i].value = url.userinfo.total.arr.length
					} else if (allobj[i].name == "一般项项目序号") {
						allobj[i].value = url.userinfo.total.arr
					} else if (allobj[i].name == "一般项发现问题项") {
						allobj[i].value = url.userinfo.total.arrpro.length
					} else if (allobj[i].name == "一般项发现问题项项目序号") {
						allobj[i].value = url.userinfo.total.arrpro
					}
				}
				uni.navigateTo({
					url: "fillinfo/fillinfo"
				})
			},
			cancel(type) {
				this['show' + type] = false
			},
			change(e) {
				if (!e.show) {
					this.showshare = false
					this.showpopup = false
				}
			},
			close(type) {
				this['show' + type] = false
			}
		},
		onBackPress() {
			if (this.showshare) {
				this.showshare = false
				return true
			}
		}
	}
</script>
<style>
	view {
		box-sizing: border-box;
	}

	.iconii {
		position: absolute;
		color: #a3a3a3;
		right: 5px;
		font-size: 50upx;
		color: #4b559d;
		top: 0;
	}

	/* 底部分享 */
	.uni-share {
		/* #ifndef APP-NVUE */
		display: flex;
		flex-direction: column;
		/* #endif */
		background-color: #fff;
	}

	.continaer {
		width: 100%;
		height: 100%;
		z-index: 1111;
	}

	.title {
		width: 100%;
		height: 60upx;
		background: #4b559d;
		font-size: 24upx;
		text-align: center;
		color: #fff;
		line-height: 60upx;
		position: relative;
	}

	.help {
		position: absolute;
		width: 40upx;
		height: 40upx;
		right: 35upx;
		top: 10upx;
	}

	.list {
		padding: 0upx 15upx 25upx;
	}

	.listitem {
		height: 74upx;
		background: #fff;
		font-size: 24upx;
		color: #333;
		line-height: 74upx;
		border-bottom: 1upx solid #b8b8b8;
		padding: 0 25upx;
		position: relative;
		margin-top: 30upx;
	}


	.circle {
		width: 40upx;
		height: 40upx;
		background: #4b559d;
		border-radius: 50%;
		color: #fff;
		display: inline-block;
		text-align: center;
		line-height: 40upx;
		margin-right: 15upx;
	}

	.common {
		color: #333;
		text-align: center;
		position: absolute;
		right: 25upx;
		top: 0;
		height: 100%;
		line-height: 74upx;
		margin-right: 15upx;
	}

	.commonbtn {
		width: 440upx;
		height: 60upx;
		line-height: 60upx;
		margin-top: 70upx;
		background: #4b559d;
		font-size: 30upx;
		color: #fff;
	}

	.btn-hover {
		color: hsla(0, 0%, 100%, .6);
	}

	.itemcontinaer {
		padding: 25upx 50upx;
		background: #fff;
		position: relative;
		height: 600upx;
		overflow: hidden;
	}

	.titleitem {
		width: 100%;
		height: 80upx;
		background: #fff;
		font-size: 34upx;
		text-align: center;
		color: #000;
		line-height: 80upx;
		position: relative;
		font-weight: 600;
	}

	.iteltitle {
		color: #4b559d;
		font-size: 28upx;
		font-weight: 600;
		margin-bottom: 15upx;
	}

	.itemli {
		margin-bottom: 35upx;
	}

	.itemcontent {
		font-size: 24upx;
		color: #333;
		margin-bottom: 15upx;
	}

	.radio {
		width: 20%;
		height: 70upx;
		display: block;
		line-height: 70upx;
	}

	.itemcheack {
		font-size: 24upx;
		display: flex;
	}


	.radioitem {
		transform: scale(0.7);
	}

	.section {
		display: flex;
		align-items: center;
		position: relative;
		margin-bottom: 20upx;
	}

	.section__input {
		flex: 1;
		font-size: 24upx;
		position: relative;
	}

	.section__title {
		font-size: 28upx;
	}
</style>
