<template>
	<view>
		<view class="content">
			<form @submit="submit">
				<view class="inputitem">
					<view class="inputtitle">
						企业名称:
					</view>
					<input class="initem" type="text" name='qyname' :value="info.qyname?info.qyname:'无'" />
				</view>
				<view class="inputitem">
					<view class="inputtitle">
						企业地址:
					</view>
					<input class="initem" type="text" name='qyadress' :value="info.qydz?info.qydz:'无'" />
				</view>
				<view class="inputitem">
					<view class="inputtitle">
						联系人:
					</view>
					<input class="initem" type="text" name='qyfa' :value="info.qyfr?info.qyfr:'无'" />
				</view>
				<view class="inputitem">
					<view class="inputtitle">
						联系方式:
					</view>
					<input class="initem" type="text" name='qyfatel' :value="info.frtel?info.frtel:'无'" />
				</view>
				<view class="inputitem">
					<view class="inputtitle">
						许可证号:
					</view>
					<input class="initem" type="text" name='qyxk' :value="info.xkz?info.xkz:'无'" />
				</view>
				<view class="inputitem">
					<view class="inputtitle">
						检查次数:
					</view>
					<view class="ci">
						本年度第
						<input class="initem cii" type="text" name="jnum" value="" />次检查
					</view>
				</view>
				<button class="btn" hover-class="btn-hover" form-type="submit">下一步</button>
			</form>
		</view>
	</view>
</template>

<script>
	import commonInfo from "@/common/common.js"
	export default {
		data() {
			return {
				formtype: '',
				jnum: '',
				info: ""
			}
		},
		onLoad: function(res) {
			this.info = commonInfo.userinfo.qyinfo
			/* 从全局变量中取 */
			let allobj = commonInfo.userinfo.daily.data.values;
			this.formtype = commonInfo.userinfo.daily.templateCode
			for (let i in allobj) {
				if (allobj[i].name == "企业ID") {
					allobj[i].value = commonInfo.userinfo.qyinfo.qyid
				} else if (allobj[i].name == "所属区域") {
					allobj[i].value = commonInfo.userinfo.qyinfo.qyzs
				}
			}
		},
		methods: {
			back: function() {
				uni.navigateBack()
			},
			submit: function(e) {
				let allobj = commonInfo.userinfo.daily.data.values;
				var reg = /^\d+$|^\d+[.]?\d+$/;
				if (!reg.test(e.detail.value.jnum)) {
					uni.showToast({
						title: "请输入正确的检查次数",
						icon: "none"
					})
					return false;
				}
				for (let i in allobj) {
					if (allobj[i].name == "检查次数") {
						allobj[i].value = e.detail.value.jnum
					} else if (allobj[i].name == "名称") {
						allobj[i].value = e.detail.value.qyname
					} else if (allobj[i].name == "地址") {
						allobj[i].value = e.detail.value.qyadress
					} else if (allobj[i].name == "联系人") {
						allobj[i].value = e.detail.value.qyfa
					} else if (allobj[i].name == "联系方式") {
						allobj[i].value = e.detail.value.qyfatel
					} else if (allobj[i].name == "许可证编号") {
						allobj[i].value = e.detail.value.qyxk
					}
				}
				uni.navigateTo({
					url: "../fillresult/fillresult",
				});
			}
		}
	}
</script>

<style>
	page {
		background: #fff;
	}
	.content {
		padding: 20upx 40upx;
	}

	.inputitem {
		display: flex;
		padding: 10upx 0;
		font-size: 28upx;
		margin-bottom: 5upx;
	}

	.inputtitle {
		width: 200upx;
	}

	.initem {
		border-bottom: 1px solid #0a0a0a;
		flex: 1;
		padding-left: .2em;
		font-size: 28upx;
		color: #656565;
	}

	.btn {
		width: 440upx;
		height: 60upx;
		line-height: 60upx;
		margin-top: 70upx;
		background: #4b559d;
		font-size: 30upx;
		color: #fff;
	}

	.btn-hover {
		color: hsla(0, 0%, 100%, .6);
	}


	.ci {
		display: flex;
		flex: 1;
	}

	.initem.cii {
		flex: 0.5;
		text-align: center;
	}
</style>
