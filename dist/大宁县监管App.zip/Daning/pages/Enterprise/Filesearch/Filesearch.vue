<template>
	<view>
		<view class="formbox">
			<form @submit="formadd" @reset="">
				<view class="foritem">
					<view class="ftitle">
						企业类型
					</view>
					<view class="finput">
						<picker class="fpick" name="qtype" mode="selector" :value="index" :range="arrlist" @change="pickerchange">
							<view>{{arrlist[index]}}</view>
						</picker>
						<view class="iconfont icon-xiala xiala"></view>
					</view>
				</view>
				<view class="foritem">
					<view class="ftitle">
						企业名称
					</view>
					<view class="finput">
						<input type="text" name="qname" value="" placeholder="--请输入企业名称--" />
					</view>
				</view>
				<view class="foritem">
					<view class="ftitle">
						企业法人
					</view>
					<view class="finput">
						<input type="text" name="legend" value="" placeholder="--请输入企业法人--" />
					</view>
				</view>
				<button class="btn" form-type="submit">搜索</button>
			</form>
		</view>
	</view>
</template>

<script>
	import api from "@/api/api.js"
	var type;
	export default {
		data() {
			return {
				arrlist: ['全部企业', '餐饮服务', '食品销售', '食品生产'],
				index: 0,
				entType: 'RepastService',
				colum: ''
			}
		},
		onLoad: function(res) {
			this.colum = res.colum;
		},
		methods: {
			pickerchange: function(e) {
				this.index = e.detail.value;
			},
			formadd: function(e) {
				if (e.detail.value.qtype == 0) {
					type = ''
				} else if (e.detail.value.qtype == 1) {
					type = 'RepastService'
				} else if (e.detail.value.qtype == 2) {
					type = 'FoodSales'
				} else if (e.detail.value.qtype == 3) {
					type = 'FoodProduction'
				}
				let userurl = api.apiUrle + '/getEntListServlet';
				let dataobjj = {
					entType: type,
					entName: e.detail.value.qname,
					legalPerson: e.detail.value.legend,
				}
				let userype = 'GET'

				uni.navigateTo({
					url: "Fileresult/Fileresult?colum=" + this.colum + "&obj=" + JSON.stringify(dataobjj) + ""
				})

			}
		}
	}
</script>

<style>
	page {
		box-sizing: border-box;
	}

	view {
		box-sizing: border-box;
	}

	.formbox {
		font-size: 26upx;
		padding: 5%;
	}

	.foritem {
		margin-bottom: 30upx;
	}

	.ftitle {
		font-weight: 600;
	}

	.finput {
		position: relative;
		border: 0.5px solid grey;
		outline: none;
		border-radius: 20upx;
		flex: 1;
		margin: 15upx 0;
		height: 60upx;
	}

	.finput input {
		height: 100%;
		font-size: 24upx;
		padding-left: 2em;
	}

	.fpick {
		padding-left: 2em;
		font-size: 24upx;
		flex: 1;
		height: 100%;
		display: flex;
		align-items: center;
	}

	.fpick view {
		font-size: 24upx;
		width: 100%;
		height: 100%;
		display: flex;
		align-items: center;
	}

	.xiala {
		position: absolute;
		top: 0;
		right: 30rpx;
		line-height: 1.5;
	}

	.btn {
		width: 242px;
		height: 33px;
		line-height: 33px;
		margin-top: 38px;
		background: #4b559d;
		font-size: 16px;
		color: #fff;
	}
</style>
