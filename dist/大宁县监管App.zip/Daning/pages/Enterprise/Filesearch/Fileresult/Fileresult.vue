<template>
	<view>
		<mescroll-uni :top="20" :down="downOption" @down="downCallback" :up="upOption" @up="upCallback" @init="mescrollInit">
			<block v-if="colum == 'daily'">
				<common :list="pdList" :foodtype='entType' :Jur="haslist"></common>
			</block>
			<block v-else-if="colum == 'punish' ">
				<comon :list="pdList" :foodtype='entType' :Jur="haslist"></comon>
			</block>
			<block v-else-if="colum == 'enter' ">
				<enter :list="pdList" :foodtype='entType' :Jur="haslist"></enter>
			</block>
		</mescroll-uni>
	</view>
</template>

<script>
	import url from "@/common/common.js"
	import api from "@/api/api.js"
	import MescrollUni from "@/component/mescroll-uni/mescroll-uni.vue";
	import Common from "@/component/other/common.vue";
	import comon from "@/component/other/comon.vue";
	import Enter from "@/component/other/enter.vue";
	export default {
		components: {
			MescrollUni,
			Enter,
			Common,
			comon
		},
		data() {
			return {
				mescroll: null, //mescroll实例对象
				downOption: {
					// use: false // 不使用下拉刷新
				},
				upOption: {
					auto: false, //是否在初始化后,自动执行上拉回调callback; 默认true
					// page: {
					// 	num: 0, // 当前页码,默认0,回调之前会加1,即callback(page)会从1开始
					// 	size: 10 // 每页数据的数量
					// }
					noMoreSize: 3, //如果列表已无数据,可设置列表的总数量要大于半页才显示无更多数据;避免列表数据过少(比如只有一条数据),显示无更多数据会不好看
					empty: {
						tip: '~ 搜索无结果 ~' // 提示
					}
				},
				pdList: [],
				type: '',
				entType: '', //企业档案类型
				dataobj: '',
				colum: '',
				haslist: "true"
			}
		},
		onLoad: function(res) {
			this.colum = res.colum;
			this.dataobj = JSON.parse(res.obj)
			let userinfo = url.userinfo.info;
			// 局领导
			if (userinfo.postId == '5716948556706694426' || userinfo.postId == '5716948556706694426') {
				this.haslist = 'false';
			} else {
				this.haslist = 'true';
			}
		},
		methods: {
			// mescroll组件初始化的回调,可获取到mescroll对象
			mescrollInit(mescroll) {
				this.mescroll = mescroll;
			},
			/*下拉刷新的回调 */
			downCallback(mescroll) {
				mescroll.resetUpScroll()
			},
			/*上拉加载的回调: mescroll携带page的参数, 其中num:当前页 从1开始, size:每页数据条数,默认10 */
			upCallback(mescroll) {
				// 先清空列表,显示加载进度
				if (mescroll.num == 0) this.pdList = []; //如果是第一页需手动制空列表
				//联网加载数据
				mescroll.size = 15;
				this.getListDataFromNet(this.curWord, mescroll.num, mescroll.size, (curPageData) => {
					//联网成功的回调,隐藏下拉刷新和上拉加载的状态;
					mescroll.endSuccess(curPageData.length);
					//追加新数据
					this.pdList = this.pdList.concat(curPageData);
					console.log(this.pdList)
				}, () => {
					//联网失败的回调,隐藏下拉刷新的状态
					mescroll.endErr();
				})
			},
			getListDataFromNet(curWord, pageNum, pageSize, successCallback, errorCallback) {
				var that = this;
				//延时一秒,模拟联网
				let userurl = api.apiUrle + '/getEntListServlet';
				this.dataobj.pageIndex = pageNum + 1;
				this.dataobj.pageSize = pageSize;
				this.dataobj.memberID = url.userinfo.info.memberId;
				let dataobj = this.dataobj;
				let userype = 'GET';
				api.getToken(userurl, dataobj, userype, (res) => {
					console.log(res)
					var curPageData
					if (res.data) {
						curPageData = res.data;
					} else if (res) {
						curPageData = res;
					}
					var listData = [];
					if (!curPageData.length) {
						listData = listData.concat(curPageData);
					} else {
						for (let i = 0; i < curPageData.length; i++) {
							listData.push(curPageData[i]);
						}
					}
					//模拟分页数据
					successCallback && successCallback(listData);
				});

			}
		}
	}
</script>

<style>
	page {
		background: #fff;
	}

	.add {
		text-align: right;
		color: #4b559d;
		font-size: 26upx;
		font-weight: 600;
		padding: 20upx 20upx 10upx 20upx;
	}
</style>
