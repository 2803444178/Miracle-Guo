<template>
	<view>
		<view class="fheader">
			<view class="fhead">
				<view class="ftitle xiao" v-if="info.qylx == '食品销售'">销</view>
				<view class="ftitle can" v-else-if="info.qylx == '餐饮服务'">餐</view>
				<view class="ftitle sheng" v-else>生</view>
				<view class="fcontent">
					{{info.qyname}}
				</view>
			</view>
		</view>
		<view class="fcont">
			<view class="content">
				<view class="fcontitem">
					企业名称：{{info.qyname? info.qyname : '无'}}
				</view>
				<view class="fcontitem">
					企业类型：{{info.qylx? info.qylx : '无'}}
				</view>
				<view class="fcontitem">
					所属站所：{{info.qyzs? info.qyzs : '无'}}
				</view>
				<view class="fcontitem">
					法人/负责人：{{info.qyfr? info.qyfr : '无'}}
				</view>
				<view class="fcontitem">
					联系电话：{{info.frtel? info.frtel : '无'}}
				</view>
				<view class="fcontitem">
					企业地址：{{info.qydz? info.qydz : '无'}}
				</view>
			</view>
			<view class="commonti">
				<view class="line">|</view>企业详情
			</view>
		</view>
		<view class="itemize_boxe">
			<view class="itemize">
				<view class="itemize_item" hover-class="uni-list-cell-hover" v-on:tap="godetails('/legalPersonInfoServlet','fa')">
					<view class="imgbox">
						<view class="iconfont icon-farendaibiao xiala iconii"></view>
					</view>
					<text>法人信息</text>
				</view>
				<view class="itemize_item" hover-class="uni-list-cell-hover" v-on:tap="godetails('/licenseInfoServlet','xk')">
					<view class="imgbox">
						<view class="iconfont icon-hangzhengxuke xiala iconii"></view>
					</view>
					<text>许可信息</text>
				</view>
				<view class="itemize_item" hover-class="uni-list-cell-hover" v-on:tap="godetails('/businessLicenseServlet','yy')">
					<view class="imgbox">
						<view class="iconfont icon-yingyezhizhao xiala iconii"></view>
					</view>
					<text>营业执照</text>
				</view>
				<view class="itemize_item" hover-class="uni-list-cell-hover" v-on:tap="godetails('/getEntMemberServlet','ry')">
					<view class="imgbox">
						<view class="iconfont icon-renyuanbianzhi xiala iconii"></view>
					</view>
					<text>人员信息</text>
				</view>
				<view class="itemize_item" hover-class="uni-list-cell-hover" v-on:tap="gosearch()">
					<view class="imgbox">
						<view class="iconfont icon-jiancha xiala iconii"></view>
					</view>
					<text>日常检查</text>
				</view>
				<view class="itemize_item" hover-class="uni-list-cell-hover" v-on:tap="gosearchA()">
					<view class="imgbox">
						<view class="iconfont icon-xiafachufa xiala iconii"></view>
					</view>
					<text>行政处罚</text>
				</view>
				<view class="itemize_item" hover-class="uni-list-cell-hover" v-on:tap="gosearchA()">
					<view class="imgbox">
						<view class="iconfont icon-shishishipinjiankong xiala iconii"></view>
					</view>
					<text>视频监控</text>
				</view>
			</view>
		</view>
	</view>
</template>

<script>
	import commonInfo from "@/common/common.js";
	export default {
		data() {
			return {
				info: ""
			}
		},
		onLoad: function(res) {
			this.info = commonInfo.userinfo.qyinfo;
		},
		methods: {
			godetails: function(url, type) {
				uni.navigateTo({
					url: "./Filede/Filede?&url=" + url + "&type=" + type + ""
				})
			},
			godetai: function() {
				uni.navigateTo({
					url: "./File/File"
				})
			},
			gosearch: function(type, str) {
				uni.navigateTo({
					url: "./FileList/FileList"
				})
			},
			gosearchA: function(type, str) {
				uni.navigateTo({
					url: "./FileListA/FileListA"
				})
			},
		}
	}
</script>

<style>
	view {
		box-sizing: border-box;
	}

	.fheader {
		background: #4b559d;
		height: 100upx;
		position: relative;
	}

	.fhead {
		background: #fff;
		width: 80%;
		min-height: 100upx;
		display: flex;
		margin: 0 auto;
		padding: 10upx 20upx;
		align-items: center;
		font-size: 36upx;
		font-weight: 600;
		position: absolute;
		left: 10%;
		top: 40upx;
		box-shadow: 0px 0px 5px #888888;
		border-radius: 10upx;
	}

	.iconii {
		font-size: 30px;
		color: #4b559d;
	}

	.ftitle {
		width: 60upx;
		height: 60upx;
		color: #fff;
		text-align: center;
		border-radius: 50%;
		line-height: 60upx;
	}

	.ftitle.xiao {
		background: #b296eb;
	}

	.ftitle.sheng {
		background: #699ee2;
	}

	.ftitle.can {
		background: #74d7a9;
	}

	.fcontent {
		padding-left: 20upx;
	}

	.fcont {
		padding: 10% 10% 2%;
		font-size: 28upx;
		color: #333;
	}

	.content {
		border-bottom: 0.5px solid #666;
	}

	.fcontitem {
		margin-bottom: 15upx;
	}

	.commonti {
		font-weight: 600;
		padding: 30upx 0;
		display: flex;
		align-items: center;
	}

	.commonti .line {
		font-weight: 600;
		color: #4b80e8;
		margin-right: 10upx;
	}

	.itemize_box {
		width: 100%;
		background: #FFFFFF;
		margin: 0 auto 25upx;
		border-radius: 15upx;
	}

	.itemize_boxe {
		width: 100%;
		background: #FFFFFF;
		margin: 0 auto;
		border-radius: 15upx;
		margin-bottom: 30upx;
		padding: 0 5%;
	}

	.itemize {
		display: flex;
		justify-content: flex-start;
		flex-wrap: wrap;
		align-items: center;
	}

	.itemize_item {
		width: 25%;
		display: flex;
		flex-direction: column;
		justify-content: center;
		align-items: center;
		font-size: 24upx;
		padding: 25rpx 0;
	}


	.itemize_item .imgbox {
		width: 100upx;
		height: 100upx !important;
		margin-bottom: 10upx;
		border-radius: 50%;
		padding: 10upx;
		background: #e4eeff;
		display: flex;
		justify-content: center;
		align-items: center;
	}

	.itemize_item image {
		width: 100%;
		height: 100% !important;
	}

	.itemize_item text {
		font-size: 24upx;
		color: #2f2f2f;
		margin-top: 10upx;
	}
</style>
