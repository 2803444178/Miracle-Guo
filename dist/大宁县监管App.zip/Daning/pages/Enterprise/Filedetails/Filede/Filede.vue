<template>
	<view>
		<view class="fheader">
			<view class="fhead">
				<view class="ftitle xiao" v-if="qylx == '食品销售'">销</view>
				<view class="ftitle can" v-else-if="qylx == '餐饮服务'">餐</view>
				<view class="ftitle sheng" v-else>生</view>
				<view class="fcontent">
					{{qyname}}
				</view>
			</view>
		</view>
		<view class="fcont" v-if="info && info.length != 0">
			<view v-if="Infotype == 'fa'">
				<view class="content">
					<view class="fcontitem">
						<view class="fonw">
							企业名称：
						</view>
						{{info['企业名称']}}
					</view>
					<view class="fcontitem">
						<view class="fonw">
							法人姓名：
						</view>
						{{info['姓名']}}
					</view>
					<view class="fcontitem">
						<view class="fonw">
							出生年月：
						</view>
						{{info['出生年月']}}
					</view>
					<view class="fcontitem">
						<view class="fonw">
							身份证号码：
						</view>
						{{info['身份证号码']}}
					</view>
					<view class="fcontitem">
						<view class="fonw">
							联系电话：
						</view>
						{{info['联系电话']}}
					</view>
					<view class="fcontitem">
						<view class="fonw">
							学历：
						</view>
						{{info['学历']}}
					</view>
					<view class="fcontitem">
						<view class="fonw">
							通讯地址：
						</view>
						{{info['通讯地址']}}
					</view>
					<view class="fcontitem">
						<view class="fonw">
							餐具消毒方式：
						</view>
						{{info['企业名称']}}
					</view>
				</view>
			</view>
			<view v-else-if="Infotype == 'xk'">
				<view class="content">
					<view class="fcontitem">
						<view class="fonw">
							企业名称：
						</view>
						{{info['企业名称']}}
					</view>
					<view class="fcontitem">
						<view class="fonw">
							证书编号：
						</view>
						{{info['证书编号']}}
					</view>
					<view class="fcontitem">
						<view class="fonw">
							发证机关：
						</view>
						{{info['发证机关']}}
					</view>
					<view class="fcontitem">
						<view class="fonw">
							发证日期：
						</view>
						{{info['发证日期']? info['发证日期'].replace(/.........[0-9]*$/,'') : '无'}}
					</view>
					<view class="fcontitem">
						<view class="fonw">
							有效期至：
						</view>
						{{info['有效期至']? info['有效期至'].replace(/.........[0-9]*$/,'') : '无'}}
					</view>
				</view>
			</view>
			<view v-else-if="Infotype == 'yy'">
				<view class="content">
					<view class="fcontitem">
						<view class="fonw">
							企业名称：
						</view>
						{{info['企业名称']}}
					</view>
					<view class="fcontitem">
						<view class="fonw">
							注册地址：
						</view>
						{{info['注册地址']}}
					</view>
					<view class="fcontitem">
						<view class="fonw">
							注册号：
						</view>
						{{info['注册号']}}
					</view>
					<view class="fcontitem">
						<view class="fonw">
							经营范围：
						</view>
						{{info['经营范围']}}
					</view>
					<view class="fcontitem">
						<view class="fonw">
							发证机关：
						</view>
						{{info['发证机关']}}
					</view>
					<view class="fcontitem">
						<view class="fonw">
							成立日期：
						</view>
						{{info['成立日期']? info['成立日期'].replace(/.........[0-9]*$/,'') : '无'}}
					</view>
				</view>
			</view>
			<view v-else-if="Infotype == 'ry'">
				<view v-for="(item,index) in info" :key="index">
					<view class="content mbo">
						<view class="fcontitem">
							<view class="fonw">
								企业名称：
							</view>
							{{item['企业名称']}}
						</view>
						<view class="fcontitem">
							<view class="fonw">
								姓名：
							</view>
							{{item['姓名']}}
						</view>
						<view class="fcontitem">
							<view class="fonw">
								人员类别-法人：
							</view>
							{{item['人员类别-法人']}}
						</view>
						<view class="fcontitem">
							<view class="fonw">
								出生年月：
							</view>
							{{item['出生年月']}}
						</view>
						<view class="fcontitem">
							<view class="fonw">
								身份证号码：
							</view>
							{{item['身份证号码']}}
						</view>
						<view class="fcontitem">
							<view class="fonw">
								性别：
							</view>
							{{item['性别']}}
						</view>
						<view class="fcontitem">
							<view class="fonw">
								联系电话：
							</view>
							{{item['联系电话']}}
						</view>
						<view class="fcontitem">
							<view class="fonw">
								学历：
							</view>
							{{item['学历']}}
						</view>
						<view class="fcontitem">
							<view class="fonw">
								通讯地址：
							</view>
							{{item['通讯地址']}}
						</view>
					</view>
				</view>
			</view>
		</view>
		<view class="empty" v-else>
			<view class="empty-img">
				<image src="http://www.mescroll.com/img/mescroll-empty.png" mode="widthFix"></image>
			</view>
			<view class="empty-title">
				暂无相关信息
			</view>
		</view>
	</view>
</template>

<script>
	import api from "@/api/api.js";
	import commonInfo from "@/common/common.js";
	export default {
		data() {
			return {
				Infotype: '',
				info: "",
				qylx: "",
				qyname: ''
			}
		},
		onLoad: function(res) {
			//获取用户信息
			let userurl = api.apiUrle + res.url;
			this.qylx = commonInfo.userinfo.qyinfo.qylx;
			this.qyname = commonInfo.userinfo.qyinfo.qyname;
			console.log(this.qyname)
			let dataobjj = {
				id: commonInfo.userinfo.qyinfo.qyid
			}
			this.Infotype = res.type;
			if (res.type == 'fa') {
				uni.setNavigationBarTitle({
					title: '法人信息'
				})
			} else if (res.type == 'xk') {
				uni.setNavigationBarTitle({
					title: '许可信息'
				})
			} else if (res.type == 'yy') {
				uni.setNavigationBarTitle({
					title: '营业执照'
				})
			} else if (res.type == 'ry') {
				uni.setNavigationBarTitle({
					title: '人员信息'
				})
			}
			let userype = 'GET'
			api.getToken(userurl, dataobjj, userype, (res) => {
				console.log(res);
				this.info = res;
			});
		},
		methods: {

		}
	}
</script>

<style>
	view {
		box-sizing: border-box;
	}

	.fheader {
		background: #4b559d;
		height: 100upx;
		position: relative;
	}

	.fhead {
		background: #fff;
		width: 80%;
		height: 100upx;
		display: flex;
		margin: 0 auto;
		padding: 10upx 20upx;
		align-items: center;
		font-size: 36upx;
		font-weight: 600;
		position: absolute;
		left: 10%;
		top: 40upx;
		box-shadow: 0px 0px 5px #888888;
		border-radius: 10upx;
	}

	.ftitle {
		width: 60upx;
		height: 60upx;
		color: #fff;
		text-align: center;
		border-radius: 50%;
		line-height: 60upx;
	}

	.ftitle.xiao {
		background: #b296eb;
	}

	.ftitle.sheng {
		background: #699ee2;
	}

	.ftitle.can {
		background: #74d7a9;
	}

	.fcontent {
		padding-left: 20upx;
	}

	.fcont {
		padding: 10% 10% 2%;
		font-size: 28upx;
		color: #333;
	}

	.fcontitem {
		margin-bottom: 15upx;
		display: flex;
	}

	.fonw {
		font-weight: 600;
	}

	.mbo {
		margin-bottom: 50upx;
	}

	.empty {
		margin: 200upx auto;
		display: flex;
		justify-content: center;
		flex-direction: column;
		align-items: center;
	}

	.empty-img {
		width: 300upx;
		height: 300upx;
	}

	.empty-img image {
		width: 100%;
	}

	.empty-title {
		font-size: 30upx;
		color: #4b559d;
	}
</style>
