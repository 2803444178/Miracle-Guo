<template>
	<view>
		<view class="fheader">
			<view class="fhead">
				<view class="ftitle xiao" v-if="info.qylx == '食品销售'">销</view>
				<view class="ftitle can" v-else-if="info.qylx == '餐饮服务'">餐</view>
				<view class="ftitle sheng" v-else>生</view>
				<view class="fcontent">
					{{info.qyname}}
				</view>
			</view>
		</view>
		<view class="fcont">
			<mescroll-body ref="mescrollRef" @init="mescrollInit" @down="downCallback" :up="upOption" @up="upCallback"
			 @emptyclick="emptyClick">
				<!-- 数据列表 -->
				<FilsList :list="pdList" :foodtype='entType' :Jur='haslist'></FilsList>
			</mescroll-body>
		</view>
	</view>
</template>

<script>
	import api from "@/api/api.js";
	import commonInfo from "@/common/common.js";
	import MescrollMixin from "@/component/mescroll-uni/mescroll-mixins.js";
	import {
		apiSearch
	} from "@/api/mock.js"
	import FilsList from "@/component/other/FilsList.vue";
	export default {
		mixins: [MescrollMixin], // 使用mixin (在main.js注册全局组件)
		components: {
			FilsList
		},

		data() {
			return {
				upOption: {
					auto: false, //是否在初始化后,自动执行上拉回调callback; 默认true
					// page: {
					// 	num: 0, // 当前页码,默认0,回调之前会加1,即callback(page)会从1开始
					// 	size: 10 // 每页数据的数量
					// }
					noMoreSize: 3, //如果列表已无数据,可设置列表的总数量要大于半页才显示无更多数据;避免列表数据过少(比如只有一条数据),显示无更多数据会不好看
					empty: {
						use: true, // 是否显示空布局
						icon: "http://www.mescroll.com/img/mescroll-empty.png", // 图标路径
						tip: '~ 暂无相关数据 ~', // 提示
						btnText: '日常检查填报', // 按钮
						fixed: false, // 是否使用fixed定位,默认false; 配置fixed为true,以下的top和zIndex才生效 (transform会使fixed失效,最终会降级为absolute)
						top: "100rpx", // fixed定位的top值 (完整的单位值,如 "10%"; "100rpx")
						zIndex: 99 // fixed定位z-index值
					},
				},
				pdList: [],
				type: '',
				entType: '', //企业档案类型
				entName: '',
				haslist: 'true',
				info: "",
				listinfo: null
			}
		},
		onLoad: function(res) {

		},
		methods: {
			upCallback(page) {
				if (commonInfo) {
					this.info = commonInfo.userinfo.qyinfo;
					console.log(commonInfo)
					let data = {};
					data.type = 'DailyCheck';
					data.id = commonInfo.userinfo.qyinfo.qyid;
					apiSearch(page.num, page.size, data).then(curPageData => {
						console.log(curPageData)
						//联网成功的回调,隐藏下拉刷新和上拉加载的状态;
						this.mescroll.endSuccess(curPageData.length);
						//设置列表数据
						if (page.num == 1) this.pdList = []; //如果是第一页需手动制空列表
						let list = this.pdList.concat(curPageData);
						for (let i in list) {
							if (list[i].STATE == 0) {
								list[i].STATE = '进行中'
							} else if (list[i].STATE == 1) {
								list[i].STATE = '终止结束'
							} else if (list[i].STATE == 2) {
								list[i].STATE = '取消'
							} else if (list[i].STATE == 3) {
								list[i].STATE = '完成'
							} else if (list[i].STATE == 4) {
								list[i].STATE = '被删除'
							}
						}
						this.pdList = list; //追加新数据
					}).catch(() => {
						//联网失败, 结束加载
						this.mescroll.endErr();
					})
				}
			},
			emptyClick() {
				uni.navigateTo({
					url: "../../../fill/fill"
				})
			},
		}
	}
</script>

<style>
	view {
		box-sizing: border-box;
	}

	.fheader {
		background: #4b559d;
		height: 100upx;
		position: relative;
	}

	.fhead {
		background: #fff;
		width: 80%;
		height: 100upx;
		display: flex;
		margin: 0 auto;
		padding: 10upx 20upx;
		align-items: center;
		font-size: 36upx;
		font-weight: 600;
		position: absolute;
		left: 10%;
		top: 40upx;
		box-shadow: 0px 0px 5px #888888;
		border-radius: 10upx;
	}

	.ftitle {
		width: 60upx;
		height: 60upx;
		color: #fff;
		text-align: center;
		border-radius: 50%;
		line-height: 60upx;
	}

	.ftitle.xiao {
		background: #b296eb;
	}

	.ftitle.sheng {
		background: #699ee2;
	}

	.ftitle.can {
		background: #74d7a9;
	}

	.fcontent {
		padding-left: 20upx;
	}

	.fcont {
		background: #F4F5F6;
		padding: 10% 20upx 2%;
		font-size: 11px;
		color: #333;
	}
</style>
