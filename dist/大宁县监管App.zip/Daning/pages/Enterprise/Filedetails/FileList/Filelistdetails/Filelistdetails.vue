<template>
	<view>
		<view class="content" v-if="qytype == '餐饮服务' && qyFromInfo">
			<view class="tablebox">
				<view class="tablelist">
					<view class="tabletitle">
						名称
					</view>
					|
					<view class="tablecontent">
						{{qyFromInfo['名称']}}
					</view>
				</view>
				<view class="tablelist">
					<view class="tabletitle">
						地址
					</view>

					|
					<view class="tablecontent">
						{{qyFromInfo['地址']}}
					</view>
				</view>
				<view class="tablelist">
					<view class="tabletitle">
						联系人
					</view>

					|
					<view class="tablecontent">
						{{qyFromInfo['联系人']}}
					</view>
				</view>
				<view class="tablelist">
					<view class="tabletitle">
						联系方式
					</view>
					|
					<view class="tablecontent">
						{{qyFromInfo['联系方式']}}
					</view>
				</view>
				<view class="tablelist">
					<view class="tabletitle">
						许可证号
					</view>
					|
					<view class="tablecontent">
						{{qyFromInfo['许可证编号']}}
					</view>
				</view>
				<view class="tablelist">
					<view class="tabletitle">
						检查次数
					</view>

					<view class="tablecontent">
						本年度第{{qyFromInfo['检查次数']}}次检查
					</view>
				</view>
			</view>
			<view class="titiel">
				检查内容
			</view>
			<view class="totcontent">
				<view class="tiiit">
					<view class="initem">{{qyFromInfo['检查部门']}}</view>
					检察人员根据《中华人民共和国食品安全法》及实施条例、
					《食品生产经营日常监督检查管理办法的规定》，于
					<view class="initem">{{qyFromInfo['检查时间'].replace(/.........[0-9]*$/,'')}}</view>
					对你单位进行了监督检查，
					本次监督检查按照表开展，共检查了
					<view class="initem">{{qyFromInfo['检查项数']}}</view>
					项内容，其中：
				</view>
				<view class="tiiit">
					<view class="title">
						重点项：<view class="initem listiem">{{qyFromInfo['重点项数'] }}</view>项
					</view>
					<view class="title tfle">
						项目序号分别是：<view class="initem listiem">
							{{qyFromInfo['重点项序号'] ? qyFromInfo['重点项序号'] :''}}
						</view>
					</view>
					<view class="title">
						发现问题：<view class="initem listiem">{{qyFromInfo['重点问题中发现问题项数']}}</view>项
					</view>
					<view class="title tfle">
						项目序号分别是：
						<view class="initem listiem">
							{{qyFromInfo['重点项中发现问题项序号'] ? qyFromInfo['重点项中发现问题项序号'] :''}}
						</view>
					</view>
				</view>
				<view class="tiiit">
					<view class="title">
						一般项：<view class="initem listiem">{{qyFromInfo['一般项数']}}</view>项
					</view>
					<view class="title tfle">
						项目序号分别是：<view class="initem listiem">
							{{qyFromInfo['一般项序号']}}
						</view>
					</view>
					<view class="title">
						发现问题：<view class="initem ">{{qyFromInfo['一般项发现问题项数']}}</view>项
					</view>
					<view class="title tfle">
						项目序号分别是：<view class="initem listiem">
							{{qyFromInfo['一般项发现问题序号']? qyFromInfo['一般项发现问题序号'] :''}}
						</view>
					</view>
				</view>
			</view>
			<view class="tablebox">
				<view class="tablelist">
					<view class="tabletitle">
						检查结果
					</view>
					|
					<view class="tablecontent">
						{{qyFromInfo['检查结果']}}
					</view>
				</view>

				<view class="tablelist">
					<view class="tabletitle">
						结果处理
					</view>
					|
					<view class="tablecontent">
						{{qyFromInfo['结果处理']}}
					</view>
				</view>
				<view class="tablelist form" v-if="qyFromInfo['结果处理'] == '书面整改'">
					<view class="tabletitle" @tap="details" data-id='201917' data-title="现场笔录">
						现成笔录
					</view>
					|
					<view class="tabletitle" @tap="details" data-id='201918' data-title="责令改正通知书">
						责令改正通知书
					</view>
				</view>
				<view class="tablelist form" v-if="qyFromInfo['结果处理'] == '停业整顿'">
					<view class="tabletitle">
						现成笔录
					</view>
					|
					<view class="tabletitle">
						立案（不予立案）审批表
					</view>
				</view>
				<view class="tablelist">
					<view class="tabletitle">
						执法定位
					</view>

					|
					<view class="tablecontent">
						{{qyFromInfo['执法定位']}}
					</view>
				</view>
				<view class="tablelist">
					<view class="tabletitle">
						说明
					</view>

					|
					<view class="tablecontent">
						{{qyFromInfo['说明']}}
					</view>
				</view>
			</view>
			<view v-if="qyFromInfo['执法人员签名']">
				<view class="titiel">
					执法人员签名
				</view>
				<view class="fubox">
					<image :src="qyFromInfo['执法人员签名'] " mode="aspectFill"></image>
				</view>
			</view>
			<view v-if="qyFromInfo['法人负责人签字']">
				<view class="titiel">
					法人负责人签字
				</view>
				<view class="fubox">
					<image :src="qyFromInfo['法人负责人签字'] " mode="aspectFill"></image>
				</view>
			</view>
			<view v-if="fuurl">
				<view class="titiel">
					附件
				</view>
				<view class="fubox">
					<image v-for="(item,index) in fuurl" :key="index" :src="item" mode="aspectFill" ></image>
				</view>
			</view>
		</view>
		<view class="content" v-if="qytype == '食品销售' && qyFromInfo">
			<view class="tablebox">
				<view class="tablelist">
					<view class="tabletitle">
						名称
					</view>
					|
					<view class="tablecontent">
						{{qyFromInfo['名称']}}
					</view>
				</view>
				<view class="tablelist">
					<view class="tabletitle">
						地址
					</view>

					|
					<view class="tablecontent">
						{{qyFromInfo['地址']}}
					</view>
				</view>
				<view class="tablelist">
					<view class="tabletitle">
						联系人
					</view>
					|
					<view class="tablecontent">
						{{qyFromInfo['联系人']}}
					</view>
				</view>
				<view class="tablelist">
					<view class="tabletitle">
						联系方式
					</view>
					|
					<view class="tablecontent">
						{{qyFromInfo['联系方式']}}
					</view>
				</view>
				<view class="tablelist">
					<view class="tabletitle">
						许可证号
					</view>
					|
					<view class="tablecontent">
						{{qyFromInfo['许可证编号']}}
					</view>
				</view>
				<view class="tablelist">
					<view class="tabletitle">
						检查次数
					</view>

					<view class="tablecontent">
						本年度第{{qyFromInfo['检查次数']}}次检查
					</view>
				</view>
			</view>
			<view class="titiel">
				检查内容
			</view>
			<view class="totcontent">
				<view class="tiiit">
					<view class="initem">{{qyFromInfo['检查食药单位']}}</view>
					检察人员根据《中华人民共和国食品安全法》及实施条例、
					《食品生产经营日常监督检查管理办法的规定》，于
					<view class="initem">{{qyFromInfo['检查日期'].replace(/.........[0-9]*$/,'') }}</view>
					对你单位进行了监督检查，
					本次监督检查按照表开展，共检查了
					<view class="initem">{{qyFromInfo['检查内容项'] ? qyFromInfo['检查内容项'] :'0' }}</view>
					项内容，其中：
				</view>
				<view class="tiiit">
					<view class="title">
						重点项：<view class="initem listiem">{{qyFromInfo['重点项'] }}</view>项
					</view>
					<view class="title tfle">
						项目序号分别是：<view class="initem listiem">
							{{qyFromInfo['重点项序号'] ? qyFromInfo['重点项序号'] :''}}
						</view>
					</view>
					<view class="title">
						发现问题：<view class="initem listiem">{{qyFromInfo['重点项发现问题项']}}</view>项
					</view>
					<view class="title tfle">
						项目序号分别是：
						<view class="initem listiem">
							{{qyFromInfo['重点项发现问题项序号'] ? qyFromInfo['重点项发现问题项序号'] :''}}
						</view>
					</view>
				</view>
				<view class="tiiit">
					<view class="title">
						一般项：<view class="initem listiem">{{qyFromInfo['一般项']}}</view>项
					</view>
					<view class="title tfle">
						项目序号分别是：<view class="initem listiem">
							{{qyFromInfo['一般项项目序号'] ? qyFromInfo['一般项项目序号'] :''}}
						</view>
					</view>
					<view class="title">
						发现问题：<view class="initem ">{{qyFromInfo['一般项发现问题项']}}</view>项
					</view>
					<view class="title tfle">
						项目序号分别是：<view class="initem listiem">
							{{qyFromInfo['一般项发现问题项序号'] ? qyFromInfo['一般项发现问题项序号'] :''}}
						</view>
					</view>
				</view>
			</view>
			<view class="tablebox">
				<view class="tablelist">
					<view class="tabletitle">
						检查结果
					</view>
					|
					<view class="tablecontent">
						{{qyFromInfo['检查结果']}}
					</view>
				</view>
				<view class="tablelist">
					<view class="tabletitle">
						结果处理
					</view>
					|
					<view class="tablecontent">
						{{qyFromInfo['结果处理']}}
					</view>
				</view>
				<view class="tablelist form" v-if="qyFromInfo['结果处理'] == '书面整改'">
					<view class="tabletitle" @tap="details" data-id='201917' data-title="现场笔录">
						现成笔录
					</view>
					|
					<view class="tabletitle" @tap="details" data-id='201918' data-title="责令改正通知书">
						责令改正通知书
					</view>
				</view>
				<view class="tablelist form" v-if="qyFromInfo['结果处理'] == '停业整顿'">
					<view class="tabletitle" @tap="details" data-id='201917' data-title="现场笔录">
						现成笔录
					</view>
					|
					<view class="tabletitle" @tap="details" data-id='201919' data-title="立案（不予立案）审批表">
						立案（不予立案）审批表
					</view>
				</view>
				<view class="tablelist">
					<view class="tabletitle">
						执法定位
					</view>
					|
					<view class="tablecontent">
						{{qyFromInfo['执法定位']}}
					</view>
				</view>
				<view class="tablelist">
					<view class="tabletitle">
						说明
					</view>
					|
					<view class="tablecontent">
						{{qyFromInfo['说明'] ? qyFromInfo['说明'] :''}}
					</view>
				</view>
			</view>
			<view v-if="qyFromInfo['执法人员签名']">
				<view class="titiel">
					执法人员签名
				</view>
				<view class="fubox">
					<image :src="qyFromInfo['执法人员签名']" mode="aspectFill"></image>
				</view>
			</view>
			<view v-if="qyFromInfo['法人负责人签字']">
				<view class="titiel">
					法人负责人签字
				</view>
				<view class="fubox">
					<image :src="qyFromInfo['法人负责人签字'] " mode="aspectFill"></image>
				</view>
			</view>
			<view v-if="fuurl">
				<view class="titiel">
					附件
				</view>
				<view class="fubox">
					<image v-for="(item,index) in fuurl" :key="index" :src="item" mode="aspectFill" ></image>
				</view>
			</view>
		</view>
	</view>
</template>

<script>
	import commonInfo from "@/common/common.js";
	import api from "@/api/api.js";
	var token;
	export default {
		data() {
			return {
				qyFromInfo: null,
				qytype: null,
				canvasurl: null,
				fuurl: []
			}
		},
		onLoad: function(res) {
			// 刷新token
			var that = this;
			//企业类型
			this.qytype = commonInfo.userinfo.qyinfo.qylx;
			uni.request({
				url: 'http://h5.shouyunchina.com:8002/DNServices/businessInfoServlet', //仅为示例，并非真实接口地址。
				data: {
					id: res.id,
					recordId: res.formid
				},
				success: async (data) => {
					if (data.data) {
						let info = data.data;
						info['检查结果'] = info['检查结果'] && this.fillet(info['检查结果']);
						info['结果处理'] = info['结果处理'] && this.fillet(info['结果处理']);
						info['执法定位'] = info['执法定位'] && await this.getadress(info['执法定位']);
						uni.request({
							url: 'http://h5.shouyunchina.com:8002/DNServices/getAttachmentServlet', //仅为示例，并非真实接口地址。
							data: {
								id: res.id,
								recordId: res.formid
							},
							success: async (res) => {
								console.log(res.data)
								let arr = res.data;
								for (let i in arr) {
									if (info['执法人员签名']) {;
										if (arr[i].FILE_URL == info['执法人员签名']) {
											arr.splice(i, 1)
											info['执法人员签名'] = info['执法人员签名'] && await this.getimg(info['执法人员签名']);
										}
									}
									if (info['法人负责人签字']) {
										if (arr[i].FILE_URL == info['法人负责人签字']) {
											arr.splice(i, 1)
											info['法人负责人签字'] = info['法人负责人签字'] && await this.getimg(info['法人负责人签字']);
										}
									}
								}
								let name = commonInfo.userinfo.name
								api.GetNowtoken(name, (res) => {
									uni.hideLoading();
									for (let i in arr) {
										console.log("http://183.203.90.25:8888/seeyon/services/downloadService?token=" + res +
											"&fileId=" + arr[i].FILE_URL + "")
										this.fuurl.push("http://183.203.90.25:8888/seeyon/services/downloadService?token=" + res +
											"&fileId=" + arr[i].FILE_URL + "")
									}

									console.log(this.fuurl)
								});
							}
						});
						this.qyFromInfo = info
					}
				}
			});
		},
		methods: {
			getimg: function(id) {
				return new Promise((resolve, reject) => {
					let name = commonInfo.userinfo.name
					api.GetNowtoken(name, (res) => {
						uni.hideLoading()
						let url = "http://183.203.90.25:8888/seeyon/services/downloadService?token=" + res +
							"&fileId=" + id + "";
						resolve(url)
					});
				})
			},
			getadress: function(id, info) {
				return new Promise((resolve, reject) => {
					uni.request({
						url: 'http://h5.shouyunchina.com:8002/DNServices/getLocationServlet', //仅为示例，并非真实接口地址。
						data: {
							id: id,
						},
						success: res => {
							console.log(res.data.message)
							resolve(res.data.message)
						},
						fail: err => {
							reject(err)
						}
					});
				})
			},
			details: function(e) {
				let title = e.mp.currentTarget.dataset.title;
				let id = e.mp.currentTarget.dataset.id;
				uni.navigateTo({
					url: "../../../../punish/" + id + "/" + id + "?id=" + id + "&&title=" + title + ""
				})
			},
			fillet: function(res) {
				if (res == '8361367595765681198') {
					return '符合'
				} else if (res == '-2066416451667277405') {
					return '基本符合'
				} else if (res == '6571312966818286323') {
					return '不符合'
				} else if (res == '986401131406182056') {
					return '通过'
				} else if (res == '-233736429269465346') {
					return '书面整改'
				} else if (res == '-8708609701263029876') {
					return '停业整顿'
				}
			},
		},
	}
</script>

<style>
	.content {
		padding: 20upx;
	}

	.tablelist {
		font-size: 30upx;
		display: flex;
		padding: 10upx;
		background: #dddddd;
		align-items: center;
	}

	.tablelist.form {
		display: flex;
		padding: 10upx;
	}

	.tablelist.form .tabletitle {
		width: 50%;
		text-align: center;
		text-align-last: auto;

	}

	.tablelist:nth-of-type(2n) {
		background: #fff;
	}

	.tabletitle {
		min-width: 160upx;
		text-align-last: justify;
		text-align: justify;
		text-justify: distribute-all-lines;
		padding: 0 10upx;
		font-weight: 600;
		margin-right: 30upx;
	}

	.tablecontent {
		margin-left: 30upx;
		font-size: 30upx;
	}

	.titiel {
		text-align: center;
		font-size: 30upx;
		background: #dddddd;
		padding: 8upx;
		margin-top: 10upx;
	}

	.totcontent {
		padding: 10upx 0;
		font-size: 30upx;
		margin-bottom: 5upx;
		line-height: 70upx;
		text-indent: 2em;
	}

	.title {
		font-size: 28upx;
		text-indent: 2em;
	}

	.title.tfle {
		display: flex;
		flex-wrap: wrap;
		text-indent: 2em;
	}

	.title.tfle .initem {
		flex: 1;
		text-align: justify;
		overflow-wrap: break-word;
	}

	.listiem {
		margin: 5upx 0;
		text-align: justify;
	}

	.listiem .lie {
		margin: 0 5upx;
	}

	.initem {
		border-bottom: 0.2px solid #0a0a0a;
		font-size: 28upx;
		color: #656565;
		display: inline-block;
		min-width: 160upx;
		padding: 0 10upx;
		text-indent: 0;
		text-align: center;
	}

	.fubox {
		padding-top: 20upx;
		width: 100%;
		display: flex;
		flex-wrap: wrap;
	}

	.fubox image {
		width: 32.5%;
		margin: 0.6%;
		height: 200upx;
	}

	.fubox image:nth-of-type(3n + 1) {
		margin-left: 0;
	}

	.fubox image:nth-of-type(3n) {
		margin-right: 0;
	}
</style>
