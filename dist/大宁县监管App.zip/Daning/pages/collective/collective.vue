<template>
	<view>
		<view class="content">
			<view class="itembox">
				<view class="itemli" @tap="shenbao()">
					<image src="../../static/shenbao.png" mode="widthFix"></image>
					<text>
						申报
					</text>
				</view>
				<view class="itemli" @tap="chakan()">
					<image src="../../static/chakan.png" mode="widthFix"></image>
					<text>
						查看
					</text>
				</view>
			</view>
		</view>
	</view>

</template>

<script>
	export default {
		data() {
			return {

			}
		},
		methods: {
			shenbao: function() {
				uni.navigateTo({
					url: "declare/declare"
				})
			},
			chakan: function() {
				uni.navigateTo({
					url: "declare/declist"
				})
			}
		}
	}
</script>

<style>
	page {
		background: #fff;
	}
	.itembox {
		margin-top: 20upx;
		width: 100%;
		display: flex;
		justify-content: space-between;
		background: #fff;
		padding-top: 100upx;
	}

	.itemli {
		width: 100%;
		font-size: 24upx;
		display: flex;
		flex-direction: column;
		justify-content: center;
		align-items: center;
	}

	.itemli image {
		width: 120upx;
	}

	.itemli text {
		color: #333333;
		font-size: 30upx;
		margin-top: 10upx;
	}
</style>
