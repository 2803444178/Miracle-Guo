<template>
	<view>
		<view class="content" v-if="infoarr">
			<form @submit="formSubmit" class="formbox" style="box-sizing: border-box;">
				<view class="totcontent">
					<view v-for="(item,itemindex) in infoarr" :key="itemindex">
						<view class="section" v-if="item.rule== 'date'">
							<view class="section__title">{{item.name}}：</view>
							<view class="iconbox">
								<input disabled="true" @tap="toggleTab('picker',itemindex)" :placeholder="item.name" class="section__input"
								 :value="item.value" placeholder-class="placesize" /></input>
								<view class="iconfont icon-riqi xiala"></view>
							</view>
						</view>
						<view v-else-if="item.name.includes('ID')" class="section" style="display: none;">
							<view class="section__title">{{item.name}}：</view>
							<input class="section__input" v-model="item.value" :placeholder="item.name" />
						</view>
						<view v-else-if="item.rule== 'select' && itemindex == 8" class="section">
							<view class="section__title">{{item.name}}：</view>
							<view class="iconbox">
								<picker class="pickee" @change="bindTpye($event,item,itemindex)" :range="item.options" range-key="label">
									<view class="section__input">{{item.options[index] ? item.options[index].label:'请选择'}}</view>
								</picker>
								<view class="iconfont icon-xiala xiala"></view>
							</view>
						</view>
						<view v-else-if="item.rule== 'select' && itemindex == 11" class="section">
							<view class="section__title">{{item.name}}：</view>
							<view class="iconbox">
								<picker class="pickee" @change="bindTpye($event,item,itemindex)" :range="item.options" range-key="label">
									<view class="section__input">{{item.options[indexe] ? item.options[indexe].label:'请选择'}}</view>
								</picker>
								<view class="iconfont icon-xiala xiala"></view>
							</view>
						</view>
						<view v-else-if="item.name.includes('菜单')" class="section">
							<view class="section__title">{{item.name}}：</view>
							<textarea class="section__text" v-model="item.value" :placeholder="item.name" placeholder-class="placesize"></textarea>
						</view>
						<view v-else class="section">
							<view class="section__title">{{item.name}}：</view>
							<input class="section__input" v-model="item.value" :placeholder="item.name" placeholder-class="placesize" />
						</view>
					</view>
				</view>
				<view class="btn-area">
					<button formType="submit" class="uni-btn-v">发送申请</button>
				</view>
			</form>
		</view>
		<w-picker mode="date" :current="false" @confirm="onConfirmee" :disabledAfter="false" ref="picker" themeColor="#f00"></w-picker>
	</view>
</template>
<script>
	var _self;
	import commonInfo from "@/common/common.js"
	import api from "@/api/api.js"
	var apiurl
	export default {

		data() {
			return {
				array: ['100以内', '100-200', '200-500', '500以上'],
				index: -1,
				indexe: -1,
				backbtn: true,
				infoarr: [],
				declinfo: null,
				curDateIndex: null
			};
		},
		onLoad(res) {
			apiurl = commonInfo.apiUrle;
			let name = commonInfo.userinfo.name;
			let key = '201920集体聚餐';
			uni.showLoading({
				title: "加载中"
			})
			api.getFormdata(key, '201920', name, (res, fields) => {
				console.log(res)
				this.declinfo = res;
				let arr = res.data.values;
				let arri = []
				console.log(fields)
				console.log(arr)
				fields['所属机构'].value = commonInfo.userinfo.info.unitName;
				fields['所属机构'].value = commonInfo.userinfo.info.unitName;
				fields['所属区域'].value = commonInfo.userinfo.info.levelName;
				fields['所属区域ID'].value = commonInfo.userinfo.info.levelId;
				fields['协管员'].value = commonInfo.userinfo.info.memberName;
				fields['所属站所'].value = commonInfo.userinfo.info.levelName;
				fields['申报人'].value = commonInfo.userinfo.info.memberName;
				this.infoarr = arr;
				console.log('----------')
				console.log(this.infoarr)
			})
		},
		onBackPress: function() {
			var that = this;
			if (this.backbtn) {
				uni.showModal({
					title: '提示',
					content: '确定保存本次编辑？',
					success: function(res) {
						if (res.confirm) {
							let key = '201920集体聚餐';
							uni.setStorageSync(key, that.declinfo)
							that.backbtn = false;
							uni.navigateBack()
						} else if (res.cancel) {
							that.backbtn = false;
							uni.navigateBack()
						}
					}
				});
				return true
			} else {
				return false
			}
		},
		methods: {
			toggleTab(str, index) {
				this.curDateIndex = index
				this.$refs[str].show();
			},
			onConfirmee(val) {
				this.infoarr[this.curDateIndex].value = val.result
			},
			bindTpye: function(e, field, intype) {
				console.log(intype)
				let index = e.target.value
				if (intype == 8) {
					this.index = index;
				} else if (intype == 11) {
					this.indexe = index;
				}
				let value = this.infoarr[intype].options[index].value;
				this.infoarr[intype].value = value;
			},
			formSubmit(e) {
				//表单验证
				let info = this.declinfo.data.values
				for (let i in info) {
					if (info[i].value == "" &&  !info[i].name.includes('ID') ) {
						uni.showToast({
							title: "" + info[i].name + "不可为空",
							icon: "none"
						})
						return false
					}
					if (info[i].name == "联系电话") {
						if (!(/^1[3456789]\d{9}$/.test(info[i].value))) {
							uni.showToast({
								title: "" + info[i].name + "错误",
								icon: "none"
							})
							return false;
						}
					}
				}
				
				//提交
				api.postFormdata(this.declinfo, (res) => {
					this.backbtn = false;
					uni.hideLoading()
					uni.showToast({
						title: "提交成功",
						icon: "none"
					})
					let key = '201920集体聚餐';
					uni.removeStorage({
						key: key,
						success: function(res) {
							setTimeout(function() {
								uni.navigateBack()
							}, 600)
						}
					});
				})
			}
		}
	}
</script>

<style>
	@import url("../../../static/css/CommonPunish.css");

	.uni-btn-v {
		width: 60%;
		margin: 33px auto;
		height: 60upx;
		line-height: 60upx;
		padding: 0;
		font-size: 32upx;
		letter-spacing: 4px;
		border-radius: 40upx;
		background: #4b559d;
		color: #fff;
	}
</style>
