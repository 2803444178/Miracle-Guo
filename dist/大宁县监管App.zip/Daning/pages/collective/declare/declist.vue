<template>
	<view>
		<view>
			<mescroll-uni :down="downOption" @down="downCallback" :up="upOption" @up="upCallback" @init="mescrollInit">
				<desilt :list="pdList"></desilt>
			</mescroll-uni>
		</view>
	</view>
</template>
<script>
	import Desilt from "@/component/other/desilt.vue";
	import MescrollUni from "@/component/mescroll-uni/mescroll-uni.vue";
	import url from "@/common/common.js"
	var apiurl
	export default {
		components: {
			Desilt,
			MescrollUni
		},
		data() {
			return {
				regulator: '',
				mescroll: {
					num: 1
				}, //mescroll实例对象
				downOption: {

				},
				upOption: {
					auto: false, //是否在初始化后,自动执行上拉回调callback; 默认true
					noMoreSize: 3, //如果列表已无数据,可设置列表的总数量要大于半页才显示无更多数据;避免列表数据过少(比如只有一条数据),显示无更多数据会不好看
					empty: {
						tip: '~ 搜索无结果 ~' // 提示
					}
				},
				pdList: [],
			};
		},
		onLoad() {
			apiurl = url.apiUrle;
		},
		methods: {
			back: function() {
				uni.navigateBack()
			},
			// mescroll组件初始化的回调,可获取到mescroll对象
			mescrollInit(mescroll) {
				this.mescroll = mescroll;
			},
			/*下拉刷新的回调 */
			downCallback(mescroll) {
				// 下拉刷新的回调,默认重置上拉加载列表为第一页 (自动执行 mescroll.num=1, 再触发upCallback方法 )
				mescroll.resetUpScroll()
			},
			/*上拉加载的回调: mescroll携带page的参数, 其中num:当前页 从1开始, size:每页数据条数,默认10 */
			upCallback(mescroll) {
				// 先清空列表,显示加载进度
				if (mescroll.num == 1) this.pdList = []; //如果是第一页需手动制空列表
				//联网加载数据
				console.log(this.mescroll)
				mescroll.size = 15;
				this.getListDataFromNet(this.curWord, mescroll.num, mescroll.size, (curPageData) => {
					console.log(curPageData)
					//联网成功的回调,隐藏下拉刷新和上拉加载的状态;
					mescroll.endSuccess(curPageData.length);
					//追加新数据
					this.pdList = this.pdList.concat(curPageData);
				}, () => {
					//联网失败的回调,隐藏下拉刷新的状态
					mescroll.endErr();
				})
			},
			/*联网加载列表数据
			在您的实际项目中,请参考官方写法: http://www.mescroll.com/uni.html#tagUpCallback
			请忽略getListDataFromNet的逻辑,这里仅仅是在本地模拟分页数据,本地演示用
			实际项目以您服务器接口返回的数据为准,无需本地处理分页.
			* */
			getListDataFromNet(curWord, pageNum, pageSize, successCallback, errorCallback) {
				var that = this;
				//延时一秒,模拟联网
				var levelName // 所长
				var loginName // 协管员
				var juName // 局领导
				let res = url.userinfo.info;
				console.log(res)
				if (res.postId == '-6525400723727104131' || res.postId == '-3585262753697609220') {
					// 所长或者职员 级别统一，都是查看本站所的相关信息
					//站所ID
					levelName = res.levelName;
					loginName = "";
				} else if (res.postId == '8170119026523193523') {
					// 协管员，只能查看自己申报的信息
					loginName = res.loginName;
					levelName = ""
				} else if (res.postId == '5716948556706694426') {
					// 协管员，只能查看自己申报的信息
					loginName = "";
					levelName = ""
				}
				uni.request({
					url: apiurl + '/getFormInfoServlet?templateCode=201920', //仅为示例，并非真实接口地址。
					data: {
						pageindex: pageNum,
						pageSize: pageSize,
						'所属站所': levelName,
						'协管员': loginName,
					},
					success: (res) => {
						console.log(res)
						var curPageData = res.data.data;
						//模拟分页数据
						let listData = [];
						for (let i = 0; i < curPageData.length; i++) {
							curPageData[i]['申报事由'] = curPageData[i]['申报事由'] && this.fillet(curPageData[i]['申报事由'])
							listData.push(curPageData[i]);
						}
						successCallback && successCallback(listData);
					}
				});
			},
			fillet: function(res) {
				if (res == '-9054198286668182842') {
					return '结婚'
				} else if (res == '-6360903066980561562') {
					return '新建房'
				} else if (res == '-5096476115961625045') {
					return '丧事'
				} else if (res == '1829776505627036550') {
					return '其他'
				}
			},
		}
	}
</script>

<style>
	page {
		background: #fff;
	}

	.status_bar {
		height: var(--status-bar-height);
		width: 100%;
		background: #4b559d;
	}

	.headbox {
		background: #4b559d;
		text-align: center;
		padding: 20upx;
		color: #fff;
		font-weight: normal;
	}
</style>
