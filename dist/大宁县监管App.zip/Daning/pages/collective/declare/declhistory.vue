<template>
	<view>
		<view class="list-content" v-if="info">
			<form class="formbox" style="box-sizing: border-box;">
				<view class="section">
					<view class="section__title">协管员：</view>
					<view class="section__input">{{info['协管员'] ? info['协管员'] : "无" }}</view>
				</view>
				<view class="section">
					<view class="section__title">所属站所：</view>
					<view class="section__input">{{info['所属站所'] ? info['所属站所'] : "无" }}</view>
				</view>
				<view class="section">
					<view class="section__title">申报单位：</view>
					<view class="section__input">{{info['申报单位'] ? info['申报单位'] : "无" }}</view>
				</view>
				<view class="section">
					<view class="section__title">申报事由：</view>
					<view class="section__input">{{info['申报事由'] ? info['申报事由'] : "无" }}</view>
				</view>
				<view class="section">
					<view class="section__title">申报人：</view>
					<view class="section__input">{{info['申报人'] ? info['申报人'] : "无" }}</view>
				</view>
				<view class="section">
					<view class="section__title">申报时间：</view>
					<view class="section__input">{{info['申报时间'] ? info['申报时间'].replace(/00.00.00.0*$/,'') : "无" }}</view>
				</view>
				<view class="section">
					<view class="section__title">就餐人数：</view>
					<view class="section__input">{{info['就餐人数'] ? info['就餐人数'] : "无" }}</view>
				</view>
				<view class="section">
					<view class="section__title">聚餐时间：</view>
					<view class="section__input">{{info['就餐时间'] ? info['就餐时间'].replace(/00.00.00.0*$/,'') : "无" }}</view>
				</view>
				<view class="section">
					<view class="section__title">联系电话：</view>
					<view class="section__input">{{info['联系电话'] ? info['联系电话'] : "无" }}</view>
				</view>
				<view class="section-tex">
					<view class="section__title" style="padding-left: 15upx; margin-bottom: 15upx;">凉菜菜单：</view>
					<view class="section-text">{{info['凉菜菜单'] ? info['凉菜菜单'] : "无" }}</view>
				</view>
				<view class="section-tex">
					<view class="section__title" style="padding-left: 15upx; margin-bottom: 15upx;">热菜菜单：</view>
					<view class="section-text">{{info['热菜菜单'] ? info['热菜菜单'] : "无" }}</view>
				</view>
			</form>
		</view>
	</view>
</template>
<script>
	import url from "@/common/common.js"
	var apiurl
	var _self;
	export default {
		data() {
			return {
				info: ""
			};
		},
		onLoad(res) {
			apiurl = url.apiUrl;
			uni.showLoading({
				title: "加载中"
			})
			uni.request({
				url: apiurl + "/form-detail",
				data: {
					templateCode: '201920',
					ID: res.id
				},
				success: (res) => {
					if (res.data) {
						uni.hideLoading()
						this.info = res.data;
					}
				}
			});
		},
		methods: {
			back: function() {
				uni.navigateBack()
			},
		}
	}
</script>

<style>
	.title {
		margin-top: 50upx;
		text-align: center;
		font-size: 36upx;
		color: #333333;
		font-weight: 600;
	}

	.formbox {
		padding: 20upx;
		width: 100%;
		display: block;
	}

	.section {
		display: flex;
		padding: 35upx 15upx;
		height: 80upx;
		border-bottom: 2upx solid #c1c1c1;
		align-items: center;
	}

	.section-tex {
		padding: 25upx 0upx;
	}

	.section-text {
		border: 2upx solid #C1C1C1;
		width: 100%;
		height: 200upx;
		padding: 20upx;
		font-size: 28upx;
	}

	.section__title {
		min-width: 20%;
		max-width: 80%;
		font-size: 28upx;
		font-weight: 600;
	}

	.section__input {
		flex: 1;
		font-size: 30upx;
		padding-left: 1em;
	}

	.section__input image {
		width: 100%;
		height: 100%;
	}
</style>
