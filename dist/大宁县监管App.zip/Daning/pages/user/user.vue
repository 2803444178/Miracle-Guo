<template>
	<view>
		<view class="bg">
			<view class="headimg">
				<image src="../../static/face.jpg" mode=""></image>
				<view class="name">
					{{userinfo.loginName}}
				</view>
				<view class="area">
					{{userinfo.unitName}}
				</view>
			</view>
		</view>
		<view class="list-content">
			<view class="list">
				<view class="li noborder">
					<text class="iconfont icon-zhiwu"></text>
					<view class="text">职务</view>
					<view class="text" style="text-align: right;">{{userinfo.postName}}</view>
					<text class="iconfont icon-you"></text>
				</view>
				<view class="li noborder" @tap="clear()">
					<text class="iconfont icon-qingchu"></text>
					<view class="text">清除缓存</view>
					<view class="text" style="text-align: right;">{{currentSize}}KB</view>
					<text class="iconfont icon-you"></text>
				</view>
				<view class="li noborder" @tap="Appstart()">
					<text class="iconfont icon-banben"></text>
					<view class="text">版本检测</view>
					<view class="text" style="text-align: right;">{{keversion}}</view>
					<text class="iconfont icon-you"></text>
				</view>
				<view class="li noborder" @tap="Appout()">
					<text class="iconfont icon-icon-out-light"></text>
					<view class="text">退出登录</view>
					<text class="iconfont icon-you"></text>
				</view>
			</view>
		</view>
	</view>
</template>
<script>
	import url from "@/common/common.js"
	export default {
		data() {
			return {
				userinfo: '',
				keversion: '',
				currentSize: '',
				setUserData: null //登录信息
			};
		},
		onLoad() {
			this.userinfo = url.userinfo.info;
			var that = this;
			uni.getStorageInfo({
				success: function(res) {
					that.currentSize = res.currentSize;
				}
			});
			const value = uni.getStorageSync('setUserData');
			if (value) {
				this.setUserData = value;
			}
			plus.runtime.getProperty(plus.runtime.appid, function(widgetInfo) {
				that.keversion = widgetInfo.version
			});
		},
		methods: {
			Appstart: function() {
				var that = this;
				uni.request({
					url: 'http://60.222.220.223:30006/Test/upid',
					success: (result) => {
						var data = result.data.data;
						var version = data.UpID;
						if (that.keversion < version) {
							uni.showModal({
								title: '更新提示',
								content: '检测有新的版本，是否现在更新？',
								success: function(res) {
									if (res.confirm) {
										uni.showLoading({
											title: "下载中",
											icon: "none"
										})
										uni.downloadFile({
											url: data.UpURL,
											success: (downloadResult) => {
												if (downloadResult.statusCode === 200) {
													plus.runtime.install(downloadResult.tempFilePath, {
														force: false
													}, function() {
														uni.showToast({
															title: '下载成功',
															duration: 2000,
															icon: "none"
														});
														setTimeout(function() {
															plus.runtime.restart();
														}, 3000);
													}, function(e) {
														uni.showToast({
															title: '下载失败',
															duration: 2000,
															icon: "none",
														});
													});
												}
											},
											fail: function() {
												uni.showToast({
													title: '下载失败',
													duration: 2000,
													icon: "none",
												});
											}
										});
									} else if (res.cancel) {
										console.log('用户点击取消');
									}
								}
							});
						} else {
							uni.showToast({
								title: '已经是最新版本',
								duration: 2000,
								icon: "none",
							});
						}
					}
				});
			},
			Appout: function() {
				uni.showModal({
					title: '提示',
					content: '确定退出当前账号？',
					success: function(res) {
						if (res.confirm) {
							uni.removeStorageSync('setUserData');
							uni.reLaunch({
								url: "../login/login"
							})
						} else if (res.cancel) {
							console.log('用户点击取消');
						}
					}
				});
			},
			clear: function() {
				var that = this;
				try {
					uni.getStorageInfo({
						success: function(res) {
							if (res.currentSize && res.currentSize > 0) {
								uni.showModal({
									title: '提示',
									content: '确定清除缓存数据？',
									success: function(res) {
										if (res.confirm) {
											uni.clearStorageSync();
											uni.setStorageSync('setUserData', that.setUserData);
											uni.showToast({
												title: "清理成功",
												icon: "none"
											})
											that.currentSize = 0;
										} else if (res.cancel) {
											console.log('用户点击取消');
										}
									}
								});
							} else {
								uni.showToast({
									title: "暂无缓存",
									icon: "none"
								})
							}

						}
					});
				} catch (e) {
					// error
				}
			}
		}
	}
</script>

<style lang="scss">
	page {
		background-color: #fff;
	}

	.bg {
		background: #4b559d;
	}

	.iconfont {
		font-size: 46upx;
		color: #4b559d;
	}

	.headbox {
		display: flex;
		justify-content: center;
		align-items: center;
		font-size: 18px;
		background-color: #4b559d;
		color: #fff;
	}

	.headimg {
		display: flex;
		flex-direction: column;
		justify-content: center;
		align-items: center;
		padding-top: 80upx;
		padding-bottom: 40upx;
		margin-bottom: 30upx;
	}

	.headimg image {
		width: 150upx;
		height: 150upx;
		border-radius: 50%;
	}

	.name {
		font-size: 36upx;
		color: #fff;
		padding-top: 30upx;
		letter-spacing: 5upx;
		font-weight: 600;
	}

	.area {
		font-size: 30upx;
		color: #fff;
		padding-top: 10upx;
	}

	.list-content {
		background: #fff;
	}

	.list {
		width: 100%;
		border-bottom: 15upx solid #f1f1f1;
		background: #fff;
		padding: 0 4%;

		&:last-child {
			border: none;
		}

		.li {
			width: 100%;
			height: 100upx;
			border-bottom: 1px solid #e1e1e1;
			display: flex;
			align-items: center;

			&:last-child {
				border: none;
			}



			.text {
				padding-left: 20upx;
				width: 100%;
				color: #666;
				font-size: 30upx;
			}

			.to {
				flex-shrink: 0;
				width: 40upx;
				height: 40upx;
			}
		}
	}
</style>
