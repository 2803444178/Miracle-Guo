<template>
	<view>
		<view class="content" v-if="fields">
			<form @submit="submit">
				<view class="totcontent">

					<view class="section">
						<view class="section__title">立案/不予立案审批表：</view>
						<input class="section__input" :value="fields['立案或不予立案'] ? fields['立案或不予立案']:'' " disabled="true"></input>
					</view>
					<view class="common-t">
						当事人单位
					</view>
					<view class="section">
						<view class="section__title">名称：</view>
						<input class="section__input" :value="fields['单位名称'] ? fields['单位名称']:'' " disabled="true"></input>
					</view>
					<view class="section">
						<view class="section__title">统一社会信用代码：</view>
						<input class="section__input" :value="fields['统一社会信用代码'] ? fields['统一社会信用代码']:'' " disabled="true"></input>
					</view>
					<view class="section sbo">
						<view class="section__title">法定代表人（负责人）：</view>
						<input class="section__input" :value="fields['法定代表人'] ? fields['法定代表人']:'' " disabled="true"></input>
					</view>
					<view class="common-t">
						当事人个体工商户或个人
					</view>
					<view class="section">
						<view class="section__title">字号名称：</view>
						<input class="section__input" :value="fields['字号名称'] ? fields['字号名称']:'' " disabled="true"></input>
					</view>
					<view class="section">
						<view class="section__title">姓名：</view>
						<input class="section__input" :value="fields['姓名'] ? fields['姓名']:'' " disabled="true"></input>
					</view>
					<view class="section">
						<view class="section__title">统一社会信用代码（注册号）：</view>
						<input class="section__input" :value="fields['个体工商户统一社会信用代码'] ? fields['个体工商户统一社会信用代码']:'' " disabled="true"></input>
					</view>
					<view class="section">
						<view class="section__title">身份证（其他有效证件）号码：</view>
						<input class="section__input" :value="fields['身份证'] ? fields['身份证']:'' " disabled="true"></input>
					</view>
					<view class="section sbo">
						<view class="section__titlm">住所（地址）：</view>
						<input class="section__input" :value="fields['住所'] ? fields['住所']:'' " disabled="true"></input>
					</view>
					<view class="section">
						<view class="section__title">案由：</view>
						<input class="section__input" :value="fields['案由'] ? fields['案由']:'' " disabled="true"></input>
					</view>
					<view class="section sbo">
						<view class="section__title">案源登记时间：</view>
						<input class="section__input" :value="fields['案源登记时间'] ? fields['案源登记时间']:'' " disabled="true"></input>
					</view>
					<view class="section">
						<view class="section__title">核查情况及立案（不予立案）理由：</view>
						<input class="section__input" :value="fields['核查情况及廉不予立案理由'] ? fields['核查情况及廉不予立案理由']:'' " disabled="true"></input>
					</view>

					<view class="section">
						<view class="section__title">经办人：</view>
						<view class="section_canvas">
							<image :src="fields['经办人'] " class="qianfa" mode="aspectFit"></image>
						</view>
					</view>
					<view class="section sbo">
						<view class="section__title">时间：</view>
						<input class="section__input" :value="fields['经办人时间'] ? fields['经办人时间']:'' " disabled="true"></input>
					</view>

					<view class="section ">
						<view class="section__title">办案机构负责人意见：</view>
						<input class="section__input" :value="fields['办案机构负责人意见'] ? fields['办案机构负责人意见']:'' " disabled="true"></input>
					</view>

					<view class="section">
						<view class="section__title">办案机构负责人：</view>
						<view class="section_canvas">
							<image :src="fields['办案机构负责人'] " class="qianfa" mode="aspectFit"></image>
						</view>
					</view>
					<view class="section sbo">
						<view class="section__title">时间：</view>
						<input class="section__input" :value="fields['办案机构负责人时间'] ? fields['办案机构负责人时间']:'' " disabled="true"></input>
					</view>
					<view class="section">
						<view class="section__title">部门负责人意见：</view>
						<input class="section__input" :value="fields['部门负责人意见'] ? fields['部门负责人意见']:'' " disabled="true"></input>
					</view>
					<view class="section">
						<view class="section__title">部门负责人：</view>
						<view class="section_canvas">
							<image :src="fields['部门负责人'] " class="qianfa" mode="aspectFit"></image>
						</view>
					</view>

					<view class="section sbo">
						<view class="section__title">时间：</view>
						<input class="section__input" :value="fields['部门负责人时间'] ? fields['部门负责人时间']:'' " disabled="true"></input>
					</view>
					<view class="section">
						<view class="section__title">备注：</view>
						<textarea class="section__text" :value="fields['备注'] ? fields['备注'] : ''" disabled />
						</view>
				</view>
			</form>
		</view>
	</view>
</template>

<script>
	import api from "@/api/api.js"
	import commonInfo from "@/common/common.js"
	var token;
	export default {
		data() {
			return {
				dataL: "",
				nowdate: '',
				currentIndex: "",
				fields: null,
				//签名信息
				signImage: {
					"经办人": "",
					"办案机构负责人": "",
					"部门负责人": "",
				},
				// 企业信息
				enterpriseinfo: ""
			}
		},
		onLoad: function(res) {
			uni.setNavigationBarTitle({
				title: res.name
			})
			let that = this;
			let name = commonInfo.userinfo.name
			api.GetNowtoken(name, (res) => {
				console.log(res)
				token = res
			});
			uni.showLoading({
				title: "加载中"
			})
			uni.request({
				url: "http://h5.shouyunchina.com:8002/DNServices/businessInfoServlet",
				method: "GET",
				data: {
					recordId: res.recordId,
					id: res.id
				},
				success: async (res) => {
					if (res && res.data) {
						let {
							data: {
								values: values
							}
						} = res;
						let info = res.data;
						info['立案或不予立案'] = info['立案或不予立案'] && this.fillet(info['立案或不予立案']);
						info['经办人'] = info['经办人'] &&  await this.getimg(info['经办人']);
						info['办案机构负责人'] = info['办案机构负责人'] && await  this.getimg(info['办案机构负责人']);
						info['部门负责人'] = info['部门负责人'] &&  await this.getimg(info['部门负责人']);
						console.log(info)
						this.fields = info;
						uni.hideLoading()
					}
					
				},
				fail: (err) => {
					console.log(err);
					uni.showToast({
						title:"请求失败",
						icon:"none"
					})
				}
			});
		},
		methods: {
			fillet: function(res) {
				if (res == '8361367595765681198') {
					return '符合'
				} else if (res == '-2066416451667277405') {
					return '基本符合'
				} else if (res == '6571312966818286323') {
					return '不符合'
				} else if (res == '986401131406182056') {
					return '通过'
				} else if (res == '-233736429269465346') {
					return '书面整改'
				} else if (res == '-8708609701263029876') {
					return '停业整顿'
				} else if (res == '8997802166051095014') {
					return '否'
				} else if (res == '-6831193320631809582') {
					return '是'
				} else if (res == '5885808606164896166') {
					return '已向你宣读'
				} else if (res == '6573754221301875061') {
					return '请核对'
				} else if (res == '1068839251742507953') {
					return '全部证据'
				} else if (res == '6513549339120258159') {
					return '部分证据'
				} else if (res == '3117111607399304046') {
					return '场所清单'
				} else if (res == '-3564747582551603596') {
					return '财物清单'
				} else if (res == '2944129172193822406') {
					return '设施清单'
				} else if (res == '6897086536934377384') {
					return '男'
				} else if (res == '-4637397066553733657') {
					return '女'
				}
				else if (res == '3495632856930011401') {
					return '设施'
				}
				else if (res == '-9102571236001362048') {
					return '财物'
				}
				else if (res == '7350172593853450270') {
					return '场所'
				}
				else if (res == '-456001630006194760') {
					return '扣押'
				}
				else if (res == '1472044003399387940') {
					return '查封'
				}
				else if (res == '-4807422774013443093') {
					return '立案'
				}
				else if (res == '-8528133649199512965') {
					return '不予立案'
				}
			},
			getimg: function(id) {
				console.log(id)
				return new Promise((resolve, reject) => {
					let name = commonInfo.userinfo.name
					api.GetNowtoken(name, (res) => {
						console.log(name)
						console.log(res)
						let url = "http://183.203.90.25:8888/seeyon/services/downloadService?token=" + res +
							"&fileId=" + id + "";
						resolve(url)
					});
				})
			},
		},
	}
</script>

<style>
	@import url("../../../static/css/CommonPunish.css");
</style>
