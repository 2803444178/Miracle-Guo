<template>
	<view>
		<view class="content" v-if="fields">
			<form @submit="submit">
				<view class="totcontent" v-show=" showindex == 1 ">
					<view class="section__title">
						立案/不予立案审批表
					</view>
					<view class="iconbox">
						<picker class="pickee" @change="bindTpye($event,fields['立案或不予立案'],'1')" :range="fields['立案或不予立案'].options"
						 range-key="label">
							<view class="section__input">{{fields['立案或不予立案'].options[index] ? fields['立案或不予立案'].options[index].label:'请选择'}}</view>
						</picker>
						<view class="iconfont icon-xiala xiala"></view>
					</view>
					<view class="section__title">
						当事人单位
					</view>
					<view class="section">
						<view class="section__title">名称：</view>
						<input class="section__input" v-model="fields['单位名称'].value" placeholder-class="placesize" name="单位名称"
						 placeholder="当事人单位名称"></input>
					</view>
					<view class="section">
						<view class="section__title">统一社会信用代码：</view>
						<input class="section__input" v-model="fields['统一社会信用代码'].value" placeholder-class="placesize" name="统一社会信用代码"
						 placeholder="统一社会信用代码"></input>
					</view>
					<view class="section sbo">
						<view class="section__title">法定代表人（负责人）：</view>
						<input class="section__input" v-model="fields['法定代表人'].value" placeholder-class="placesize" name="法定代表人"
						 placeholder="定代表人名称"></input>
					</view>
					<button class="btn" @tap="next(2)">下一步</button>
				</view>

				<view class="totcontent" v-show="showindex == 2">
					<view class="section__title">
						当事人个体工商户或个人
					</view>
					<view class="section">
						<view class="section__title">字号名称：</view>
						<input class="section__input" v-model="fields['字号名称'].value" placeholder-class="placesize" name="字号名称"
						 placeholder="字号名称"></input>
					</view>
					<view class="section">
						<view class="section__title">姓名：</view>
						<input class="section__input" v-model="fields['姓名'].value" placeholder-class="placesize" name="姓名" placeholder="姓名"></input>
					</view>
					<view class="section">
						<view class="section__title">统一社会信用代码（注册号）：</view>
						<input class="section__input" v-model="fields['个体工商户统一社会信用代码'].value" placeholder-class="placesize" name="个体工商户统一社会信用代码"
						 placeholder="统一社会信用代码"></input>
					</view>
					<view class="section">
						<view class="section__title">身份证（其他有效证件）号码：</view>
						<input class="section__input" v-model="fields['身份证'].value" placeholder-class="placesize" name="身份证" placeholder="身份证号码"></input>
					</view>
					<view class="section sbo">
						<view class="section__titlm">住所（地址）：</view>
						<input class="section__input" v-model="fields['住所'].value" placeholder-class="placesize" name="住所" placeholder="住所"></input>
					</view>
					<view class="section">
						<view class="section__title">案由：</view>
						<input class="section__input" v-model="fields['案由'].value" placeholder-class="placesize" name="案由" placeholder="案由"></input>
					</view>
					<view class="section sbo">
						<view class="section__title">案源登记时间：</view>
						<view class="iconbox">
							<input class="section__input" @tap="toggleTab('picker','案源登记时间')" v-model="fields['案源登记时间'].value" disabled="true"
							 placeholder-class="placesize" placeholder="开始时间"></input>
							<view class="iconfont icon-riqi xiala"></view>
						</view>
					</view>
					<view class="combtn">
						<button class="btn" @tap="pre(1)">上一步</button>
						<button class="btn" @tap="next(3)">下一步</button>
					</view>
				</view>
				<view class="totcontent" v-show="showindex == 3">
					<view class="section">
						<view class="section__title">核查情况及立案（不予立案）理由：</view>
						<textarea class="section__text" v-model="fields['核查情况及廉不予立案理由'].value" placeholder="核查情况及廉不予立案理由"
						 placeholder-class="placesize" />
						</view>
					<view class="section">
						<view class="section__title">经办人：</view>
						<view class="section_canvas" @tap="gocanvas('经办人')">
							<view v-if="!signImage['经办人']" class="iconfont icon-iconzhengli_shouxieqianpi xiala"></view>
							<image :src="signImage['经办人']" class="qianfa" mode="aspectFit"></image>
						</view>
					</view>
					<view class="section sbo">
						<view class="section__title">时间：</view>
						<view class="iconbox">
							<input class="section__input" @tap="toggleTab('picker','经办人时间')" v-model="fields['经办人时间'].value" disabled="true"
							 placeholder-class="placesize" placeholder="开始时间"></input>
							<view class="iconfont icon-riqi xiala"></view>
						</view>
					</view>
					<view class="combtn">
						<button class="btn" @tap="pre(2)">上一步</button>
						<button class="btn" @tap="next(4)">下一步</button>
					</view>
				</view>
				<view class="totcontent" v-show="showindex == 4">
					<view class="section ">
						<view class="section__title">办案机构负责人意见：</view>
						<input class="section__input" placeholder-class="placesize" v-model="fields['办案机构负责人意见'].value" name="办案机构负责人意见"
						 placeholder="办案机构负责人意见"></input>
					</view>
					<view class="section">
						<view class="section__title">办案机构负责人：</view>
						<view class="section_canvas" @tap="gocanvas('办案机构负责人')">
							<view v-if="!signImage['办案机构负责人']" class="iconfont icon-iconzhengli_shouxieqianpi xiala"></view>
							<image :src="signImage['办案机构负责人']" class="qianfa" mode="aspectFit"></image>
						</view>
					</view>
					<view class="section sbo">
						<view class="section__title">时间：</view>
						<view class="iconbox">
							<input class="section__input" @tap="toggleTab('picker','办案机构负责人时间')" v-model="fields['办案机构负责人时间'].value"
							 disabled="true" placeholder-class="placesize" placeholder="办案机构负责人时间"></input>
							<view class="iconfont icon-riqi xiala"></view>
						</view>
					</view>
					<view class="combtn">
						<button class="btn" @tap="pre(3)">上一步</button>
						<button class="btn" @tap="next(5)">下一步</button>
					</view>
				</view>
				<view class="totcontent" v-show="showindex == 5">
					<view class="section">
						<view class="section__title">部门负责人意见：</view>
						<input class="section__input" placeholder-class="placesize" v-model="fields['部门负责人意见'].value" name="部门负责人意见"
						 placeholder="部门负责人意见"></input>
					</view>
					<view class="section">
						<view class="section__title">部门负责人：</view>
						<view class="section_canvas" @tap="gocanvas('部门负责人')">
							<view v-if="!signImage['部门负责人']" class="iconfont icon-iconzhengli_shouxieqianpi xiala"></view>
							<image :src="signImage['部门负责人']" class="qianfa" mode="aspectFit"></image>
						</view>
					</view>
					<view class="section">
						<view class="section__title">备注：</view>
						<textarea class="section__text" v-model="fields['备注'].value" placeholder="备注" placeholder-class="placesize" />
						</view>
					
					<view class="combtn">
						<button class="btn" @tap="pre(4)">上一步</button>
						<button class="btn" form-type="submit">提交</button>
					</view>
				</view>
			</form>
			<w-picker mode="date" :current="false" @confirm="onConfirme" :disabledAfter="false" ref="picker"></w-picker>
		</view>
	</view>
</template>

<script>
	import api from "@/api/api.js"
	import commonInfo from "@/common/common.js"
	var token;
	export default {
		data() {
			return {
				showindex:1,
				dataL: "",
				nowdate: '',
				currentIndex: "",
				fields: null,
				//签名信息
				signImage: {
					"经办人": "",
					"办案机构负责人": "",
					"部门负责人": "",
				},
				index: -1,
				backbtn: true,
				// 企业信息
				enterpriseinfo: "",
				key: null
			}
		},
		onLoad: function(res) {
			//设置标题
			uni.setNavigationBarTitle({
				title: res.title
			})
			this.title = res.title;
			let key = commonInfo.userinfo.qycase.ID + '' + res.title;
			this.key = key;
			let name = commonInfo.userinfo.name;
			//获取模板
			api.GetNowtoken(name, (Tokendata) => {
				token = Tokendata
				if (res) {
					api.getFormdata(key, res.id, name, (res, fields) => {
						console.log(fields)
						api.initFields(fields, commonInfo.userinfo.qycase, '201919');
						console.log(2222)
						res.token = Tokendata;
						this.dataL = res;
						this.fields = fields;
					})
				}
			});
			var that = this;
			uni.$on('update', function(data) {
				let arrobj = that.signImage;
				let name = data.name;
				let imgurl = data[data.name];
				let token = commonInfo.userinfo.token;
				let obj = that.dataL;
				api.Getsign(obj, name, imgurl, token, function(res) {
					that.dataL = res;
				})
				for (let i in arrobj) {
					if (arrobj[data.name] == "") {
						arrobj[data.name] = data[data.name]
					}
				}
			})
		},
		onBackPress: function() {
			var that = this;
			if (this.backbtn) {
				uni.showModal({
					title: '提示',
					content: '确定保存本次编辑？',
					success: function(res) {
						if (res.confirm) {
							let key = commonInfo.userinfo.qycase.ID + '' + that.title;
							console.log(that.dataL.data.values)
							uni.setStorageSync(key, that.dataL)
							that.backbtn = false;
							uni.navigateBack()
						} else if (res.cancel) {
							console.log('用户点击取消');
							that.backbtn = true;
						}
					}
				});
				return true
			} else {
				return false
			}
		},
		methods: {
			next:function(res){
				console.log(res)
				this.showindex = res;
			},
			pre:function(res){
				this.showindex = res;
			},
			bindTpye: function(e, field, intype) {
				let name = field.name;
				let index = e.target.value
				let value = this.fields[name].options[index].value;
				field.value = value;
				if (intype == 1) {
					this.index = index;
				}
			},
			toggleTab(str, index) {
				console.log(index)
				this.currentIndex = index;
				this.$refs[str].show();
			},
			onConfirme(val) {
				this.fields[this.currentIndex].value = val.result
			},
			gocanvas: function(name) {
				uni.navigateTo({
					url: "../xzzcan/xzzcan?name=" + name + ""
				})
			},
			submit: function(e) {
				/* 将案件来源登记表的信息缓存，以便于关联使用 */
				uni.showLoading({
					title: "提交中"
				})
				api.postFormdata(this.dataL, (res) => {
					console.log(res)
					if (res && res.code == '0') {
						uni.hideLoading();
						uni.showToast({
							title: "提交成功",
							icon: "success"
						})
						uni.removeStorage({
							key: this.key,
							success: function(res) {
								setTimeout(function() {
									uni.navigateTo({
										url: "../punsucess/punsucess"
									})
								}, 300)
							}
						});

					} else {
						uni.hideLoading();
						uni.showToast({
							title: "提交失败",
							icon: "none"
						})
					}
				}, (err) => {
					console.log(err)
					uni.showToast({
						title: "错误",
						icon: "none"
					})
				});
			}
		},
	}
</script>

<style>
	@import url("../../../static/css/CommonPunish.css");
</style>
