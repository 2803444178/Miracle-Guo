<template>
	<view>
		<view class="content">
			<form @submit="submit" v-if="fields">
				<view class="itemcontent"  v-show="showindex == 1">
					<view class="title-p">
						<input v-model="fields['市'].value" placeholder-class="placesize" class="placeinput title" />
						市监<input v-model="fields['域2'].value" placeholder-class="placesize" class="placeinput title" />(
						<input v-model="fields['市监'].value" placeholder-class="placesize" class="placeinput title" />
						)<input v-model="fields['号'].value" placeholder-class="placesize" class="placeinput title" />号
					</view>
					
					<view class="section">
						<view class="section__title">单位名称</view>
						<input v-model="fields['单位名称'].value" placeholder="单位名称" placeholder-class="placesize" class="section__input" />
						<view class="section__title">经查，你（单位）</view>
						<input v-model="fields['行为'].value" placeholder="违法行为" placeholder-class="placesize" class="section__input" />
						<view class="section__title">的行为，违反了</view>
						<input v-model="fields['违反规定'].value" placeholder="违反规定" placeholder-class="placesize" class="section__input" />
						<view class="section__title">的规定，依据</view>
						<input v-model="fields['依据规定'].value" placeholder="依据规定" placeholder-class="placesize" class="section__input" />
						<view class="section__title">的规定，现责令你（单位）</view>
						<view class="section__title">
							<label class="cheackboxlist">
								<checkbox class="radioitem" value="1" @tap="radioChange(fields['立即予以改正'])" />
								<text>立即予以改正</text>
							</label>
						</view>
						<view class="section__title">
							<label class="cheackboxlist">
								<checkbox class="radioitem" value="1" @tap="radioChange(fields['在具体日期前改正'])" />
								<text>在</text>
							</label>
						</view>
						<view class="section">
							<view class="iconbox">
								<input class="section__input" @tap="toggleTab('picker','改正日期')" v-model="fields['改正日期'].value" disabled="true"
								 placeholder-class="placesize" placeholder="时间"></input>
								<view class="iconfont icon-riqi xiala"></view>
							</view>
						</view>
						<view class="section__title">前改正。（逾期不改的，本局将依据</view>
						<input v-model="fields['逾期依据'].value" placeholder="逾期依据" placeholder-class="placesize" class="section__input" />
						<view class="section__title">的规定</view>
						<input v-model="fields['规定内容'].value" placeholder="规定内容" placeholder-class="placesize" class="section__input" />
						<view class="section__title">改正内容及要求</view>
						<input v-model="fields['改正内容及要求'].value" placeholder="改正内容及要求" placeholder-class="placesize" class="section__input" />
					</view>
					<button class="btn" @tap="next(2)">下一步</button>
				</view>
				<view class="totcontent" v-show=" showindex == 2 ">
					<view class="section">
						<view class="section__title">如对本责令改正决定不服，可以自收到本通知书之日起六十日
							内向</view>
						<input v-model="fields['人民政府'].value" placeholder="人民政府名称" placeholder-class="placesize" class="section__input" />
						<view class="section__title">人民政府或者</view>
						<input type="text" v-model="fields['市场监督管理局'].value" placeholder="市场监督管理局名称" placeholder-class="placesize" class="section__input" />
						<view class="section__title">市场监督管理局申请行政复议；也可以在六个月内依法向</view>
						<input v-model="fields['法院'].value" placeholder="法院名称" placeholder-class="placesize" class="section__input" />
						<view class="section__title">法院提起行政诉讼。</view>
					</view>
					<view class="section">
						<view class="section__title">联系人：</view>
						<input v-model="fields['联系人'].value" placeholder="联系人" placeholder-class="placesize" class="section__input" />
					</view>
					<view class="section">
						<view class="section__title">联系方式：</view>
						<input v-model="fields['联系电话'].value" placeholder="联系方式" placeholder-class="placesize" class="section__input" />
					</view>
					<view class="section">
						<view class="section__title"> 日期：</view>
						<view class="iconbox">
							<input class="section__input" @tap="toggleTab('picker','日期')" v-model="fields['日期'].value" disabled="true"
							 placeholder-class="placesize" placeholder="日期"></input>
							 <view class="iconfont icon-riqi xiala"></view>
						</view>
					</view>
					<view class="itemcontent">
						本文书一式(
						<input v-model="fields['一式份数'].value" placeholder-class="placesize" class="placeinpu" />
						)份,(<input v-model="fields['送达份数'].value" placeholder-class="placesize" class="placeinpu" />
						)份送达，一份归档
					</view>
					<view class="combtn">
						<button class="btn" @tap="pre(1)">上一步</button>
						<button class="btn" form-type="submit">提交</button>
					</view>
				</view>
			</form>
		</view>
		<w-picker mode="date" :current="false" @confirm="onConfirme" :disabledAfter="false" ref="picker"></w-picker>
	</view>
</template>

<script>
	import api from "@/api/api.js"
	import commonInfo from "@/common/common.js"
	var token;
	export default {
		data() {
			return {
				dataL: "",
				nowdate: '',
				showindex: 1,
				fields:null,
				currentIndex: "",
				//签名信息
				signImage: {
					"经办人": "",
					"办案机构负责人": "",
					"部门负责人": "",
				},
				// 企业信息
				enterpriseinfo: "",
				index: 0,
				qyname:'',
				backbtn: true,
				key:null
			}
		},
		onLoad: function(res) {
			//设置标题
			uni.setNavigationBarTitle({
				title: res.title
			})
			this.title = res.title;
			let key = commonInfo.userinfo.qycase.ID + '' + res.title;
			this.key = key;
			let name = commonInfo.userinfo.name;
			//获取模板
			console.log(commonInfo.userinfo.qycase)
			api.GetNowtoken(name, (Tokendata) => {
				token = Tokendata
				if (res) {
					api.getFormdata(key, res.id, name, (res, fields) => {
						console.log(fields)
						api.initFields(fields, commonInfo.userinfo.qycase, '201918');
						res.token = Tokendata;
						this.dataL = res;
						this.fields = fields;
					})
				}
			});
			var that = this;
			uni.$on('update', function(data) {
				let arrobj = that.signImage;
				let name = data.name;
				let imgurl = data[data.name];
				let token = commonInfo.userinfo.token;
				let obj = that.dataL;
				api.Getsign(obj, name, imgurl, token, function(res) {
					that.dataL = res;
				})
				for (let i in arrobj) {
					if (arrobj[data.name] == "") {
						arrobj[data.name] = data[data.name]
					}
				}
			})
		},
		onBackPress: function() {
			var that = this;
			if (this.backbtn) {
				uni.showModal({
					title: '提示',
					content: '确定保存本次编辑？',
					success: function(res) {
						if (res.confirm) {
							let key = commonInfo.userinfo.qycase.ID + '' + that.title;
							console.log(that.dataL.data.values)
							uni.setStorageSync(key, that.dataL)
							that.backbtn = false;
							uni.navigateBack()
						} else if (res.cancel) {
							console.log('用户点击取消');
							that.backbtn = true;
						}
					}
				});
				return true
			} else {
				return false
			}
		},
		methods: {
			radioChange(evt) {
				console.log(evt)
				let str = this.totalarr;
				if (evt.value == '') {
					evt.value = 1;
				} else {
					evt.value = '';
				}
			},
			toggleTab(str, index) {
				this.currentIndex = index;
				this.$refs[str].show();
			},
			next: function(res) {
				this.showindex = res;
			},
			pre: function(res) {
				this.showindex = res;
			},
			onConfirme(val) {
				this.fields[this.currentIndex].value = val.result;
			},
			submit: function(e) {
				/* 将案件来源登记表的信息缓存，以便于关联使用 */
				api.postFormdata(this.dataL, (res) => {
					console.log(res)
					if (res && res.code == '0') {
						uni.hideLoading();
						uni.showToast({
							title: "提交成功",
							icon: "success"
						})
						uni.removeStorage({
							key: this.key,
							success: function(res) {
								setTimeout(function() {
									uni.navigateTo({
										url: "../punsucess/punsucess"
									})
								}, 300)
							}
						});
					} else {
						uni.hideLoading();
						uni.showToast({
							title: "提交失败",
							icon: "none"
						})
					}
				}, (err) => {
					console.log(err)
					uni.showToast({
						title: "错误",
						icon: "none"
					})
				});
			}
		},
	}
</script>

<style>
	@import url("../../../static/css/CommonPunish.css");
	.btn{
		background: #4b559d;
		color: #fff;
	}
</style>
