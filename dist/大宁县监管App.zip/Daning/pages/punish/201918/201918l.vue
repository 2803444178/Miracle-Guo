<template>
	<view>
		<view class="content">
			<form @submit="submit">
				<view class="itemcontent" v-if="fields">
					<view class="title-p">
						<input :value="fields['市'] ? fields['市'] : '' " disabled class="placeinput title" />
						市监<input :value="fields['监'] ? fields['监'] : ''" disabled class="placeinput title" />(
						<input :value="fields['市监号'] ? fields['市监号'] : ''" disabled class="placeinput title" />
						)<input :value="fields['号'] ? fields['号'] : ''" disabled class="placeinput title" />号
					</view>
					<view class="section">
						<view class="section__title">单位名称</view>
						<input class="section__input" :value="fields['单位名称'] ? fields['单位名称']  : '' " disabled />
						<view class="section__title">经查，你（单位）</view>
						<input class="section__input" :value="fields['行为'] ? fields['行为']  : '' " disabled />
						<view class="section__title">的行为，违反了</view>
						<input class="section__input" :value="fields['违反规定'] ? fields['违反规定']  : '' " disabled />
						<view class="section__title">的规定，依据</view>
						<input class="section__input" :value="fields['依据规定'] ? fields['依据规定']  : '' " disabled />
						<view class="section__title">的规定，现责令你（单位）</view>
						<view class="section__title">
							<label class="cheackboxlist">
								<checkbox class="radioitem" :checked="fields['立即予以改正'] == 1" />
								<text>立即予以改正</text>
							</label>
						</view>
						<view class="section__title">
							<label class="cheackboxlist">
								<checkbox class="radioitem" :checked="fields['在具体日期前改正'] == 1" />
								<text>在</text>
							</label>
						</view>
						<view class="section">
							<input class="section__input" :value="fields['改正日期'] ? fields['改正日期']  : '' " disabled />
						</view>
						<view class="section__title">前改正。（逾期不改的，本局将依据</view>
						<input class="section__input" :value="fields['逾期依据'] ? fields['逾期依据']  : '' " disabled />
						<view class="section__title">的规定</view>
						<input class="section__input" :value="fields['规定内容'] ? fields['规定内容']  : '' " disabled />
						<view class="section__title">改正内容及要求</view>
						<input class="section__input" :value="fields['改正内容及要求'] ? fields['改正内容及要求']  : '' " disabled />
					</view>
					<view class="section">
						<view class="section__title">如对本责令改正决定不服，可以自收到本通知书之日起六十日
							内向</view>
						<input class="section__input" :value="fields['人民政府'] ? fields['人民政府']  : '' " disabled />
						<view class="section__title">人民政府或者</view>
						<input class="section__input" :value="fields['市场监督管理局'] ? fields['市场监督管理局']  : '' " disabled />
						<view class="section__title">市场监督管理局申请行政复议；也可以在六个月内依法向</view>
						<input class="section__input" :value="fields['法院'] ? fields['法院']  : '' " disabled />
						<view class="section__title">法院提起行政诉讼。</view>
					</view>
					<view class="section">
						<view class="section__title">联系人：</view>
						<input class="section__input" :value="fields['联系人'] ? fields['联系人']  : '' " disabled />
					</view>
					<view class="section">
						<view class="section__title">联系方式：</view>
						<input class="section__input" :value="fields['联系电话'] ? fields['联系电话']  : '' " disabled />
					</view>
					<view class="section">
						<view class="section__title"> 日期：</view>
						<input class="section__input" :value="fields['日期'] ? fields['日期']  : '' " disabled />
					</view>
					<view class="itemcontent">
						本文书一式(
						<input :value="fields['文书份数']? fields['文书份数']:''" disabled class="placeinpu" />
						)份,(<input :value="fields['送达份数']? fields['送达份数']:''" disabled class="placeinpu" />
						)份送达，一份归档,其他剩余(<input :value="fields['其他份数']? fields['其他份数']:''" disabled class="placeinpu" />
						)份
					</view>
				</view>
			</form>
		</view>
	</view>
</template>

<script>
	import api from "@/api/api.js"
	import commonInfo from "@/common/common.js"
	var token = null;
	export default {
		data() {
			return {
				showindex: 1,
				dataL: "",
				currentIndex: "",
				fields: null,
			}
		},
		onLoad: function(res) {
			uni.setNavigationBarTitle({
				title: res.name
			})
			let that = this;
			let name = commonInfo.userinfo.name
			api.GetNowtoken(name, (res) => {
				console.log(res)
				token = res
			});
			api.getFormscree(res.id, res.recordId, (res) => {
				if (res && res.data) {
					let info = res;
					this.fields = info;
				}
			})
			uni.showLoading({
				title: "加载中"
			})
			uni.request({
				url: "http://h5.shouyunchina.com:8002/DNServices/businessInfoServlet",
				method: "GET",
				data: {
					recordId: res.recordId,
					id: res.id
				},
				success: async (res) => {
					if (res && res.data) {
						let {
							data: {
								values: values
							}
						} = res;
						let info = res.data;
						this.fields = info;
						uni.hideLoading()
					}
				},
				fail: (err) => {
					console.log(err);
					uni.showToast({
						title: "请求失败",
						icon: "none"
					})
				}
			});
		},
	}
</script>

<style>
	@import url("../../../static/css/CommonPunish.css");
</style>
