<template>
	<view>
		<uni-nav-bar @clickLeft="back" @clickRight="scan" background-color="#4b559d" status-bar="true" color="#fff" left-icon="back"
		 right-icon="search" title="行政处罚"></uni-nav-bar>
		<view class="content" style="padding-top: 20upx;">
			<mescroll-uni :top="120" :down="downOption" @down="downCallback" :up="upOption" @up="upCallback" @init="mescrollInit">
				<comon :list="pdList" :foodtype='entType' :Jur='haslist'></comon>
			</mescroll-uni>
		</view>
	</view>
</template>

<script>
	import api from "@/api/api.js"
	import uniNavBar from "@/component/uni-nav-bar/uni-nav-bar.vue"
	import url from "@/common/common.js"
	import MescrollUni from "@/component/mescroll-uni/mescroll-uni.vue";
	import Comon from "@/component/other/comon.vue";
	var apiurl;
	var _self;
	export default {
		components: {
			MescrollUni,
			Comon,
			uniNavBar
		},
		data() {
			return {
				mescroll: null, //mescroll实例对象
				downOption: {
					// use: false // 不使用下拉刷新
				},
				upOption: {
					auto: false, //是否在初始化后,自动执行上拉回调callback; 默认true
					// page: {
					// 	num: 0, // 当前页码,默认0,回调之前会加1,即callback(page)会从1开始
					// 	size: 10 // 每页数据的数量
					// }
					noMoreSize: 3, //如果列表已无数据,可设置列表的总数量要大于半页才显示无更多数据;避免列表数据过少(比如只有一条数据),显示无更多数据会不好看
					empty: {
						tip: '~ 搜索无结果 ~' // 提示
					}
				},
				pdList: [],
				colum: '',
				type: '',
				entType: '', //企业档案类型
				title: '企业档案',
				entName: '',
				haslist: true
			}
		},
		onLoad: function(res) {

		},
		methods: {
			back: function() {
				uni.navigateBack()
			},
			scan: function() {
				uni.navigateTo({
					url: "../../Enterprise/Filesearch/Filesearch?colum=punish"
				})
			},
			// mescroll组件初始化的回调,可获取到mescroll对象
			mescrollInit(mescroll) {
				this.mescroll = mescroll;
			},
			/*下拉刷新的回调 */
			downCallback(mescroll) {
				// 下拉刷新的回调,默认重置上拉加载列表为第一页 (自动执行 mescroll.num=1, 再触发upCallback方法 )
				mescroll.resetUpScroll()
			},
			/*上拉加载的回调: mescroll携带page的参数, 其中num:当前页 从1开始, size:每页数据条数,默认10 */
			upCallback(mescroll) {
				// 先清空列表,显示加载进度
				if (mescroll.num == 0) this.pdList = []; //如果是第一页需手动制空列表
				//联网加载数据
				mescroll.size = 15;
				this.getListDataFromNet(this.curWord, mescroll.num, mescroll.size, (curPageData) => {
					//联网成功的回调,隐藏下拉刷新和上拉加载的状态;
					mescroll.endSuccess(curPageData.length);
					//追加新数据
					this.pdList = this.pdList.concat(curPageData);
				}, () => {
					//联网失败的回调,隐藏下拉刷新的状态
					mescroll.endErr();
				})
			},
			/*联网加载列表数据
			在您的实际项目中,请参考官方写法: http://www.mescroll.com/uni.html#tagUpCallback
			请忽略getListDataFromNet的逻辑,这里仅仅是在本地模拟分页数据,本地演示用
			实际项目以您服务器接口返回的数据为准,无需本地处理分页.
			* */
			getListDataFromNet(curWord, pageNum, pageSize, successCallback, errorCallback) {
				var that = this;
				//延时一秒,模拟联网
				try {
					var that = this;
					let dataobjj = {
						pageIndex: pageNum + 1,
						pageSize: pageSize,
						entType: that.entName,
						memberID: url.userinfo.info.memberId
					}
					let userype = 'GET'
					api.getArchives(dataobjj, (res) => {
						console.log(res)
						var curPageData
						curPageData = res.data;
						//模拟分页数据
						let listData = [];
						for (let i = 0; i < curPageData.length; i++) {
							listData.push(curPageData[i]);
						}
						successCallback && successCallback(listData);
					});
				} catch (e) {
					errorCallback && errorCallback();
				}
			}

		}
	}
</script>

<style>
	view {
		box-sizing: border-box;
	}

	page {
		background: #f5f5f5;
	}

	.status_bar {
		height: var(--status-bar-height);
		width: 100%;
		background: #007aff;
		color: #fff;
	}

	.example-body {
		padding: 0;
	}

	.content {
		padding: 0;
	}
</style>
