<template>
	<view class="content">
		<form @submit="submit" v-if="fields">
			<view class="totcontent" v-show=" showindex == 1 ">
				<view class="section">
					<view class="section__title">企业名称：</view>
					<input class="section__input" :value="qyname" placeholder-class="placesize" placeholder="当事人单位名称"></input>
				</view>
				<view class="section">
					<view class="section__title">登记号：</view>
					<input class="section__input" v-model="fields['登记号'].value" placeholder-class="placesize" placeholder="登记号"></input>
				</view>
				<view class="section">
					<view class="section__title">登记时间：</view>
					<view class="iconbox">
						<input class="section__input" @tap="toggleTab('picker','登记时间')" v-model="fields['登记时间'].value" disabled="true"
						 placeholder-class="placesize" placeholder="登记时间"></input>
						<view class="iconfont icon-riqi xiala"></view>
					</view>
				</view>
				<view class="section">
					<view class="section__title">来源分类：</view>
					<radio-group class="cheackbox">
						<label class="cheackboxlist" @tap="radioChange(fields['监督检查'])">
							<checkbox class="radioitem" color="#007aff" value="1" /><text>监督检查</text>
						</label>
						<label class="cheackboxlist" @tap="radioChange(fields['投诉举报'])">
							<checkbox class="radioitem" color="#007aff" value="2" /><text>投诉、举报</text>
						</label>
						<label class="cheackboxlist" @tap="radioChange(fields['其他'])">
							<checkbox class="radioitem" color="#007aff" value="3" /><text>其他</text>
						</label>
						<label class="cheackboxlist" @tap="radioChange(fields['其他部门移送'])">
							<checkbox class="radioitem" color="#007aff" value="4" /><text>其他部门移送</text>
						</label>
						<label class="cheackboxlist" @tap="radioChange(fields['上级交办'])">
							<checkbox class="radioitem" color="#007aff" value="5" /><text>上级交办</text>
						</label>
					</radio-group>
				</view>
				<button class="btn" @tap="next(2)">下一步</button>
			</view>
			<view class="totcontent" v-show="showindex == 2">
				<view class="section">
					<view class="section__title">监督检查人员1名称：</view>
					<input class="section__input" v-model="fields['监督检查人姓名1'].value" placeholder-class="placesize" placeholder="监督检查人姓名1"></input>
				</view>
				<view class="section">
					<view class="section__title">监督检查人员1所属单位：</view>
					<input class="section__input" v-model="fields['监督检查人所属单位1'].value" placeholder-class="placesize" placeholder="监督检查人所属单位1"></input>
				</view>
				<view class="section">
					<view class="section__title">监督检查人员2名称：</view>
					<input class="section__input" v-model="fields['监督检查人姓名2'].value" placeholder-class="placesize" placeholder="监督检查人姓名2"></input>
				</view>
				<view class="section">
					<view class="section__title">监督检查人员2所属单位：</view>
					<input class="section__input" v-model="fields['监督检查人所属单位2'].value" placeholder-class="placesize" placeholder="监督检查人所属单位2"></input>
				</view>
				<view class="section">
					<view class="section__title">投诉人单位名称：</view>
					<input class="section__input" v-model="fields['投诉人单位名称'].value" placeholder-class="placesize" placeholder="投诉人单位名称"></input>
				</view>
				<view class="section">
					<view class="section__title">投诉人单位法定代表人：</view>
					<input class="section__input" v-model="fields['投诉人单位法定代表人'].value" placeholder-class="placesize" placeholder="投诉人单位法定代表人"></input>
				</view>
				<view class="section">
					<view class="section__title">投诉人个人姓名：</view>
					<input class="section__input" v-model="fields['投诉人个人姓名'].value" placeholder-class="placesize" placeholder="投诉人个人姓名"></input>
				</view>
				<view class="section">
					<view class="section__title">投诉人个人身份证：</view>
					<input class="section__input" v-model="fields['投诉人个人身份证'].value" placeholder-class="placesize" placeholder="投诉人个人身份证"></input>
				</view>
				<view class="section">
					<view class="section__title">投诉人联系电话：</view>
					<input class="section__input" v-model="fields['投诉人联系电话'].value" placeholder-class="placesize" placeholder="投诉人联系电话"></input>
				</view>
				<view class="section">
					<view class="section__title">投诉人其他联系方式：</view>
					<input class="section__input" v-model="fields['投诉人其他联系方式'].value" placeholder-class="placesize" placeholder="投诉人其他联系方式"></input>
				</view>
				<view class="section">
					<view class="section__title">投诉人联系地址：</view>
					<input class="section__input" v-model="fields['投诉人联系地址'].value" placeholder-class="placesize" placeholder="投诉人联系地址"></input>
				</view>
				<view class="combtn">
					<button class="btn" @tap="pre(1)">上一步</button>
					<button class="btn" @tap="next(3)">下一步</button>
				</view>
			</view>
			<view class="totcontent" v-show="showindex == 3">
				<view class="section">
					<view class="section__title">移送部门名称：</view>
					<input class="section__input" v-model="fields['移送部门名称'].value" placeholder-class="placesize" placeholder="移送部门名称"></input>
				</view>
				<view class="section">
					<view class="section__title">移送部门联系人：</view>
					<input class="section__input" v-model="fields['移送部门联系人'].value" placeholder-class="placesize" placeholder="移送部门联系人"></input>
				</view>
				<view class="section">
					<view class="section__title">移送部门联系电话：</view>
					<input class="section__input" v-model="fields['移送部门联系电话'].value" placeholder-class="placesize" placeholder="移送部门联系电话"></input>
				</view>
				<view class="section">
					<view class="section__title">移送部门联系地址：</view>
					<input class="section__input" v-model="fields['移送部门联系地址'].value" placeholder-class="placesize" placeholder="移送部门联系地址"></input>
				</view>
				<view class="section">
					<view class="section__title">当事人姓名：</view>
					<input class="section__input" v-model="fields['当事人姓名'].value" placeholder-class="placesize" placeholder="当事人姓名"></input>
				</view>
				<view class="section">
					<view class="section__title">当事人住所：</view>
					<input class="section__input" v-model="fields['当事人住所'].value" placeholder-class="placesize" placeholder="当事人住所"></input>
				</view>
				<view class="section">
					<view class="section__title">当事人联系电话：</view>
					<input class="section__input" v-model="fields['当事人联系电话'].value" placeholder-class="placesize" placeholder="当事人联系电话"></input>
				</view>
				<view class="section">
					<view class="section__title">当事人其他联系方式：</view>
					<input class="section__input" v-model="fields['当事人其他联系方式'].value" placeholder-class="placesize" placeholder="当事人其他联系方式"></input>
				</view>
				<view class="combtn">
					<button class="btn" @tap="pre(2)">上一步</button>
					<button class="btn" @tap="next(4)">下一步</button>
				</view>
			</view>
			<view class="totcontent" v-show="showindex == 4">
				<view class="section">
					<view class="section__title">案源登记内容：</view>
					<textarea class="section__text" v-model="fields['安源登记内容'].value" placeholder="案源登记内容" placeholder-class="placesize" />
					</view>
					<view class="section">
						<view class="section__title">案源登记人：</view>
						<view class="section_canvas" @tap="gocanvas('安源登记人')">
							<view v-if="!signImage['安源登记人']"  class="iconfont icon-iconzhengli_shouxieqianpi xiala"></view>
							<image :src="signImage['安源登记人']" class="qianfa" mode="aspectFit"></image>
						</view>
					</view>
					<view class="section">
						<view class="section__title"> 案源登记日期：</view>
						<view class="iconbox">
							<input class="section__input" @tap="toggleTab('picker','安源登记日期')" v-model="fields['安源登记日期'].value" disabled="true"
							 placeholder-class="placesize" placeholder="案源登记日期"></input>
							<view class="iconfont icon-riqi xiala"></view>
						</view>
					</view>
					<view class="combtn">
						<button class="btn" @tap="pre(3)">上一步</button>
						<button class="btn" @tap="next(5)">下一步</button>
					</view>
				</view>
				<view class="totcontent" v-show="showindex == 5">
					<view class="section">
						<view class="section__title">案源处理意见：</view>
						<textarea class="section__text" v-model="fields['安源处理意见'].value"  placeholder="安源处理意见" placeholder-class="placesize" />
						</view>
					<view class="section">
						<view class="section__title">办案机构负责人：</view>
						<view class="section_canvas" @tap="gocanvas('办案机构负责人')">
							<view v-if="!signImage['办案机构负责人']"  class="iconfont icon-iconzhengli_shouxieqianpi xiala"></view>
							<image :src="signImage['办案机构负责人']" class="qianfa" mode="aspectFit"></image>
						</view>
					</view>
					<view class="section">
						<view class="section__title"> 办案日期：</view>
						<view class="iconbox">
							<input class="section__input" @tap="toggleTab('picker','办案日期')" v-model="fields['办案日期'].value" disabled="true"
							 placeholder-class="placesize" placeholder="办案日期"></input>
							<view class="iconfont icon-riqi xiala"></view>
						</view>
					</view>
					<view class="section">
						<view class="section__title">备注：</view>
						<textarea class="section__text" v-model="fields['备注'].value" placeholder="备注" placeholder-class="placesize" />
						</view>
					<view class="combtn">
						<button class="btn" @tap="pre(4)">上一步</button>
						<button class="btn" form-type="submit" >提交</button>
					</view>
				</view>
			</form>
			<w-picker mode="dateTime" :current="false" @confirm="onConfirme" :disabledAfter="false" ref="picker"></w-picker>
		</view>
</template>

<script>
	import wPicker from "@/component/w-picker/w-picker.vue";
	import api from "@/api/api.js"
	import commonInfo from "@/common/common.js"
	var token;
	export default {
		components: {
			wPicker
		},
		data() {
			return {
				showindex: 1,
				dataL: "",
				currentIndex: "",
				fields: null,
				//签名信息
				signImage: {
					"安源登记人": "",
					"办案机构负责人": "",
				},
				// 企业信息
				enterpriseinfo: "",
				index: 0,
				qyname:'',
				backbtn: true,
			}
		},
		onLoad: function(res) {
			//设置标题
			uni.setNavigationBarTitle({
				title: res.title
			})
			this.title = res.title;
			let key = commonInfo.userinfo.qycase.ID + '' + res.title;
			this.key = key;
			let name = commonInfo.userinfo.name;
			//获取模板
			var qyid = commonInfo.userinfo.qyinfo.qyid;
			api.GetNowtoken(name, (Tokendata) => {
				token = Tokendata
				if (res) {
					api.getFormdata(key, res.id, name, (res, fields) => {
						for(let i  in fields){
							if(fields[i].name =='企业ID'){
								fields[i].value = qyid;
							}
						}
						this.dataL = res;
						this.fields = fields;
					})
				}
			});
			var that = this;
			uni.$on('update', function(data) {
				let arrobj = that.signImage;
				let name = data.name;
				let imgurl = data[data.name];
				let token = commonInfo.userinfo.token;
				let obj = that.dataL;
				api.Getsign(obj, name, imgurl, token, function(res) {
					that.dataL = res;
				})
				for (let i in arrobj) {
					if (arrobj[data.name] == "") {
						arrobj[data.name] = data[data.name]
					}
				}
			})
		},
		onBackPress: function() {
			var that = this;
			if (this.backbtn) {
				uni.showModal({
					title: '提示',
					content: '确定保存本次编辑？',
					success: function(res) {
						if (res.confirm) {
							let key = commonInfo.userinfo.qycase.ID + '' + that.title;
							console.log(that.dataL.data.values)
							uni.setStorageSync(key, that.dataL)
							that.backbtn = false;
							uni.navigateBack()
						} else if (res.cancel) {
							console.log('用户点击取消');
							that.backbtn = true;
						}
					}
				});
				return true
			} else {
				return false
			}
		},
		methods: {
			radioChange(evt) {
				let str = this.totalarr;
				if (evt.value == '') {
					evt.value = 1;
				} else {
					evt.value = '';
				}
			},
			bindTpye: function(e) {
				let index = e.target.value
				let value = this.Typeoptions[index].value;
				let dataobj = this.dataL.data.values;
				this.indexType = e.target.value
			},
			toggleTab(str, index) {
				this.$refs[str].show();
				this.currentIndex = index;
			},
			onConfirme(val) {
				this.fields[this.currentIndex].value = val.result;
			},
			next:function(res){
				this.showindex = res;
			},
			pre:function(res){
				this.showindex = res;
			},
			gocanvas: function(name) {
				uni.navigateTo({
					url: "../xzzcan/xzzcan?name=" + name + ""
				})
			},
			submit: function(e) {
				/* 将案件来源登记表的信息缓存，以便于关联使用 */
				api.postFormdata(this.dataL, (res) => {
					console.log(JSON.stringify(this.dataL))
					if (res && res.code == '0') {
						uni.hideLoading();
						uni.showToast({
							title: "提交成功",
							icon: "success"
						})
						uni.removeStorage({
							key: this.key,
							success: function(res) {
								setTimeout(function() {
									uni.navigateTo({
										url: "../punsucess/punsucess"
									})
								}, 300)
							}
						});

					} else {
						uni.hideLoading();
						uni.showToast({
							title: "提交失败",
							icon: "none"
						})
					}
				}, (err) => {
					console.log(err)
					uni.showToast({
						title: "错误",
						icon: "none"
					})
				});
			}
		},
	}
	
	/* 
		行政执法流程
		
		点击行政执法 ===> 企业列表（选择企业） ===> {
			1.这里是必须先填写案件来源登记表么？ 还是除了案件来源登记表还可以选择填写其他表单；然后再进行其他表单选择
		}
		
	 */
</script>

<style>
	@import url("../../../static/css/CommonPunish.css");
	@import url("../../../static/icon/iconfont.css");
</style>
