<template>
	<view class="content" v-if="fields">
		<view class="totcontent">
			<view class="section">
				<view class="section__title">登记号：</view>
				<input class="section__input" :value="fields['登记号'] ? fields['登记号'] : '' " disabled></input>
			</view>
			<view class="section">
				<view class="section__title">登记时间：</view>
				<view class="iconbox">
					<input class="section__input" :value="fields['登记时间'] ? fields['登记时间'] : '' " disabled></input>
				</view>
			</view>
			<view class="section">
				<view class="section__title">来源分类：</view>
				<radio-group class="cheackbox">
					<label class="cheackboxlist">
						<checkbox class="radioitem" :checked="fields['监督检查'] == 1 " /><text>监督检查</text>
					</label>
					<label class="cheackboxlist">
						<checkbox class="radioitem" :checked="fields['投诉举报'] == 1 " /><text>投诉、举报</text>
					</label>
					<label class="cheackboxlist">
						<checkbox class="radioitem" :checked="fields['其他'] == 1 " /><text>其他</text>
					</label>
					<label class="cheackboxlist">
						<checkbox class="radioitem" :checked="fields['其他部门移送'] == 1 " /><text>其他部门移送</text>
					</label>
					<label class="cheackboxlist" @tap="radioChange(fields['上级交办'])">
						<checkbox class="radioitem" :checked="fields['上级交办'] == 1 " /><text>上级交办</text>
					</label>
				</radio-group>
			</view>
			<view class="section">
				<view class="section__title">监督检查人员1名称：</view>
				<input class="section__input" :value="fields['监督检查人姓名1'] ? fields['监督检查人姓名1'] : '' " disabled></input>
			</view>
			<view class="section">
				<view class="section__title">监督检查人员1所属单位：</view>
				<input class="section__input" :value="fields['监督检查人所属单位1'] ? fields['监督检查人所属单位1'] : '' " disabled></input>
			</view>
			<view class="section">
				<view class="section__title">监督检查人员2名称：</view>
				<input class="section__input" :value="fields['监督检查人姓名2'] ? fields['监督检查人姓名2'] : '' " disabled></input>
			</view>
			<view class="section">
				<view class="section__title">监督检查人员2所属单位：</view>
				<input class="section__input" :value="fields['监督检查人所属单位2'] ? fields['监督检查人所属单位2'] : '' " disabled></input>
			</view>
			<view class="section">
				<view class="section__title">投诉人单位名称：</view>
				<input class="section__input" :value="fields['投诉人单位名称'] ? fields['投诉人单位名称'] : '' " disabled></input>
			</view>
			<view class="section">
				<view class="section__title">投诉人单位法定代表人：</view>
				<input class="section__input" :value="fields['投诉人单位法定代表人'] ? fields['投诉人单位法定代表人'] : '' " disabled></input>
			</view>
			<view class="section">
				<view class="section__title">投诉人个人姓名：</view>
				<input class="section__input" :value="fields['投诉人个人姓名'] ? fields['投诉人个人姓名'] : '' " disabled></input>
			</view>
			<view class="section">
				<view class="section__title">投诉人个人身份证：</view>
				<input class="section__input" :value="fields['投诉人个人身份证'] ? fields['投诉人个人身份证'] : '' " disabled></input>
			</view>
			<view class="section">
				<view class="section__title">投诉人联系电话：</view>
				<input class="section__input" :value="fields['投诉人联系电话'] ? fields['投诉人联系电话'] : '' " disabled></input>
			</view>
			<view class="section">
				<view class="section__title">投诉人其他联系方式：</view>
				<input class="section__input" :value="fields['投诉人其他联系方式'] ? fields['投诉人其他联系方式'] : '' " disabled></input>
			</view>
			<view class="section">
				<view class="section__title">投诉人联系地址：</view>
				<input class="section__input" :value="fields['投诉人联系地址'] ? fields['投诉人联系地址'] : '' " disabled></input>
			</view>

			<view class="section">
				<view class="section__title">移送部门名称：</view>
				<input class="section__input" :value="fields['移送部门名称'] ? fields['移送部门名称'] : '' " disabled></input>
			</view>
			<view class="section">
				<view class="section__title">移送部门联系人：</view>
				<input class="section__input" :value="fields['移送部门联系人'] ? fields['移送部门联系人'] : '' " disabled></input>
			</view>
			<view class="section">
				<view class="section__title">移送部门联系电话：</view>
				<input class="section__input" :value="fields['移送部门联系电话'] ? fields['移送部门联系电话'] : '' " disabled></input>
			</view>
			<view class="section">
				<view class="section__title">移送部门联系地址：</view>
				<input class="section__input" :value="fields['移送部门联系地址'] ? fields['移送部门联系地址'] : '' " disabled></input>
			</view>
			<view class="section">
				<view class="section__title">当事人姓名：</view>
				<input class="section__input" :value="fields['当事人姓名'] ? fields['当事人姓名'] : '' " disabled></input>
			</view>
			<view class="section">
				<view class="section__title">当事人住所：</view>
				<input class="section__input" :value="fields['当事人住所'] ? fields['当事人住所'] : '' " disabled></input>
			</view>
			<view class="section">
				<view class="section__title">当事人联系电话：</view>
				<input class="section__input" :value="fields['当事人联系电话'] ? fields['当事人联系电话'] : '' " disabled></input>
			</view>
			<view class="section">
				<view class="section__title">当事人其他联系方式：</view>
				<input class="section__input" :value="fields['当事人其他联系方式'] ? fields['当事人其他联系方式'] : '' " disabled></input>
			</view>

			<view class="section">
				<view class="section__title">安源登记内容：</view>
				<textarea class="section__text" :value="fields['安源登记内容'] ? fields['安源登记内容'] : '' " disabled></textarea>
			</view>
			<view class="section">
				<view class="section__title">安源登记人：</view>
				<view class="section_canvas">
					<image :src="fields['安源登记人']" class="qianfa" mode="aspectFit"></image>
				</view>
			</view>
			<view class="section">
				<view class="section__title"> 安源登记日期：</view>
				<input class="section__input" :value="fields['安源登记日期'] ? fields['安源登记日期'] : '' " disabled></input>
			</view>

			<view class="section">
				<view class="section__title">安源处理意见：</view>
				<textarea class="section__text" :value="fields['安源处理意见'] ? fields['安源处理意见'] : '' " disabled></textarea>
			</view>
			<view class="section">
				<view class="section__title">办案机构负责人：</view>

				<view class="section_canvas">
					<image :src="fields['办案机构负责人']" class="qianfa" mode="aspectFit"></image>
				</view>
			</view>
			<view class="section">
				<view class="section__title"> 办案日期：</view>
				<input class="section__input" :value="fields['办案日期'] ? fields['办案日期'] : '' " disabled></input>
			</view>
			<view class="section">
				<view class="section__title">备注：</view>
				<textarea class="section__text" :value="fields['备注'] ? fields['备注'] : '' " disabled></textarea>
			</view>
		</view>

	</view>
</template>

<script>
	import api from "@/api/api.js"
	import commonInfo from "@/common/common.js"
	var token = null;
	export default {
		data() {
			return {
				showindex: 1,
				dataL: "",
				currentIndex: "",
				fields: null,
			}
		},
		onLoad: function(res) {
			uni.setNavigationBarTitle({
				title: res.name
			})
			let that = this;
			let name = commonInfo.userinfo.name
			api.GetNowtoken(name, (res) => {
				console.log(res)
				token = res
			});
			uni.request({
				url: "http://h5.shouyunchina.com:8002/DNServices/businessInfoServlet",
				method: "GET",
				data: {
					recordId: res.recordId,
					id: res.id
				},
				success: async (res) => {
					uni.hideLoading()
					if (res) {
						let {
							data: {
								values: values
							}
						} = res;
						if (res.data) {
							let info = res.data;
							info['办案机构负责人'] = info['办案机构负责人'] && await this.getimg(info['办案机构负责人']);
							info['安源登记人'] = info['安源登记人'] && await this.getimg(info['安源登记人']);
							console.log(info)
							this.fields = info;
							console.log(this.fields)
						}
					}
				},
				fail: (err) => {
					console.log(err);
					uni.showToast({
						title: "请求失败",
						icon: "none"
					})
				}
			});
		},
		methods: {
			fillet: function(res) {
				if (res == '8361367595765681198') {
					return '符合'
				} else if (res == '-2066416451667277405') {
					return '基本符合'
				} else if (res == '6571312966818286323') {
					return '不符合'
				} else if (res == '986401131406182056') {
					return '通过'
				} else if (res == '-233736429269465346') {
					return '书面整改'
				} else if (res == '-8708609701263029876') {
					return '停业整顿'
				} else if (res == '8997802166051095014') {
					return '否'
				} else if (res == '-6831193320631809582') {
					return '是'
				} else if (res == '5885808606164896166') {
					return '已向你宣读'
				} else if (res == '6573754221301875061') {
					return '请核对'
				} else if (res == '1068839251742507953') {
					return '全部证据'
				} else if (res == '6513549339120258159') {
					return '部分证据'
				} else if (res == '3117111607399304046') {
					return '场所清单'
				} else if (res == '-3564747582551603596') {
					return '财物清单'
				} else if (res == '2944129172193822406') {
					return '设施清单'
				} else if (res == '6897086536934377384') {
					return '男'
				} else if (res == '-4637397066553733657') {
					return '女'
				} else if (res == '3495632856930011401') {
					return '设施'
				} else if (res == '-9102571236001362048') {
					return '财物'
				} else if (res == '7350172593853450270') {
					return '场所'
				} else if (res == '-456001630006194760') {
					return '扣押'
				} else if (res == '1472044003399387940') {
					return '查封'
				} else if (res == '-4807422774013443093') {
					return '立案'
				} else if (res == '-8528133649199512965') {
					return '不予立案'
				}
			},
			getimg: function(id) {
				console.log(id)
				return new Promise((resolve, reject) => {
					let name = commonInfo.userinfo.name
					api.GetNowtoken(name, (res) => {
						console.log(name)
						console.log(res)
						uni.hideLoading()
						let url = "http://183.203.90.25:8888/seeyon/services/downloadService?token=" + res +
							"&fileId=" + id + "";
						resolve(url)
					});
				})
			},
		}
	}
</script>

<style>
	@import url("../../../static/css/CommonPunish.css");
	@import url("../../../static/icon/iconfont.css");
</style>
