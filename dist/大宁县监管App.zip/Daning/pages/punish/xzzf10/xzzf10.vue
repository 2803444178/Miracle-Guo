<template>
	<view>
		<view class="content">
			<form @submit="submit" v-if="fields">
				<view class="totcontent" v-show=" showindex == 1 ">
					<view class="title-p">
						<input v-model="fields['市'].value" placeholder-class="placesize" class="placeinput title" />
						市监<input v-model="fields['监'].value" placeholder-class="placesize" class="placeinput title" />(
						<input v-model="fields['市监号'].value" placeholder-class="placesize" class="placeinput title" />
						)<input v-model="fields['号'].value" placeholder-class="placesize" class="placeinput title" />号
					</view>
					<view class="qyname">
						<input v-model="fields['市场监管局名称'].value" placeholder-class="placesize" class="placeinput inputitle" value="" />
					</view>
					<view class="section">
						<view class="section__title">为调查了解：</view>
					</view>
					<view class="section">
						<input v-model="fields['案件名称'].value" placeholder="案件名称" placeholder-class="placesize" class="section__input" />
					</view>
					<view class="section">
						<view class="section__title">请于：</view>
					</view>
					<view class="section ">
						<view class="iconbox">
							<input class="section__input" @tap="toggleTab('picker','报到日期')" v-model="fields['报到日期'].value" disabled="true"
							 placeholder-class="placesize" placeholder="报到日期"></input>
							<view class="iconfont icon-riqi xiala"></view>
						</view>
					</view>
					<view class="section">
						<view class="section__title">到：</view>
					</view>
					<view class="section">
						<input v-model="fields['报到位置'].value" placeholder="报到位置" placeholder-class="placesize" class="section__input" />
					</view>
					<view class="section">
						<view class="section__title">接受询问调查。依据《中华人民共和国行政处罚法》第三十七条第一款
							的规定，你（单位）有如实回答询问、协助调查的义务。</view>
					</view>
					<button class="btn" @tap="next(2)">下一步</button>
				</view>
				<view class="totcontent" v-show=" showindex == 2 ">
					<view class="section">
						<view class="section__title">请携带以下材料：</view>
					</view>
					<view class="section">
						<view class="section__titlm">材料1：</view>
						<input class="section__input" v-model="fields['材料1'].value" placeholder-class="placesize" placeholder="材料1"></input>
					</view>
					<view class="section">
						<view class="section__titlm">材料1：</view>
						<input class="section__input" v-model="fields['材料2'].value" placeholder-class="placesize" placeholder="材料2"></input>
					</view>

					<view class="section">
						<view class="section__titlm">材料1：</view>
						<input class="section__input" v-model="fields['材料3'].value" placeholder-class="placesize" placeholder="材料3"></input>
					</view>
					<view class="combtn">
						<button class="btn" @tap="pre(1)">上一步</button>
						<button class="btn" @tap="next(3)">下一步</button>
					</view>
				</view>
				<view class="totcontent" v-show=" showindex == 3 ">
					<view class="section">
						<view class="section__title">如你（单位）委托其他人员接受询问调查的，委托代理人应同时提供
							授权委托书及委托代理人身份证明。</view>
					</view>
					<view class="section">
						<view class="section__title">办案人员1：</view>
						<input v-model="fields['办案人员1'].value" placeholder-class="placesize" class="section__input" placeholder="办案人员1名称" />
					</view>
					<view class="section">
						<view class="section__title">联系电话1：</view>
						<input v-model="fields['联系电话1'].value" placeholder-class="placesize" class="section__input" placeholder="联系方式1" />
					</view>
					<view class="section">
						<view class="section__title">办案人员2：</view>
						<input v-model="fields['办案人员2'].value" placeholder-class="placesize" class="section__input" placeholder="办案人员2名称" />
					</view>
					<view class="section">
						<view class="section__title">联系电话2：</view>
						<input v-model="fields['联系电话2'].value" placeholder-class="placesize" class="section__input" placeholder="联系方式2" />
					</view>
					<view class="section">
						<view class="section__title"> 日期：</view>

						<view class="iconbox">
							<input class="section__input" @tap="toggleTab('picker','日期')" v-model="fields['日期'].value" disabled="true"
							 placeholder-class="placesize" placeholder="日期"></input>
							<view class="iconfont icon-riqi xiala"></view>
						</view>
					</view>
					<view class="itemcontent">
						本文书一式(
						<input v-model="fields['文书份数'].value" placeholder-class="placesize" class="placeinpu" />
						)份,(<input v-model="fields['送达份数'].value" placeholder-class="placesize" class="placeinpu" />
						)份送达，一份归档,其他剩余(<input v-model="fields['其他份数'].value" placeholder-class="placesize" class="placeinpu" />
						)份
					</view>
					<view class="combtn">
						<button class="btn" @tap="pre(2)">上一步</button>
						<button class="btn" form-type="submit">提交</button>
					</view>
				</view>
			</form>
			<w-picker mode="date" :current="false" @confirm="onConfirme" :disabledAfter="false" ref="picker"></w-picker>
		</view>
	</view>
</template>

<script>
	import api from "@/api/api.js"
	import commonInfo from "@/common/common.js"
	var token;
	export default {
		data() {
			return {
				showindex: 1,
				dataL: "",
				currentIndex: "",
				fields: null,
				//签名信息
				signImage: {
					"经办人": "",
					"办案机构负责人": "",
					"部门负责人": "",
				},
				backbtn: true,
				title: null,
				key: null
			}
		},
		onLoad: function(res) {
			//设置标题
			uni.setNavigationBarTitle({
				title: res.title
			})
			this.title = res.title;
			let key = commonInfo.userinfo.qycase.ID + '' + res.title;
			this.key = key;
			let name = commonInfo.userinfo.name;
			//获取模板
			console.log(commonInfo.userinfo.qycase)
			api.GetNowtoken(name, (Tokendata) => {
				token = Tokendata
				if (res) {
					api.getFormdata(key, res.id, name, (res, fields) => {
						console.log(fields)
						api.initFields(fields, commonInfo.userinfo.qycase, 'xzzf10');
						res.token = Tokendata;
						this.dataL = res;
						this.fields = fields;
					})
				}
			});
			var that = this;
			uni.$on('update', function(data) {
				let arrobj = that.signImage;
				let name = data.name;
				let imgurl = data[data.name];
				let token = commonInfo.userinfo.token;
				let obj = that.dataL;
				api.Getsign(obj, name, imgurl, token, function(res) {
					that.dataL = res;
				})
				for (let i in arrobj) {
					if (arrobj[data.name] == "") {
						arrobj[data.name] = data[data.name]
					}
				}
			})
		},
		onBackPress: function() {
			var that = this;
			if (this.backbtn) {
				uni.showModal({
					title: '提示',
					content: '确定保存本次编辑？',
					success: function(res) {
						if (res.confirm) {
							let key = commonInfo.userinfo.qycase.ID + '' + that.title;
							console.log(that.dataL.data.values)
							uni.setStorageSync(key, that.dataL)
							that.backbtn = false;
							uni.navigateBack()
						} else if (res.cancel) {
							console.log('用户点击取消');
							that.backbtn = true;
						}
					}
				});
				return true
			} else {
				return false
			}
		},
		methods: {
			toggleTab(str, index) {
				this.currentIndex = index;
				this.$refs[str].show();
			},
			onConfirme(val) {
				this.fields[this.currentIndex].value = val.result
			},
			next: function(res) {
				this.showindex = res;
			},
			pre: function(res) {
				this.showindex = res;
			},
			submit: function(e) {
				/* 将案件来源登记表的信息缓存，以便于关联使用 */
				api.postFormdata(this.dataL, (res) => {
					console.log(res)
					if (res && res.code == '0') {
						uni.hideLoading();
						uni.showToast({
							title: "提交成功",
							icon: "success"
						})
						uni.removeStorage({
							key: this.key,
							success: function(res) {
								setTimeout(function() {
									uni.navigateTo({
										url: "../punsucess/punsucess"
									})
								}, 300)
							}
						});
					} else {
						uni.hideLoading();
						uni.showToast({
							title: "提交失败",
							icon: "none"
						})
					}
				}, (err) => {
					console.log(err)
					uni.showToast({
						title: "错误",
						icon: "none"
					})
				});
			}
		},
	}
</script>

<style>
	@import url("../../../static/css/CommonPunish.css");
</style>
