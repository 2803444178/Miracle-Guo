<template>
	<view class="content">
		<form @submit="submit">
			<view class="totcontent"  v-if="fields">
				<view class="title-p">
					<input :value="fields['市'] ? fields['市'] : '' " disabled placeholder-class="placesize" class="placeinput title" />
					市监<input :value="fields['监'] ? fields['监'] : ''" disabled placeholder-class="placesize" class="placeinput title" />(
					<input :value="fields['市监号'] ? fields['市监号'] : ''" disabled placeholder-class="placesize" class="placeinput title" />
					)<input :value="fields['号'] ? fields['号'] : ''" disabled placeholder-class="placesize" class="placeinput title" />号
				</view>
				<view class="qyname">
					<input :value="fields['市场监管局名称']? fields['市场监管局名称'] : '' " disabled placeholder-class="placesize" class="placeinput inputitle" />
				</view>
				<view class="section">
					<view class="section__title">为调查了解：</view>
				</view>
				<view class="section">
					<input :value="fields['案件名称']? fields['案件名称'] : '' " disabled placeholder="案件名称" placeholder-class="placesize"
					 class="section__input" />
				</view>
				<view class="section">
					<view class="section__title">请于：</view>
				</view>
				<view class="section ">
					<input :value="fields['报到日期']? fields['报到日期'] : '' " disabled placeholder-class="placesize" class="section__input"
					 disabled="true"></input>
				</view>
				<view class="section">
					<view class="section__title">到：</view>
				</view>
				<view class="section">
					<input :value="fields['报到位置']? fields['报到位置'] : '' " disabled placeholder="报到位置" placeholder-class="placesize"
					 class="section__input" />
				</view>
				<view class="section">
					<view class="section__title">接受询问调查。依据《中华人民共和国行政处罚法》第三十七条第一款
						的规定，你（单位）有如实回答询问、协助调查的义务。</view>
				</view>
				<view class="section">
					<view class="section__title">请携带以下材料：</view>
				</view>
				<view class="section">
					<view class="section__titlm">材料1：</view>
					<input class="section__input" :value="fields['材料1']? fields['材料1'] : '' " disabled placeholder-class="placesize"
					 placeholder="材料1"></input>
				</view>
				<view class="section">
					<view class="section__titlm">材料1：</view>
					<input class="section__input" :value="fields['材料2']? fields['材料2'] : '' " disabled placeholder-class="placesize"
					 placeholder="材料2"></input>
				</view>

				<view class="section">
					<view class="section__titlm">材料1：</view>
					<input class="section__input" :value="fields['材料3']? fields['材料3'] : '' " disabled placeholder-class="placesize"
					 placeholder="材料3"></input>
				</view>

				<view class="section">
					<view class="section__title">如你（单位）委托其他人员接受询问调查的，委托代理人应同时提供
						授权委托书及委托代理人身份证明。</view>
				</view>
				<view class="section">
					<view class="section__title">办案人员1：</view>
					<input :value="fields['办案人员1']? fields['办案人员1'] : '' " disabled placeholder-class="placesize" class="section__input"
					 placeholder="办案人员1名称" />
				</view>
				<view class="section">
					<view class="section__title">联系电话1：</view>
					<input :value="fields['联系电话1']? fields['联系电话1'] : '' " disabled placeholder-class="placesize" class="section__input"
					 placeholder="联系方式1" />
				</view>
				<view class="section">
					<view class="section__title">办案人员2：</view>
					<input :value="fields['办案人员2']? fields['办案人员2'] : '' " disabled placeholder-class="placesize" class="section__input"
					 placeholder="办案人员2名称" />
				</view>
				<view class="section">
					<view class="section__title">联系电话2：</view>
					<input :value="fields['联系电话2']? fields['联系电话2'] : '' " disabled placeholder-class="placesize" class="section__input"
					 placeholder="联系方式2" />
				</view>
				<view class="section">
					<view class="section__title"> 日期：</view>
					<view class="iconbox">
						<input class="section__input" disabled :value="fields['日期']? fields['日期'] : '' " disabled="true"
						 placeholder-class="placesize"></input>
					</view>
				</view>
				<view class="itemcontent">
					本文书一式(
					<input :value="fields['文书份数']" disabled placeholder-class="placesize" class="placeinpu" />
					)份,(<input :value="fields['送达份数']" disabled placeholder-class="placesize" class="placeinpu" />
					)份送达，一份归档,其他剩余(<input :value="fields['其他份数']" disabled placeholder-class="placesize" class="placeinpu" />
					)份
				</view>

			</view>
		</form>
	</view>
</template>

<script>
	import api from "@/api/api.js"
	import commonInfo from "@/common/common.js"
	var token = null;
	export default {
		data() {
			return {
				dataL: "",
				currentIndex: "",
				fields: null,
			}
		},
		onLoad: function(res) {
			uni.setNavigationBarTitle({
				title: res.name
			})
			let that = this;
			let name = commonInfo.userinfo.name
			console.log(name)
			api.GetNowtoken(name, (res) => {
				console.log(res)
				token = res
			});
			api.getFormscree(res.id, res.recordId, (res) => {
				this.fields = res;
			})
		},
	}
</script>

<style>
	@import url("../../../static/css/CommonPunish.css");
</style>
