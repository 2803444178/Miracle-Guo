<template>
	<view>
		<view class="content">
			<form @submit="submit" v-if="fields">
				<view class="totcontent" v-show=" showindex == 1 ">
					<view class="title-p">
						<input v-model="fields['市'].value" placeholder-class="placesize" class="placeinput title" />
						市监<input v-model="fields['监'].value" placeholder-class="placesize" class="placeinput title" />(
						<input v-model="fields['市监号'].value" placeholder-class="placesize" class="placeinput title" />
						)<input v-model="fields['号'].value" placeholder-class="placesize" class="placeinput title" />号
					</view>
					<view class="section">
						<view class="section__title">当事人：</view>
						<input class="section__input" v-model="fields['当事人'].value" placeholder-class="placesize" placeholder="当事人姓名"></input>
					</view>
					<view class="section">
						<view class="section__title">主体资格证照名称：</view>
						<input class="section__input" v-model="fields['主题资格证照名称'].value" placeholder-class="placesize" placeholder="主体资格证照名称"></input>
					</view>
					<view class="section">
						<view class="section__title">统一社会信用代码（注号）：</view>
						<input class="section__input" v-model="fields['统一社会信用代码'].value" placeholder-class="placesize" placeholder="主体资格证照名称"></input>
					</view>
					<view class="section">
						<view class="section__title">住所（住址）：</view>
						<input class="section__input" v-model="fields['住所'].value" placeholder-class="placesize" placeholder="住所"></input>
					</view>
					<view class="section">
						<view class="section__title">法定代表人（负责人、经营者）：</view>
						<input class="section__input" v-model="fields['法定代表人'].value" placeholder-class="placesize" placeholder="法定代表人"></input>
					</view>
					<view class="section">
						<view class="section__title">身份证（其他有效证件）号码）：</view>
						<input class="section__input" v-model="fields['身份证号码'].value" placeholder-class="placesize" placeholder="身份证号码"></input>
					</view>
					<view class="section">
						<view class="section__title">联系电话：</view>
						<input class="section__input" v-model="fields['联系电话'].value" placeholder-class="placesize" placeholder="联系电话"></input>
					</view>
					<view class="section">
						<view class="section__title">其他联系地址：</view>
						<input class="section__input" v-model="fields['其他联系地址'].value" placeholder-class="placesize" placeholder="其他联系地址"></input>
					</view>
					<button class="btn" @tap="next(2)">下一步</button>
				</view>
				<view class="totcontent" v-show=" showindex == 2 ">
					<view class="section">
						<view class="section__title">为调查你（单位）涉嫌：</view>
					</view>
					<view class="section">
						<input v-model="fields['涉嫌行为'].value" placeholder="涉嫌行为" placeholder-class="placesize" class="section__input" />
					</view>
					<view class="section">
						<view class="section__title">依据《中华人民共和国行政处罚法》第三十七条第二款的规定，本局决定对你（单位）有关证据［详见：</view>
					</view>

					<view class="iconbox">
						<picker class="pickee" @change="bindTpye($event,fields['场所设施财物清单'],'1')" :range="fields['场所设施财物清单'].options"
						 range-key="label">
							<view class="section__input">{{fields['场所设施财物清单'].options[index]?fields['场所设施财物清单'].options[index].label : '请选择'}}</view>
						</picker>
						<view class="iconfont icon-xiala xiala"></view>
					</view>
					<view class="section">
						<view class="section__title">文书编号：</view>
						<input class="section__input" v-model="fields['财物清单文书编号'].value" placeholder-class="placesize" placeholder="财物清单文书编号"></input>
					</view>
					<view class="section ">
						<view class="section__title">采取先行登记保存措施。先行登记保存的证据，存放在：</view>
						<input class="section__input" v-model="fields['存放位置'].value" placeholder-class="placesize" placeholder="存放位置"></input>
					</view>
					<view class="section">
						<view class="section__title">
							在此期间，你（单位）或者有关人员不得
							损毁、销毁或者转移证据。
						</view>
					</view>
					<view class="section">
						<view class="section__title">
							本局将在七日内对先行登记保存的证据依法作出处理决定。逾期未作出
							处理决定的，先行登记保存措施自动解除。
						</view>
					</view>
					<view class="combtn">
						<button class="btn" @tap="pre(1)">上一步</button>
						<button class="btn" @tap="next(3)">下一步</button>
					</view>
				</view>
				<view class="totcontent" v-show=" showindex == 3 ">
					<view class="section">
						<view class="section__title">联系人：</view>
						<input v-model="fields['联系人'].value" placeholder="联系人" placeholder-class="placesize" class="section__input" />
					</view>
					<view class="section">
						<view class="section__title">联系方式：</view>
						<input v-model="fields['联系方式'].value" placeholder="联系方式" placeholder-class="placesize" class="section__input" />
					</view>
					<view class="section">
						<view class="section__title">附件：</view>
						<view class="iconbox">
							<picker class="pickee" @change="bindTpye($event,fields['附件场所设施财物清单'],'2')" :range="fields['附件场所设施财物清单'].options"
							 range-key="label">
								<view class="section__input">{{fields['附件场所设施财物清单'].options[indexq]?fields['附件场所设施财物清单'].options[indexq].label : '请选择'}}</view>
							</picker>
							<view class="iconfont icon-xiala xiala"></view>
						</view>
					</view>
					<view class="section">
						<view class="section__title">附件文书编号：</view>
						<input v-model="fields['附件文书编号'].value" placeholder="附件文书编号" placeholder-class="placesize" class="section__input" />
					</view>
					<view class="section">
						<view class="section__title"> 日期：</view>
						<view class="iconbox">
							<input class="section__input" @tap="toggleTab('picker','日期')" v-model="fields['日期'].value" disabled="true"
							 placeholder-class="placesize" placeholder="日期"></input>
							<view class="iconfont icon-riqi xiala"></view>
						</view>
					</view>
					<view class="itemcontent">
						本文书一式(
						<input v-model="fields['文书份数'].value" placeholder-class="placesize" class="placeinpu" />
						)份,(<input v-model="fields['送达份数'].value" placeholder-class="placesize" class="placeinpu" />
						)份送达，一份归档,其他剩余(<input v-model="fields['其他份数'].value" placeholder-class="placesize" class="placeinpu" />
						)份
					</view>
					<view class="combtn">
						<button class="btn" @tap="pre(2)">上一步</button>
						<button class="btn" form-type="submit">提交</button>
					</view>
				</view>
				<w-picker mode="dateTime" hasSecond="true" :current="false" @confirm="onConfirme" :disabledAfter="false" ref="picker"></w-picker>
			</form>
		</view>
	</view>
</template>

<script>
	import api from "@/api/api.js"
	import commonInfo from "@/common/common.js";
	var token;
	export default {
		data() {
			return {
				showindex: 1,
				dataL: "",
				fields:null,
				nowdate: '',
				currentIndex: "",
				signImage: {
					"经办人": "",
					"办案机构负责人": "",
					"部门负责人": "",
				},
				// 企业信息
				enterpriseinfo: "",
				index: -1,
				indexq: -1,
				backbtn: true,
				key:null,
			}
		},
		onBackPress: function() {
			var that = this;
			if (this.backbtn) {
				uni.showModal({
					title: '提示',
					content: '确定保存本次编辑？',
					success: function(res) {
						if (res.confirm) {
							let key = commonInfo.userinfo.qycase.ID + '' + that.title;
							console.log(that.dataL.data.values)
							uni.setStorageSync(key, that.dataL)
							that.backbtn = false;
							uni.navigateBack()
						} else if (res.cancel) {
							console.log('用户点击取消');
							that.backbtn = true;
						}
					}
				});
				return true
			} else {
				return false
			}
		},
		onLoad: function(res) {
			//设置标题
			uni.setNavigationBarTitle({
				title: res.title
			})
			this.title = res.title;
			let key = commonInfo.userinfo.qycase.ID + '' + res.title;
			this.key = key;
			let name = commonInfo.userinfo.name;
			//获取模板
			console.log(commonInfo.userinfo.qycase)
			api.GetNowtoken(name, (Tokendata) => {
				token = Tokendata
				if (res) {
					api.getFormdata(key, res.id, name, (res, fields) => {
						console.log(fields)
						api.initFields(fields, commonInfo.userinfo.qycase, 'xzzf15');
						res.token = Tokendata;
						this.dataL = res;
						this.fields = fields;
					})
				}
			});
			var that = this;
			uni.$on('update', function(data) {
				let arrobj = that.signImage;
				let name = data.name;
				let imgurl = data[data.name];
				let token = commonInfo.userinfo.token;
				let obj = that.dataL;
				api.Getsign(obj, name, imgurl, token, function(res) {
					that.dataL = res;
				})
				for (let i in arrobj) {
					if (arrobj[data.name] == "") {
						arrobj[data.name] = data[data.name]
					}
				}
			})
		},
		methods: {
			next: function(res) {
				this.showindex = res;
			},
			pre: function(res) {
				this.showindex = res;
			},
			toggleTab(str, index) {
				this.currentIndex = index;
				this.$refs[str].show();
			},
			onConfirme(val) {
				this.fields[this.currentIndex].value = val.result
			},

			bindTpye: function(e, field, intype) {
				console.log(intype)
				let name = field.name;
				let index = e.target.value
				let value = this.fields[name].options[index].value;
				field.value = value;
				if (intype == 1) {
					this.index = index;
				} else if (intype == 2) {
					this.indexq = index
				}
			},
			submit: function(e) {
				/* 将案件来源登记表的信息缓存，以便于关联使用 */
				api.postFormdata(this.dataL, (res) => {
					console.log(res)
					if (res && res.code == '0') {
						uni.hideLoading();
						uni.showToast({
							title: "提交成功",
							icon: "success"
						})
						uni.removeStorage({
							key: this.key,
							success: function(res) {
								setTimeout(function() {
									uni.navigateTo({
										url: "../punsucess/punsucess"
									})
								}, 300)
							}
						});
					} else {
						uni.hideLoading();
						uni.showToast({
							title: "提交失败",
							icon: "none"
						})
					}
				}, (err) => {
					console.log(err)
					uni.showToast({
						title: "错误",
						icon: "none"
					})
				});
			}
		},
	}
</script>

<style>
	@import url("../../../static/css/CommonPunish.css");
</style>
