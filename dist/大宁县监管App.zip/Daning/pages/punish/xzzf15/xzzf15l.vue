<template>
	<view>
		<view class="content">
			<form @submit="submit">
				<view class="totcontent" v-if="fields">
					<view class="title-p">
						<input :value="fields['市'] ? fields['市'] : '' " disabled class="placeinput title" />
						市监<input :value="fields['监'] ? fields['监'] : ''" disabled class="placeinput title" />(
						<input :value="fields['市监号'] ? fields['市监号'] : ''" disabled class="placeinput title" />
						)<input :value="fields['号'] ? fields['号'] : ''" disabled class="placeinput title" />号
					</view>
					<view class="section">
						<view class="section__title">当事人：</view>
						<input :value="fields['当事人'] ?  fields['当事人'] : ''" class="section__input" disabled />
					</view>
					<view class="section">
						<view class="section__title">主体资格证照名称：</view>
						<input :value="fields['主题资格证照名称'] ?  fields['主题资格证照名称'] : ''" class="section__input" disabled />
					</view>
					<view class="section">
						<view class="section__title">统一社会信用代码（注号）：</view>
						<input :value="fields['统一社会信用代码'] ?  fields['统一社会信用代码'] : ''" class="section__input" disabled />
					</view>
					<view class="section">
						<view class="section__title">住所（住址）：</view>
						<input :value="fields['住所'] ?  fields['住所'] : ''" class="section__input" disabled />
					</view>
					<view class="section">
						<view class="section__title">法定代表人（负责人、经营者）：</view>
						<input :value="fields['法定代表人'] ?  fields['法定代表人'] : ''" class="section__input" disabled />
					</view>
					<view class="section">
						<view class="section__title">身份证（其他有效证件）号码）：</view>
						<input :value="fields['身份证号码'] ?  fields['身份证号码'] : ''" class="section__input" disabled />
					</view>
					<view class="section">
						<view class="section__title">联系电话：</view>
						<input :value="fields['联系电话'] ?  fields['联系电话'] : ''" class="section__input" disabled />
					</view>
					<view class="section">
						<view class="section__title">其他联系地址：</view>
						<input :value="fields['其他联系地址'] ?  fields['其他联系地址'] : ''" class="section__input" disabled />
					</view>
					<view class="section">
						<view class="section__title">为调查你（单位）涉嫌：</view>
					</view>
					<view class="section">
						<input :value="fields['涉嫌行为'] ?  fields['涉嫌行为'] : ''" class="section__input" disabled />
					</view>
					<view class="section">
						<view class="section__title">依据《中华人民共和国行政处罚法》第三十七条第二款的规定，本局决定对你（单位）有关证据［详见：</view>
					</view>
					<view class="section">
						<input :value="fields['场所设施财物清单'] ?  fields['场所设施财物清单'] : ''" class="section__input" disabled />
					</view>
					<view class="section">
						<view class="section__title">文书编号：</view>
						<input :value="fields['财物清单文书编号'] ?  fields['财物清单文书编号'] : ''" class="section__input" disabled />
					</view>
					<view class="section ">
						<view class="section__title">采取先行登记保存措施。先行登记保存的证据，存放在：</view>
						<input :value="fields['存放位置'] ?  fields['存放位置'] : ''" class="section__input" disabled />
					</view>
					<view class="section">
						<view class="section__title">
							在此期间，你（单位）或者有关人员不得
							损毁、销毁或者转移证据。
						</view>
					</view>
					<view class="section">
						<view class="section__title">
							本局将在七日内对先行登记保存的证据依法作出处理决定。逾期未作出
							处理决定的，先行登记保存措施自动解除。
						</view>
					</view>
					<view class="section">
						<view class="section__title">联系人：</view>
						<input :value="fields['联系人'] ?  fields['联系人'] : ''" class="section__input" disabled />
					</view>
					<view class="section">
						<view class="section__title">联系方式：</view>
						<input :value="fields['联系方式'] ?  fields['联系方式'] : ''" class="section__input" disabled />
					</view>
					<view class="section">
						<view class="section__title">附件：</view>
						<input :value="fields['附件场所设施财物清单'] ?  fields['附件场所设施财物清单'] : ''" class="section__input" disabled />
					</view>
					<view class="section">
						<view class="section__title">附件文书编号：</view>
						<input :value="fields['附件文书编号'] ?  fields['附件文书编号'] : ''" class="section__input" disabled />
					</view>
					<view class="section">
						<view class="section__title"> 日期：</view>
						<input :value="fields['日期'] ?  fields['日期'] : ''" class="section__input" disabled />
					</view>
					<view class="itemcontent">
						本文书一式(
						<input :value="fields['文书份数']? fields['文书份数']:''" disabled class="placeinpu" />
						)份,(<input :value="fields['送达份数']? fields['送达份数']:''" disabled class="placeinpu" />
						)份送达，一份归档,其他剩余(<input :value="fields['其他份数']? fields['其他份数']:''" disabled class="placeinpu" />
						)份
					</view>
				</view>
			</form>
		</view>
	</view>
</template>

<script>
	import api from "@/api/api.js"
	import commonInfo from "@/common/common.js"
	var token = null;
	export default {
		data() {
			return {
				showindex: 1,
				dataL: "",
				nowdate: '',
				currentIndex: "",
				//签名信息
				signImage: {
					"被询问人签名": "",
				},
				fields: null
			}
		},
		onLoad: function(res) {
			uni.setNavigationBarTitle({
				title: res.name
			})
			let that = this;
			let name = commonInfo.userinfo.name
			api.GetNowtoken(name, (res) => {
				console.log(res)
				token = res
			});
			uni.request({
				url: "http://h5.shouyunchina.com:8002/DNServices/businessInfoServlet",
				method: "GET",
				data: {
					recordId: res.recordId,
					id: res.id
				},
				success: async (res) => {
					let {
						data: {
							values: values
						}
					} = res;
					if (res.data) {
						let info = res.data;
						info['场所设施财物清单'] = info['场所设施财物清单'] && this.fillet(info['场所设施财物清单']);
						info['附件场所设施财物清单'] = info['附件场所设施财物清单'] && this.fillet(info['附件场所设施财物清单']);
						console.log(info)
						this.fields = info;
					}
				},
				fail: (err) => {
					console.log(err);
					uni.showToast({
						title: "请求失败",
						icon: "none"
					})
				}
			});
		},
		methods: {
			fillet: function(res) {
				if (res == '8361367595765681198') {
					return '符合'
				} else if (res == '-2066416451667277405') {
					return '基本符合'
				} else if (res == '6571312966818286323') {
					return '不符合'
				} else if (res == '986401131406182056') {
					return '通过'
				} else if (res == '-233736429269465346') {
					return '书面整改'
				} else if (res == '-8708609701263029876') {
					return '停业整顿'
				} else if (res == '8997802166051095014') {
					return '否'
				} else if (res == '-6831193320631809582') {
					return '是'
				} else if (res == '5885808606164896166') {
					return '已向你宣读'
				} else if (res == '6573754221301875061') {
					return '请核对'
				} else if (res == '1068839251742507953') {
					return '全部证据'
				} else if (res == '6513549339120258159') {
					return '部分证据'
				} else if (res == '3117111607399304046') {
					return '场所清单'
				} else if (res == '-3564747582551603596') {
					return '财物清单'
				} else if (res == '2944129172193822406') {
					return '设施清单'
				} else if (res == '6897086536934377384') {
					return '男'
				} else if (res == '-4637397066553733657') {
					return '女'
				} else if (res == '3495632856930011401') {
					return '设施'
				} else if (res == '-9102571236001362048') {
					return '财物'
				} else if (res == '7350172593853450270') {
					return '场所'
				} else if (res == '-456001630006194760') {
					return '扣押'
				} else if (res == '1472044003399387940') {
					return '查封'
				} else if (res == '-4807422774013443093') {
					return '立案'
				} else if (res == '-8528133649199512965') {
					return '不予立案'
				}
			}
		},
	}
</script>

<style>
	@import url("../../../static/css/CommonPunish.css");
</style>
