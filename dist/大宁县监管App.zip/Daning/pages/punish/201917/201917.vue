<template>
	<view>
		<view class="content" v-if="fields">
			<form @submit="submit">
				<view class="totcontent" v-show=" showindex == 1 ">
					<view class="section">
						<view class="section__title">开始时间：</view>
						<view class="iconbox">
							<input class="section__input" @tap="toggleTab('picker','时间')" v-model="fields['时间'].value" disabled="true"
							 placeholder-class="placesize" placeholder="开始时间"></input>
							<view class="iconfont icon-riqi xiala"></view>
						</view>
					</view>
					<view class="section">
						<view class="section__title">结束时间：</view>
						<view class="iconbox">
							<input class="section__input" @tap="toggleTab('picker','时间至')" v-model="fields['时间至'].value" disabled="true"
							 placeholder-class="placesize" placeholder="结束时间"></input>
							<view class="iconfont icon-riqi xiala"></view>
						</view>
					</view>
					<view class="section">
						<view class="section__title">地点：</view>
						<input class="section__input" v-model="fields['地点'].value" placeholder-class="placesize" placeholder="地点"></input>
					</view>
					<view class="section">
						<view class="section__title">检查人员1：</view>
						<input class="section__input" v-model="fields['检查人员1'].value" placeholder-class="placesize" placeholder="检查人员1"></input>
					</view>
					<view class="section ">
						<view class="section__title">执法证号1：</view>
						<input class="section__input" v-model="fields['执法证号1'].value" placeholder-class="placesize" placeholder="执法证号1"></input>
					</view>
					<view class="section">
						<view class="section__title">检查人员2：</view>
						<input class="section__input" v-model="fields['检查人员2'].value" placeholder-class="placesize" placeholder="检查人员2"></input>
					</view>
					<view class="section sbo">
						<view class="section__title">执法证号2：</view>
						<input class="section__input" v-model="fields['执法证号2'].value" placeholder-class="placesize" placeholder="执法证号2"></input>
					</view>
					<button class="btn" @tap="next(2)">下一步</button>
				</view>
				<view class="totcontent" v-show="showindex == 2">
					<view class="section">
						<view class="section__title">当事人人员1：</view>
						<input class="section__input" v-model="fields['当事人1'].value" placeholder-class="placesize" placeholder="当事人1"></input>
					</view>
					<view class="section">
						<view class="section__title">主体资格证照名称：</view>
						<input class="section__input" v-model="fields['主体资格证照名称'].value" placeholder-class="placesize" placeholder="主体资格证照名称"></input>
					</view>
					<view class="section">
						<view class="section__title">统一社会信用代码：</view>
						<input class="section__input" v-model="fields['统一社会信用代码'].value" placeholder-class="placesize" placeholder="统一社会信用代码"></input>
					</view>
					<view class="section">
						<view class="section__title">住所：</view>
						<input class="section__input" v-model="fields['住所'].value" placeholder-class="placesize" placeholder="住所"></input>
					</view>
					<view class="section">
						<view class="section__title">法定代表人：</view>
						<input class="section__input" v-model="fields['法定代表人'].value" placeholder-class="placesize" placeholder="法定代表人"></input>
					</view>
					<view class="section">
						<view class="section__title">身份证：</view>
						<input class="section__input" v-model="fields['身份证'].value" placeholder-class="placesize" placeholder="身份证"></input>
					</view>
					<view class="section">
						<view class="section__title">联系电话：</view>
						<input class="section__input" v-model="fields['联系电话'].value" placeholder-class="placesize" placeholder="联系电话"></input>
					</view>
					<view class="section">
						<view class="section__title">其他联系方式：</view>
						<input class="section__input" v-model="fields['其他联系方式'].value" placeholder-class="placesize" placeholder="其他联系方式"></input>
					</view>
					<view class="section">
						<view class="section__title">联系地址：</view>
						<input class="section__input" v-model="fields['联系地址'].value" placeholder-class="placesize" placeholder="联系地址"></input>
					</view>
					<view class="section">
						<view class="section__title">通知当事人到场情况：</view>
						<input class="section__input" v-model="fields['通知当事人到场情况'].value" placeholder-class="placesize" placeholder="通知当事人到场情况"></input>
					</view>
					<view class="combtn">
						<button class="btn" @tap="pre(1)">上一步</button>
						<button class="btn" @tap="next(3)">下一步</button>
					</view>
				</view>
				<view class="totcontent" v-show="showindex == 3">
					<view class="totcontent">
						<view class="itemcontent">
							检查人员：我们是<input type="text" v-model="fields['什么的执法人员'].value" class="placeinput" />
							的执法人员，现向你出示
							我们的执法证件，你是否看清楚？
						</view>
					</view>
					<view class="section ">
						<view class="section__title">当事人：</view>
						<view class="iconbox">
							<picker class="pickee" @change="bindTpye($event,fields['当事人2'],'1')" :range="fields['当事人2'].options" range-key="label">
								<view class="section__input">{{fields['当事人2'].options[index] ? fields['当事人2'].options[index].label:'请选择'}}</view>
							</picker>
							<view class="iconfont icon-xiala xiala"></view>
						</view>
					</view>
					<view class="combtn">
						<button class="btn" @tap="pre(2)">上一步</button>
						<button class="btn" @tap="next(4)">下一步</button>
					</view>
				</view>
				<view class="totcontent" v-show="showindex == 4">
					<view class="totcontent">
						<view class="itemcontent">
							检查人员：你有权进行陈述和申辩。你应当如实回答询问，并协助调查或者
							检查，不得阻挠。你认为检查人员与你（单位）有直接利害关系的，依法有
							申请回避的权利。你是否申请检查人员回避？
						</view>
					</view>
					<view class="section ">
						<view class="section__title">当事人：</view>
						<view class="iconbox">
							<picker class="pickee" @change="bindTpye($event,fields['当事人3'],'2')" :range="fields['当事人3'].options" range-key="label">
								<view class="section__input">{{fields['当事人3'].options[indexq] ? fields['当事人3'].options[indexq].label:'请选择'}}</view>
							</picker>
							<view class="iconfont icon-xiala xiala"></view>
						</view>
					</view>

					<view class="combtn">
						<button class="btn" @tap="pre(3)">上一步</button>
						<button class="btn" @tap="next(5)">下一步</button>
					</view>
				</view>
				<view class="totcontent" v-show="showindex == 5">
					<view class="totcontent">
						<view class="itemcontent">
							（如实施行政强制措施，当场告知当事人采取行政强制措施的理由、依据以
							及依法享有的权利、救济途径情况：）
						</view>
					</view>
					<view class="section">
						<view class="section__title">救济途径情况：</view>
						<textarea class="section__text" v-model="fields['救济途径情况'].value" placeholder="救济途径情况" placeholder-class="placesize" />
						</view>
					<view class="section">
						<view class="section__title">当事人的陈述和申辩：</view>
						<textarea class="section__text" v-model="fields['当事人的陈述和申辩'].value"  placeholder="当事人的陈述和申辩" placeholder-class="placesize" />
					</view>
					<view class="combtn">
						<button class="btn" @tap="pre(4)">上一步</button>
						<button class="btn" @tap="next(6)">下一步</button>
					</view>
				</view>
				<view class="totcontent" v-show="showindex == 6">
					<view class="section">
						<view class="section__title">现场情况：</view>
						<textarea class="section__text" v-model="fields['现场情况'].value" placeholder="现场情况" placeholder-class="placesize" />
					</view>
					<view class="totcontent">
						<view class="itemcontent">
							检查人员：以上是本次现场检查的情况记录，请核对或已向你宣读
						</view>
					</view>
					<view class="section ">
						<view class="section__titl">当事人：</view>
						<view class="iconbox">
							<picker class="pickee" @change="bindTpye($event,fields['请核对或已向你宣读'],'3')" :range="fields['请核对或已向你宣读'].options"
							 range-key="label">
								<view class="section__input">{{fields['请核对或已向你宣读'].options[indexw] ? fields['请核对或已向你宣读'].options[indexw].label:'请选择'}}</view>
							</picker>
							<view class="iconfont icon-xiala xiala"></view>
						</view>
					</view>
					<view class="combtn">
						<button class="btn" @tap="pre(5)">上一步</button>
						<button class="btn" @tap="next(7)">下一步</button>
					</view>
				</view>
				<view class="totcontent" v-show="showindex == 7">
					<view class="section">
						<view class="section__title">当事人签名：</view>
						<view class="section_canvas" @tap="gocanvas('当事人签名或盖章')">
							<view v-if="!signImage['当事人签名或盖章']"  class="iconfont icon-iconzhengli_shouxieqianpi xiala"></view>
							<image :src="signImage['当事人签名或盖章']" class="qianfa" mode="aspectFit"></image>
						</view>
					</view>
					
					<view class="section">
						<view class="section__title">签名日期：</view>
						<view class="iconbox">
							<input class="section__input" @tap="toggleTab('picker','当事人时间')" v-model="fields['当事人时间'].value" disabled="true"
							 placeholder-class="placesize" placeholder="当事人时间"></input>
							<view class="iconfont icon-riqi xiala"></view>
						</view>
					</view>
					<view class="combtn">
						<button class="btn" @tap="pre(6)">上一步</button>
						<button class="btn" @tap="next(8)">下一步</button>
					</view>
				</view>
				<view class="totcontent" v-show="showindex == 8">
					<view class="section">
						<view class="section__title">见证人签名：</view>
						<view class="section_canvas" @tap="gocanvas('见证人签名或盖章')">
							<view v-if="!signImage['见证人签名或盖章']"  class="iconfont icon-iconzhengli_shouxieqianpi xiala"></view>
							<image :src="signImage['见证人签名或盖章']" class="qianfa" mode="aspectFit"></image>
						</view>
					</view>
					
					<view class="section">
						<view class="section__title">签名日期：</view>
						<view class="iconbox">
							<input class="section__input" @tap="toggleTab('picker','见证人时间')" v-model="fields['见证人时间'].value" disabled="true"
							 placeholder-class="placesize" placeholder="签名日期"></input>
							<view class="iconfont icon-riqi xiala"></view>
						</view>
					</view>
					<view class="combtn">
						<button class="btn" @tap="pre(7)">上一步</button>
						<button class="btn" @tap="next(9)">下一步</button>
					</view>
				</view>
				<view class="totcontent" v-show="showindex == 9">
					<view class="section">
						<view class="section__title">检查人员签名：</view>
						<view class="section_canvas" @tap="gocanvas('检查人员签名或盖章')">
							<view v-if="!signImage['检查人员签名或盖章']"  class="iconfont icon-iconzhengli_shouxieqianpi xiala"></view>
							<image :src="signImage['检查人员签名或盖章']" class="qianfa" mode="aspectFit"></image>
						</view>
					</view>
					<view class="section">
						<view class="section__title">签名日期：</view>
						<view class="iconbox">
							<input class="section__input" @tap="toggleTab('picker','检查人员时间')" v-model="fields['检查人员时间'].value" disabled="true"
							 placeholder-class="placesize" placeholder="签名日期"></input>
							<view class="iconfont icon-riqi xiala"></view>
						</view>
					</view>
					<view class="combtn">
						<button class="btn" @tap="pre(8)">上一步</button>
						<button class="btn" form-type="submit" >提交</button>
					</view>
				</view>
			</form>
			<w-picker mode="dateTime" hasSecond="true" :current="false" @confirm="onConfirme" :disabledAfter="false" ref="picker"></w-picker>
		</view>
	</view>
</template>

<script>
	import api from "@/api/api.js"
	import commonInfo from "@/common/common.js"
	var token;
	export default {
		data() {
			return {
				showindex: 1,
				dataL: "",
				currentIndex: "",
				fields: null,
				index:-1,
				indexq: -1,
				indexw: -1,
				signImage: {
					"当事人签名或盖章": "",
					"见证人签名或盖章": "",
					"检查人员签名或盖章": "",
				},
				backbtn: true,
				key: null
			}
		},
		onLoad: function(res) {
			//设置标题
			uni.setNavigationBarTitle({
				title: res.title
			})
			this.title = res.title;
			let key = commonInfo.userinfo.qycase.ID + '' + res.title;
			this.key = key;
			let name = commonInfo.userinfo.name;
			//获取模板
			api.GetNowtoken(name, (Tokendata) => {
				token = Tokendata
				if (res) {
					api.getFormdata(key, res.id, name, (res, fields) => {
						console.log(fields)
						api.initFields(fields, commonInfo.userinfo.qycase, '201917');
						res.token = Tokendata;
						this.dataL = res;
						console.log(fields)
						this.fields = fields;
					})
				}
			});
			var that = this;
			uni.$on('update', function(data) {
				let arrobj = that.signImage;
				let name = data.name;
				let imgurl = data[data.name];
				let token = commonInfo.userinfo.token;
				let obj = that.dataL;
				api.Getsign(obj, name, imgurl, token, function(res) {
					that.dataL = res;
				})
				for (let i in arrobj) {
					if (arrobj[data.name] == "") {
						arrobj[data.name] = data[data.name]
					}
				}
			})
		},
		onBackPress: function() {
			var that = this;
			if (this.backbtn) {
				uni.showModal({
					title: '提示',
					content: '确定保存本次编辑？',
					success: function(res) {
						if (res.confirm) {
							let key = commonInfo.userinfo.qycase.ID + '' + that.title;
							console.log(that.dataL.data.values)
							uni.setStorageSync(key, that.dataL)
							that.backbtn = false;
							uni.navigateBack()
						} else if (res.cancel) {
							console.log('用户点击取消');
							that.backbtn = true;
						}
					}
				});
				return true
			} else {
				return false
			}
		},
		methods: {
			toggleTab(str, index) {
				this.currentIndex = index;
				this.$refs[str].show();
			},
			onConfirme(val) {
				this.fields[this.currentIndex].value = val.result
			},
			gocanvas: function(name) {
				uni.navigateTo({
					url: "../xzzcan/xzzcan?name=" + name + ""
				})
			},
			next:function(res){
				this.showindex = res;
			},
			pre:function(res){
				this.showindex = res;
			},
			bindTpye: function(e, field, intype) {
				let name = field.name;
				let index = e.target.value
				let value = this.fields[name].options[index].value;
				field.value = value;
				if (intype == 1) {
					this.index = index;
				} else if (intype == 2) {
					this.indexq = index
				} else if (intype == 3) {
					this.indexw = index
				} else if (intype == 4) {
					this.indexe = index
				}else if (intype == 5) {
					this.indexr = index
				}else if (intype == 6) {
					this.indext = index
				}
			},
			submit: function(e) {
				/* 将案件来源登记表的信息缓存，以便于关联使用 */
				api.postFormdata(this.dataL, (res) => {
					console.log(JSON.stringify(this.dataL))
					if (res && res.code == '0') {
						uni.hideLoading();
						uni.showToast({
							title: "提交成功",
							icon: "success"
						})
						uni.removeStorage({
							key: this.key,
							success: function(res) {
								setTimeout(function() {
									uni.navigateTo({
										url: "../punsucess/punsucess"
									})
								}, 300)
							}
						});

					} else {
						uni.hideLoading();
						uni.showToast({
							title: "提交失败",
							icon: "none"
						})
					}
				}, (err) => {
					console.log(err)
					uni.showToast({
						title: "错误",
						icon: "none"
					})
				});
			}
		},
	}
</script>

<style>
	@import url("../../../static/css/CommonPunish.css");
</style>
