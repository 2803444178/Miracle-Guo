<template>
	<view>
		<view class="content" v-if="fields">
			<form @submit="submit">
				<view class="totcontent" v-show=" showindex == 1 ">
					<view class="section">
						<view class="section__title">开始时间：</view>
						<view class="iconbox">
							<input class="section__input" :value="fields['时间'] ? fields['时间']:'' " disabled="true"></input>
						</view>
					</view>
					<view class="section">
						<view class="section__title">结束时间：</view>
						<view class="iconbox">
							<input class="section__input" :value="fields['时间至']? fields['时间至']:''" disabled="true" placeholder="结束时间"></input>
						</view>
					</view>
					<view class="section">
						<view class="section__title">地点：</view>
						<input class="section__input" :value="fields['地点']? fields['地点']:''" placeholder="地点"></input>
					</view>
					<view class="section">
						<view class="section__title">检查人员1：</view>
						<input class="section__input" :value="fields['检查人员1']? fields['检查人员1']:''" placeholder="检查人员1"></input>
					</view>
					<view class="section ">
						<view class="section__title">执法证号1：</view>
						<input class="section__input" :value="fields['执法证号1']? fields['执法证号1']:''" placeholder="执法证号1"></input>
					</view>
					<view class="section">
						<view class="section__title">检查人员2：</view>
						<input class="section__input" :value="fields['检查人员2']? fields['检查人员2']:''" placeholder="检查人员2"></input>
					</view>
					<view class="section sbo">
						<view class="section__title">执法证号2：</view>
						<input class="section__input" :value="fields['执法证号2']? fields['执法证号2']:''" placeholder="执法证号2"></input>
					</view>
					<button class="btn" @tap="next(2)">下一步</button>
				</view>
				<view class="totcontent" v-show="showindex == 2">
					<view class="section">
						<view class="section__title">当事人人员1：</view>
						<input class="section__input" :value="fields['当事人1']? fields['当事人1']:''" placeholder="当事人1"></input>
					</view>
					<view class="section">
						<view class="section__title">主体资格证照名称：</view>
						<input class="section__input" :value="fields['主体资格证照名称']? fields['主体资格证照名称']:''" placeholder="主体资格证照名称"></input>
					</view>
					<view class="section">
						<view class="section__title">统一社会信用代码：</view>
						<input class="section__input" :value="fields['统一社会信用代码']? fields['统一社会信用代码']:''" placeholder="统一社会信用代码"></input>
					</view>
					<view class="section">
						<view class="section__title">住所：</view>
						<input class="section__input" :value="fields['住所']? fields['住所']:''" placeholder="住所"></input>
					</view>
					<view class="section">
						<view class="section__title">法定代表人：</view>
						<input class="section__input" :value="fields['法定代表人']? fields['法定代表人']:''" placeholder="法定代表人"></input>
					</view>
					<view class="section">
						<view class="section__title">身份证：</view>
						<input class="section__input" :value="fields['身份证']? fields['身份证']:''" placeholder="身份证"></input>
					</view>
					<view class="section">
						<view class="section__title">联系电话：</view>
						<input class="section__input" :value="fields['联系电话']? fields['联系电话']:''" placeholder="联系电话"></input>
					</view>
					<view class="section">
						<view class="section__title">其他联系方式：</view>
						<input class="section__input" :value="fields['其他联系方式']? fields['其他联系方式']:''" placeholder="其他联系方式"></input>
					</view>
					<view class="section">
						<view class="section__title">联系地址：</view>
						<input class="section__input" :value="fields['联系地址']? fields['联系地址']:''" placeholder="联系地址"></input>
					</view>
					<view class="section">
						<view class="section__title">通知当事人到场情况：</view>
						<input class="section__input" :value="fields['通知当事人到场情况']? fields['通知当事人到场情况']:''" placeholder="通知当事人到场情况"></input>
					</view>
					<view class="combtn">
						<button class="btn" @tap="pre(1)">上一步</button>
						<button class="btn" @tap="next(3)">下一步</button>
					</view>
				</view>
				<view class="totcontent" v-show="showindex == 3">
					<view class="totcontent">
						<view class="itemcontent">
							检查人员：我们是<input type="text" :value="fields['什么的执法人员']? fields['什么的执法人员']:''" class="placeinput" />
							的执法人员，现向你出示
							我们的执法证件，你是否看清楚？
						</view>
					</view>
					<view class="section" v-if="fields['当事人2']">
						<view class="section__titl">当事人：</view>
						<input class="section__input" :value="fields['当事人2']  ">
					</view>
					<view class="combtn">
						<button class="btn" @tap="pre(2)">上一步</button>
						<button class="btn" @tap="next(4)">下一步</button>
					</view>
				</view>
				<view class="totcontent" v-show="showindex == 4">
					<view class="totcontent">
						<view class="itemcontent">
							检查人员：你有权进行陈述和申辩。你应当如实回答询问，并协助调查或者
							检查，不得阻挠。你认为检查人员与你（单位）有直接利害关系的，依法有
							申请回避的权利。你是否申请检查人员回避？
						</view>
					</view>
					<view class="section" v-if="fields['当事人3']">
						<view class="section__titl">当事人：</view>
						<input class="section__input" :value="fields['当事人3']  ">
					</view>
					<view class="combtn">
						<button class="btn" @tap="pre(3)">上一步</button>
						<button class="btn" @tap="next(5)">下一步</button>
					</view>
				</view>
				<view class="totcontent" v-show="showindex == 5">
					<view class="totcontent">
						<view class="itemcontent">
							（如实施行政强制措施，当场告知当事人采取行政强制措施的理由、依据以
							及依法享有的权利、救济途径情况：）
						</view>
					</view>
					<view class="section">
						<view class="section__title">救济途径情况：</view>
						<textarea class="section__text" :value="fields['救济途径情况']? fields['救济途径情况']:''" placeholder="救济途径情况" />
						</view>
					<view class="section">
						<view class="section__title">当事人的陈述和申辩：</view>
						<textarea class="section__text":value="fields['当事人的陈述和申辩']? fields['当事人的陈述和申辩']:''"  placeholder="当事人的陈述和申辩" />
					</view>
					<view class="combtn">
						<button class="btn" @tap="pre(4)">上一步</button>
						<button class="btn" @tap="next(6)">下一步</button>
					</view>
				</view>
				<view class="totcontent" v-show="showindex == 6">
					<view class="section">
						<view class="section__title">现场情况：</view>
						<textarea class="section__text" :value="fields['现场情况']? fields['现场情况']:''" placeholder="现场情况" />
					</view>
					<view class="totcontent">
						<view class="itemcontent">
							检查人员：以上是本次现场检查的情况记录，请核对或已向你宣读
						</view>
					</view>
					<view class="section" v-if="fields['请核对或已向你宣读']">
						<view class="section__titl">当事人：</view>
						<input class="section__input" :value="fields['请核对或已向你宣读'] " placeholder="联系地址">
					</view>
					<view class="combtn">
						<button class="btn" @tap="pre(5)">上一步</button>
						<button class="btn" @tap="next(7)">下一步</button>
					</view>
				</view>
				<view class="totcontent" v-show="showindex == 7">
					<view class="section">
						<view class="section__title">当事人签名：</view>
						<view class="section_canvas" @tap="gocanvas('当事人签名或盖章')">
							
							<image :src="fields['当事人签名或盖章']" class="qianfa" mode="aspectFit"></image>
						</view>
					</view>
					<view class="section">
						<view class="section__title"> 签名日期：</view>
						<view class="iconbox">
							<input class="section__input" @tap="toggleTab('picker','当事人时间')" :value="fields['当事人时间']? fields['当事人时间']:''" disabled="true"
							 placeholder="当事人时间"></input>
							
						</view>
					</view>
					<view class="combtn">
						<button class="btn" @tap="pre(6)">上一步</button>
						<button class="btn" @tap="next(8)">下一步</button>
					</view>
				</view>
				<view class="totcontent" v-show="showindex == 8">
					<view class="section">
						<view class="section__title">见证人签名：</view>
						<view class="section_canvas" @tap="gocanvas('见证人签名或盖章')">
							
							<image :src="fields['见证人签名或盖章'] " class="qianfa" mode="aspectFit"></image>
						</view>
					</view>
					<view class="section">
						<view class="section__title"> 签名日期：</view>
						<view class="iconbox">
							<input class="section__input" :value="fields['见证人时间']? fields['见证人时间'].replace(/.........[0-9]*$/,''):''" disabled="true" placeholder="签名日期"></input>
						</view>
					</view>
					<view class="combtn">
						<button class="btn" @tap="pre(7)">上一步</button>
						<button class="btn" @tap="next(9)">下一步</button>
					</view>
				</view>
				<view class="totcontent" v-show="showindex == 9">
					<view class="section">
						<view class="section__title">检查人员签名：</view>
						<view class="section_canvas" >
							
							<image :src="fields['检查人员签名或盖章']" class="qianfa" mode="aspectFit"></image>
						</view>
					</view>
					<view class="section">
						<view class="section__title"> 签名日期：</view>
						<view class="iconbox">
							<input class="section__input"  :value="fields['检查人员时间']? fields['检查人员时间'].replace(/.........[0-9]*$/,''):''" disabled="true"
							 placeholder="签名日期"></input>
							
						</view>
					</view>
					<view class="combtn">
						<button class="btn" @tap="pre(8)">上一步</button>
					</view>
				</view>
			</form>
		</view>
	</view>
</template>

<script>
	import api from "@/api/api.js"
	import commonInfo from "@/common/common.js"
	var token = null;
	export default {
		data() {
			return {
				showindex: 1,
				dataL: "",
				currentIndex: "",
				fields: null,
			}
		},
		onLoad: function(res) {
			uni.setNavigationBarTitle({
				title: res.name
			})
			let that = this;
			let name = commonInfo.userinfo.name
			api.GetNowtoken(name, (res) => {
				console.log(res)
				token = res
			});
			uni.showLoading({
				title: "加载中"
			})
			uni.request({
				url: "http://h5.shouyunchina.com:8002/DNServices/businessInfoServlet",
				method: "GET",
				data: {
					recordId: res.recordId,
					id: res.id
				},
				success: async (res) => {
					if (res && res.data) {
						let {
							data: {
								values: values
							}
						} = res;
						let info = res.data;
						info['请核对或已向你宣读'] = info['请核对或已向你宣读'] && this.fillet(info['请核对或已向你宣读']);
						info['当事人2'] = info['当事人2'] && this.fillet(info['当事人2']);
						info['当事人3'] = info['当事人3'] && this.fillet(info['当事人3']);
						info['当事人签名或盖章'] = info['当事人签名或盖章'] &&  await this.getimg(info['当事人签名或盖章']);
						info['见证人签名或盖章'] = info['见证人签名或盖章'] && await  this.getimg(info['见证人签名或盖章']);
						info['检查人员签名或盖章'] = info['检查人员签名或盖章'] &&  await this.getimg(info['检查人员签名或盖章']);
						console.log(info)
						this.fields = info;
						uni.hideLoading()
					}
					
				},
				fail: (err) => {
					console.log(err);
					uni.showToast({
						title:"请求失败",
						icon:"none"
					})
				}
			});
		},
		methods: {
			next: function(res) {
				this.showindex = res;
			},
			pre: function(res) {
				this.showindex = res;
			},
			fillet: function(res) {
				if (res == '8361367595765681198') {
					return '符合'
				} else if (res == '-2066416451667277405') {
					return '基本符合'
				} else if (res == '6571312966818286323') {
					return '不符合'
				} else if (res == '986401131406182056') {
					return '通过'
				} else if (res == '-233736429269465346') {
					return '书面整改'
				} else if (res == '-8708609701263029876') {
					return '停业整顿'
				} else if (res == '8997802166051095014') {
					return '否'
				} else if (res == '-6831193320631809582') {
					return '是'
				} else if (res == '5885808606164896166') {
					return '已向你宣读'
				} else if (res == '6573754221301875061') {
					return '请核对'
				} else if (res == '1068839251742507953') {
					return '全部证据'
				} else if (res == '6513549339120258159') {
					return '部分证据'
				} else if (res == '3117111607399304046') {
					return '场所清单'
				} else if (res == '-3564747582551603596') {
					return '财物清单'
				} else if (res == '2944129172193822406') {
					return '设施清单'
				} else if (res == '6897086536934377384') {
					return '男'
				} else if (res == '-4637397066553733657') {
					return '女'
				}
				else if (res == '3495632856930011401') {
					return '设施'
				}
				else if (res == '-9102571236001362048') {
					return '财物'
				}
				else if (res == '7350172593853450270') {
					return '场所'
				}
				else if (res == '-456001630006194760') {
					return '扣押'
				}
				else if (res == '1472044003399387940') {
					return '查封'
				}
			},
			getimg: function(id) {
				console.log(id)
				return new Promise((resolve, reject) => {
					let name = commonInfo.userinfo.name
					api.GetNowtoken(name, (res) => {
						console.log(name)
						console.log(res)
						let url = "http://183.203.90.25:8888/seeyon/services/downloadService?token=" + res +
							"&fileId=" + id + "";
						resolve(url)
					});
				})
			
			},
		}
	}
</script>

<style>
	@import url("../../../static/css/CommonPunish.css");
</style>
