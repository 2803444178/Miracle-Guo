<template>
	<view>
		<view class="content">
			<form @submit="submit">
				<view class="totcontent" v-if="fields">
					<view class="section">
						<view class="section__title">编号：</view>
						<input class="section__input" :value="fields['编号'] ? fields['编号']  : '' " disabled></input>
					</view>
					<view class="section">
						<view class="section__title">当事人：</view>
						<input class="section__input" :value="fields['当事人'] ? fields['当事人']  : '' " disabled></input>
					</view>
					<view class="section">
						<view class="section__title">主体资格证照名称：</view>
						<input class="section__input" :value="fields['主题资格证照名称'] ? fields['主题资格证照名称']  : '' " disabled></input>
					</view>
					<view class="section">
						<view class="section__title">统一社会信用代码（注号）：</view>
						<input class="section__input" :value="fields['统一社会信用代码'] ? fields['统一社会信用代码']  : '' " disabled></input>
					</view>
					<view class="section">
						<view class="section__title">住所（住址）：</view>
						<input class="section__input" :value="fields['住所'] ? fields['住所']  : '' " disabled></input>
					</view>
					<view class="section">
						<view class="section__title">法定代表人（负责人、经营者）：</view>
						<input class="section__input" :value="fields['法定代表人'] ? fields['法定代表人']  : '' " disabled></input>
					</view>
					<view class="section">
						<view class="section__title">身份证（其他有效证件）号码：</view>
						<input class="section__input" :value="fields['身份证号码'] ? fields['身份证号码']  : '' " disabled></input>
					</view>
					<view class="section">
						<view class="section__title">联系电话：</view>
						<input class="section__input" :value="fields['联系电话'] ? fields['联系电话']  : '' " disabled></input>
					</view>
					<view class="section">
						<view class="section__title">其他联系地址：</view>
						<input class="section__input" :value="fields['其他联系地址'] ? fields['其他联系地址']  : '' " disabled></input>
					</view>
					<view class="section ">
						<view class="section__title">办案人员1：</view>
						<input class="section__input" :value="fields['执法人员1'] ? fields['执法人员1']  : '' " disabled></input>
					</view>
					<view class="section">
						<view class="section__title">执法证号1：</view>
						<input class="section__input" :value="fields['执法证号1'] ? fields['执法证号1']  : '' " disabled></input>
					</view>
					<view class="section ">
						<view class="section__title">办案人员2：</view>
						<input class="section__input" :value="fields['执法人员2'] ? fields['执法人员2']  : '' " disabled></input>
					</view>
					<view class="section">
						<view class="section__title">执法证号2：</view>
						<input class="section__input" :value="fields['执法证号2'] ? fields['执法证号2']  : '' " disabled></input>
					</view>
					<view class="section">
						<view class="section__title">你（单位）</view>
						<input class="section__input" :value="fields['违法行为'] ? fields['违法行为']  : '' " disabled></input>
						<view class="section__title">的行为，违反了</view>
						<input class="section__input" :value="fields['违法的规定'] ? fields['违法的规定']  : '' " disabled></input>
						<view class="section__title">的规定。依据《中华人民共和国行政处罚法》第二十三条</view>
						<input class="section__input" :value="fields['法律法规'] ? fields['法律法规']  : '' " disabled></input>
						<view class="section__title">的规定，现责令你（单位）改正上述违法行为，并作出如下行政处罚：</view>
					</view>
					<view class="section">
						<label>
							<checkbox :checked="fields['警告'] == 1" style="transform:scale(0.7)" value="1" /><text>警告</text>
						</label>
					</view>
					<view class="section">
						<label>
							<checkbox :checked="fields['罚款'] == 1" style="transform:scale(0.7)" />
						</label>
						罚款
						<input class="section__input" :value="fields['罚款金额'] ? fields['罚款金额']  : '' " disabled></input>
						元。
					</view>
					<view class="section">
						<view class="section__title">
							罚款按下列方式缴纳
						</view>
						<label>
							<checkbox :checked="fields['当场缴纳'] == 1" style="transform:scale(0.7)" /><text>当场缴纳</text>
						</label>
					</view>
					<view class="section">
						<label>
							<checkbox :checked="fields['日内缴纳'] == 1" style="transform:scale(0.7)" />
							<text>自即日起15日内通过</text>
						</label>
					</view>
					<view class="section">
						<input class="section__input" :value="fields['缴纳罚款途径'] ? fields['缴纳罚款途径']  : '' " disabled></input>
						<view class="section__title">
							缴纳罚款。
							逾期不缴纳罚款的，依据《中华人民共和国行政处罚法》第五十
							一条的规定，本局将每日按罚款数额的百分之三加处罚款，并依法
							申请人民法院强制执行。
							你（单位）如不服本行政处罚决定，可以在收到本当场行政处罚决
							定书之日起
						</view>
						<input class="section__input" :value="fields['行政复议时间'] ? fields['行政复议时间']  : '' " disabled></input>
						<view class="section__title">
							内向
						</view>
						<input class="section__input" :value="fields['人民政府'] ? fields['人民政府']  : '' " disabled></input>
						<view class="section__title">
							人民政府或者市场监督管理局申请行政复议；也可以在
						</view>
						<input class="section__input" :value="fields['行政诉讼时间'] ? fields['行政诉讼时间']  : '' " disabled></input>
						<view class="section__title">
							内依法向
						</view>
						<input class="section__input" :value="fields['法院'] ? fields['法院']  : '' " disabled></input>
						<view class="section__title">
							法院提起行政诉讼。
						</view>
					</view>


					<view class="section">
						<view class="section__title">联系人：</view>
						<input class="section__input" :value="fields['联系人'] ? fields['联系人']  : '' " disabled></input>
					</view>
					<view class="section">
						<view class="section__title">联系方式：</view>
						<input class="section__input" :value="fields['联系方式'] ? fields['联系方式']  : '' " disabled></input>
					</view>
					<view class="section">
						<view class="section__title"> 日期：</view>
						<input class="section__input" :value="fields['日期'] ? fields['日期']  : '' " disabled></input>
					</view>
					<view class="section">
						<view class="section__title">
							本行政处罚决定作出前执行人员已向你（单位）出示执法证件，告
							知你（单位）作出本行政处罚决定的事实、理由、依据及处罚内容，
							并告知你（单位）有权进行陈述和申辩。
						</view>
					</view>
					<view class="section">

						<view class="section__title">处罚地点：</view>
						<input class="section__input" :value="fields['处罚地点'] ? fields['处罚地点']  : '' " disabled></input>
					</view>

					<view class="section">
						<view class="section__title">当事人签名：</view>
						<view class="section_canvas">
							<image :src="fields['当事人签名']" class="qianfa" mode="aspectFit"></image>
						</view>
					</view>
					<view class="section">
						<view class="section__title"> 签名日期：</view>
						<input class="section__input" :value="fields['签名日期'] ? fields['签名日期']  : '' " disabled></input>
					</view>
					<view class="section">
						<view class="section__title">执法人员签名1：</view>
						<view class="section_canvas">
							<image :src="fields['执法人员签名1']" class="qianfa" mode="aspectFit"></image>
						</view>
					</view>
					<view class="section">
						<view class="section__title"> 签名日期：</view>
						<input class="section__input" :value="fields['执法人员签名日期1'] ? fields['执法人员签名日期1']  : '' " disabled></input>
						<view class="section">
							<view class="section__title">执法人员签名2：</view>
							<view class="section_canvas">
								<image :src="fields['执法人员签名2']" class="qianfa" mode="aspectFit"></image>
							</view>
						</view>
						<view class="section">
							<view class="section__title"> 签名日期：</view>
							<input class="section__input" :value="fields['执法人员签名日期2'] ? fields['执法人员签名日期2']  : '' " disabled />
						</view>
						<view class="itemcontent">
							本文书一式(
							<input :value="fields['文书份数']?fields['文书份数']:''" disabled class="placeinpu" />
							)份,(<input :value="fields['送达份数']?fields['送达份数']:''" class="placeinpu" />
							)份送达，一份归档,其他剩余(<input :value="fields['其他份数']?fields['其他份数']:''" class="placeinpu" />
							)份
						</view>
					</view>
				</view>
			</form>
		</view>
	</view>
</template>

<script>
	import api from "@/api/api.js"
	import commonInfo from "@/common/common.js"
	var token = null;
	export default {
		data() {
			return {
				fields: null,
			}
		},
		onLoad: function(res) {
			uni.setNavigationBarTitle({
				title: res.name
			})
			let that = this;
			let name = commonInfo.userinfo.name
			api.GetNowtoken(name, (res) => {
				console.log(res)
				token = res
			});
			uni.showLoading({
				title: "加载中"
			})
			uni.request({
				url: "http://h5.shouyunchina.com:8002/DNServices/businessInfoServlet",
				method: "GET",
				data: {
					recordId: res.recordId,
					id: res.id
				},
				success: async (res) => {
					if (res && res.data) {
						let {
							data: {
								values: values
							}
						} = res;
						let info = res.data;
						info['当事人签名'] = info['当事人签名'] && await this.getimg(info['当事人签名']);
						info['执法人员签名1'] = info['执法人员签名1'] && await this.getimg(info['执法人员签名1']);
						info['执法人员签名2'] = info['执法人员签名2'] && await this.getimg(info['执法人员签名2']);
						this.fields = info;
						uni.hideLoading()
					}
				},
				fail: (err) => {
					console.log(err);
					uni.showToast({
						title: "请求失败",
						icon: "none"
					})
				}
			});
		},
		methods: {
			getimg: function(id) {
				console.log(id)
				return new Promise((resolve, reject) => {
					let name = commonInfo.userinfo.name
					api.GetNowtoken(name, (res) => {
						console.log(name)
						console.log(res)
						let url = "http://183.203.90.25:8888/seeyon/services/downloadService?token=" + res +
							"&fileId=" + id + "";
						resolve(url)
					});
				})
			},
		},

	}
</script>

<style>
	@import url("../../../static/css/CommonPunish.css");
</style>
