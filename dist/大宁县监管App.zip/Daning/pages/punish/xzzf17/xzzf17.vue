<template>
	<view>
		<view class="content">
			<form @submit="submit" v-if="fields">
				<view class="totcontent"  v-show="showindex == 1 ">
					<view class="title-p">
						<input v-model="fields['市'].value" placeholder-class="placesize" class="placeinput title" />
						市监<input v-model="fields['监'].value" placeholder-class="placesize" class="placeinput title" />(
						<input v-model="fields['市监号'].value" placeholder-class="placesize" class="placeinput title" />
						)<input v-model="fields['号'].value" placeholder-class="placesize" class="placeinput title" />号
					</view>
					<view class="section">
						<view class="section__title">当事人：</view>
						<input class="section__input" v-model="fields['当事人'].value" placeholder-class="placesize" placeholder="当事人姓名"></input>
					</view>
					<view class="section">
						<view class="section__title">主体资格证照名称：</view>
						<input class="section__input" v-model="fields['主题资格证照名称'].value" placeholder-class="placesize" placeholder="主体资格证照名称"></input>
					</view>
					<view class="section">
						<view class="section__title">统一社会信用代码（注号）：</view>
						<input class="section__input" v-model="fields['统一社会信用代码'].value" placeholder-class="placesize" placeholder="主体资格证照名称"></input>
					</view>
					<view class="section">
						<view class="section__title">住所（住址）：</view>
						<input class="section__input" v-model="fields['住所'].value" placeholder-class="placesize" placeholder="住所"></input>
					</view>
					<view class="section">
						<view class="section__title">法定代表人（负责人、经营者）：</view>
						<input class="section__input" v-model="fields['法定代表人'].value" placeholder-class="placesize" placeholder="法定代表人"></input>
					</view>
					<view class="section">
						<view class="section__title">身份证（其他有效证件）号码）：</view>
						<input class="section__input" v-model="fields['身份证号码'].value" placeholder-class="placesize" placeholder="身份证号码"></input>
					</view>
					<view class="section">
						<view class="section__title">联系电话：</view>
						<input class="section__input" v-model="fields['联系电话'].value" placeholder-class="placesize" placeholder="联系电话"></input>
					</view>
					<view class="section">
						<view class="section__title">其他联系地址：</view>
						<input class="section__input" v-model="fields['其他联系地址'].value" placeholder-class="placesize" placeholder="其他联系地址"></input>
					</view>
					<button class="btn" @tap="next(2)">下一步</button>
				</view>
				<view class="totcontent" v-show="showindex == 2">
					<view class="section">
						<view class="section__title">经查，你（单位）涉嫌</view>
						<input v-model="fields['涉嫌行为'].value" placeholder="涉嫌行为" placeholder-class="placesize" class="section__input" />
						<view class="section__title">本局依据</view>
						<view class="section">
							<textarea class="section__text" v-model="fields['依据的规定'].value" placeholder="依据的规定" placeholder-class="placesize" />
							</view>
					 	<view class="section__title">的规定，决定对有关</view>
							
						<view class="iconbox">
							<picker class="pickee" @change="bindTpye($event,fields['场所设施财物'],'1')" :range="fields['场所设施财物'].options"
							 range-key="label">
								<view class="section__input">{{fields['场所设施财物'].options[index] ? fields['场所设施财物'].options[index].label:'请选择'}}</view>
							</picker>
							<view class="iconfont icon-xiala xiala"></view>
						</view>
					 	<view class="section">
							<view class="section__title">详见</view>
							<view class="iconbox">
								<picker class="pickee" @change="bindTpye($event,fields['场所设施财物清单'],'2')" :range="fields['场所设施财物清单'].options"
								 range-key="label">
									<view class="section__input">{{fields['场所设施财物清单'].options[indexq] ? fields['场所设施财物清单'].options[indexq].label:'请选择'}}</view>
								</picker>
								<view class="iconfont icon-xiala xiala"></view>
							</view>
					 	</view>
					 	<view class="section__title">文书编号</view>
					 	<input v-model="fields['详见财物清单文书编号'].value" placeholder="详见财物清单文书编号" placeholder-class="placesize" class="section__input" />
					 	<view class="section__title">实施行政强制措施</view>
						<view class="iconbox">
							<picker class="pickee" @change="bindTpye($event,fields['行政强制场所设施财物'],'3')" :range="fields['行政强制场所设施财物'].options"
							 range-key="label">
								<view class="section__input">{{fields['行政强制场所设施财物'].options[indexw] ? fields['行政强制场所设施财物'].options[indexw].label:'请选择'}}</view>
							</picker>
							<view class="iconfont icon-xiala xiala"></view>
						</view>
						
					 	<view class="section__title">地点</view>
						<input v-model="fields['施行强制措施的地点'].value" placeholder="施行强制措施的地点" placeholder-class="placesize" class="section__input" />
					 	
						<view class="section__title">
					 		实施行政强制措施的期限
					 	</view>
						<input v-model="fields['强制措施的期限'].value" placeholder="强制措施的期限" placeholder-class="placesize" class="section__input" />
						<view class="section__title">
							日。情况复杂，需要延长强制
							措施期限的，本局将书面告知。对物品需要进行检测、检验、检疫或者
							技术鉴定的，查封、扣押的期间不包括检测、检验、检疫或者技术鉴定
							的期间，检测、检验、检疫或者技术鉴定的期间本局将书面告知。
						</view>
						<view class="combtn">
							<button class="btn" @tap="pre(1)">上一步</button>
							<button class="btn" @tap="next(3)">下一步</button>
						</view>
				</view>
				</view>
				<view class="totcontent" v-show="showindex == 3 ">
					<view class="section">
						<view class="section__title">
							物品保存条件
						</view>
						<view class="iconbox">
							<picker class="pickee" @change="bindTpye($event,fields['查封或扣押'],'4')" :range="fields['查封或扣押'].options"
							 range-key="label">
								<view class="section__input">{{fields['查封或扣押'].options[indexe] ? fields['查封或扣押'].options[indexe].label:'请选择'}}</view>
							</picker>
							<view class="iconfont icon-xiala xiala"></view>
						</view>
						<view class="section__title">实施行政强制措施</view>
						<view class="iconbox">
							<picker class="pickee" @change="bindTpye($event,fields['保存场所设施财物清单'],'5')" :range="fields['保存场所设施财物清单'].options"
							 range-key="label">
								<view class="section__input">{{fields['保存场所设施财物清单'].options[indexr] ? fields['保存场所设施财物清单'].options[indexr].label:'请选择'}}</view>
							</picker>
							<view class="iconfont icon-xiala xiala"></view>
						</view>
						
						<view class="section__title">应当妥善保管，不得使用或者损毁。</view>
						<view class="section__title">
							你（单位）可以对本延长行政强制措施期限决定进行陈述和申
							辩。如对本延长行政强制措施期限决定不服，可以在收到本决定之
						日起
						</view>
						<input v-model="fields['行政复议时间'].value" placeholder="行政复议时间" placeholder-class="placesize" class="section__input" />
							<view class="section__title">内向</view>
							<input v-model="fields['人民政府'].value" placeholder="人民政府" placeholder-class="placesize" class="section__input" />
							<view class="section__title">
								人民政府或者
							</view>
							<input v-model="fields['市场监督管理局'].value" placeholder="市场监督管理局" placeholder-class="placesize" class="section__input" />
							<view class="section__title">
								市场监督
								管理局申请行政复议；也可以在
							</view>
							<input v-model="fields['行政诉讼日期'].value" placeholder="行政诉讼日期" placeholder-class="placesize" class="section__input" />
							<view class="section__title">
								内依法向
							</view>
							<input v-model="fields['法院'].value" placeholder="法院" placeholder-class="placesize" class="section__input" />
							<view class="section__title">
								法院提起行政诉讼
							</view>
						
						<view class="combtn">
							<button class="btn" @tap="pre(2)">上一步</button>
							<button class="btn" @tap="next(4)">下一步</button>
						</view>
					</view>
				</view>
					
					
				 	
					
		
				<view class="totcontent" v-show=" showindex == 4 ">
					<view class="section">
						<view class="section__title">联系人：</view>
						<input v-model="fields['联系人'].value" placeholder="联系人" placeholder-class="placesize" class="section__input" />
					</view>
					<view class="section">
						<view class="section__title">联系方式：</view>
						<input v-model="fields['联系方式'].value" placeholder="联系方式" placeholder-class="placesize" class="section__input" />
					</view>
					<view class="section">
						<view class="section__title">附件：</view>
						
						<view class="iconbox">
							<picker class="pickee" @change="bindTpye($event,fields['附件场所设施财物清单'],'6')" :range="fields['附件场所设施财物清单'].options"
							 range-key="label">
								<view class="section__input">{{fields['附件场所设施财物清单'].options[indext] ? fields['附件场所设施财物清单'].options[indext].label:'请选择'}}</view>
							</picker>
							<view class="iconfont icon-xiala xiala"></view>
						</view>
					</view>
					<view class="section">
						<view class="section__title">附件文书编号：</view>
						<input v-model="fields['附件文书编号'].value" placeholder="附件文书编号" placeholder-class="placesize" class="section__input" />
					</view>
					<view class="section">
						<view class="section__title"> 日期：</view>
						<view class="iconbox">
							<input class="section__input" @tap="toggleTab('picker','日期')" v-model="fields['日期'].value" disabled="true"
							 placeholder-class="placesize" placeholder="日期"></input>
							<view class="iconfont icon-riqi xiala"></view>
						</view>
					</view>
					<view class="itemcontent">
						本文书一式(
						<input v-model="fields['文书份数'].value" placeholder-class="placesize" class="placeinpu" />
						)份,(<input v-model="fields['送达份数'].value" placeholder-class="placesize" class="placeinpu" />
						)份送达，一份归档,其他剩余(<input v-model="fields['其他份数'].value" placeholder-class="placesize" class="placeinpu" />
						)份
					</view>
					<view class="combtn">
						<button class="btn" @tap="pre(2)">上一步</button>
						<button class="btn" form-type="submit">提交</button>
					</view>
				</view>
			</form>
		</view>
		<w-picker mode="date" :current="false" @confirm="onConfirme" :disabledAfter="false" ref="picker"></w-picker>
	</view>
</template>

<script>
	import api from "@/api/api.js"
	import commonInfo from "@/common/common.js";
	var token;
	export default {
		data() {
			return {
				showindex: 1,
				dataL: "",
				nowdate: '',
				currentIndex: "",
				index: -1,
				indexq:-1,
				indexw:-1,
				indexe:-1,
				indexr:-1,
				fields:null,
				indext:-1,
				backbtn: true,
				key:null
			}
		},
		onBackPress: function() {
			var that = this;
			if (this.backbtn) {
				uni.showModal({
					title: '提示',
					content: '确定保存本次编辑？',
					success: function(res) {
						if (res.confirm) {
							let key = commonInfo.userinfo.qycase.ID + '' + that.title;
							console.log(that.dataL.data.values)
							uni.setStorageSync(key, that.dataL)
							that.backbtn = false;
							uni.navigateBack()
						} else if (res.cancel) {
							console.log('用户点击取消');
							that.backbtn = true;
						}
					}
				});
				return true
			} else {
				return false
			}
		},
		onLoad: function(res) {
			//设置标题
			uni.setNavigationBarTitle({
				title: res.title
			})
			this.title = res.title;
			let key = commonInfo.userinfo.qycase.ID + '' + res.title;
			this.key = key;
			let name = commonInfo.userinfo.name;
			//获取模板
			console.log(commonInfo.userinfo.qycase)
			api.GetNowtoken(name, (Tokendata) => {
				token = Tokendata
				if (res) {
					api.getFormdata(key, res.id, name, (res, fields) => {
						console.log(fields)
						api.initFields(fields, commonInfo.userinfo.qycase, 'xzzf17');
						res.token = Tokendata;
						this.dataL = res;
						this.fields = fields;
					})
				}
			});
			var that = this;
			uni.$on('update', function(data) {
				let arrobj = that.signImage;
				let name = data.name;
				let imgurl = data[data.name];
				let token = commonInfo.userinfo.token;
				let obj = that.dataL;
				api.Getsign(obj, name, imgurl, token, function(res) {
					that.dataL = res;
				})
				for (let i in arrobj) {
					if (arrobj[data.name] == "") {
						arrobj[data.name] = data[data.name]
					}
				}
			})
		},
		methods: {
			next: function(res) {
				this.showindex = res;
				console.log(res)
			},
			pre: function(res) {
				this.showindex = res;
			},
		
			bindTpye: function(e, field, intype) {
				let name = field.name;
				let index = e.target.value
				let value = this.fields[name].options[index].value;
				field.value = value;
				if (intype == 1) {
					this.index = index;
				} else if (intype == 2) {
					this.indexq = index
				} else if (intype == 3) {
					this.indexw = index
				} else if (intype == 4) {
					this.indexe = index
				}else if (intype == 5) {
					this.indexr = index
				}else if (intype == 6) {
					this.indext = index
				}
			},
			toggleTab(str, index) {
				this.currentIndex = index;
				this.$refs[str].show();
			},
			onConfirme(val) {
				this.fields[this.currentIndex].value = val.result;
			},
			submit: function(e) {
				/* 将案件来源登记表的信息缓存，以便于关联使用 */
				api.postFormdata(this.dataL, (res) => {
					console.log(res)
					if (res && res.code == '0') {
						uni.hideLoading();
						uni.showToast({
							title: "提交成功",
							icon: "success"
						})
						uni.removeStorage({
							key: this.key,
							success: function(res) {
								setTimeout(function() {
									uni.navigateTo({
										url: "../punsucess/punsucess"
									})
								}, 300)
							}
						});
					} else {
						uni.hideLoading();
						uni.showToast({
							title: "提交失败",
							icon: "none"
						})
					}
				}, (err) => {
					console.log(err)
					uni.showToast({
						title: "错误",
						icon: "none"
					})
				});
			}
		},
	}
</script>

<style>
	@import url("../../../static/css/CommonPunish.css");
</style>
