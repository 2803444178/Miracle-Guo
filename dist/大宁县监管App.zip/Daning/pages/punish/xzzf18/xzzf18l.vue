<template>
	<view>
		<view class="content">
			<view class="totcontent" v-if="fields">
				<view class="title-p">
					<input :value="fields['市'] ? fields['市'] : '' " disabled class="placeinput title" />
					市监<input :value="fields['监'] ? fields['监'] : ''" disabled class="placeinput title" />(
					<input :value="fields['市监号'] ? fields['市监号'] : ''" disabled class="placeinput title" />
					)<input :value="fields['号'] ? fields['号'] : ''" disabled class="placeinput title" />号
				</view>
				<view class="section">
					<view class="section__title">市场监管局名称</view>
					<input :value="fields['市场监管局名称'] ?  fields['市场监管局名称'] : ''" class="section__input" disabled />
					<view class="section__title">本局于</view>
					<input :value="fields['做出行政强制措施决定书的日期'] ?  fields['做出行政强制措施决定书的日期'] : ''" class="section__input" disabled />
					<view class="section__title">作出《实施行政强制措施决定书》</view>
					<view class="section" style="display: flex;justify-content: space-between;align-items: center;">
						<input :value="fields['市1'] ? fields['市1'] : '' " disabled class="placeinput title" />
						市监<input :value="fields['监1'] ? fields['监1'] : ''" disabled class="placeinput title" />(
						<input :value="fields['强制决定书市监号'] ? fields['强制决定书市监号'] : ''" disabled class="placeinput title" />
						)<input :value="fields['号1'] ? fields['号1'] : ''" disabled class="placeinput title" />号
					</view>

					<view class="section">
						<view class="section__title">对你（单位）有关</view>
						<input :value="fields['场所设施财物'] ?  fields['场所设施财物'] : ''" class="section__input" disabled />
					</view>
					<view class="section__title">详见</view>
					<view class="section">
						<view class="section__title">对你（单位）有关</view>
						<input :value="fields['场所设施财物清单'] ?  fields['场所设施财物清单'] : ''" class="section__input" disabled />

					</view>
					<view class="section__title">文书编号</view>
					<input :value="fields['财物清单文书编号'] ?  fields['财物清单文书编号'] : ''" class="section__input" disabled />
					<view class="section__title">采取</view>
					<view class="section">
						<textarea class="section__text" :value="fields['采取的行政措施'] ?  fields['采取的行政措施'] : ''" placeholder="采取的行政措施"
						 placeholder-class="placesize" />
						</view>
						<view class="section">
							<view class="section__title">
								行政强制措施。因情况复杂，依据《中华人民共和国行政强制法》
								第二十五条第一款、第二款的规定，经本局负责人批准，决定将该
								行政强制措施的期限延长至
							</view>
							<view class="section">
								<input :value="fields['期限延长的日期'] ?  fields['期限延长的日期'] : ''" class="section__input" disabled />
							</view>
						</view>
							你（单位）可以对本延长行政强制措施期限决定进行陈述和申
							辩。如对本延长行政强制措施期限决定不服，可以在收到本决定之
						日起
						</view>
						<input :value="fields['行政复议的时间'] ?  fields['行政复议的时间'] : ''" class="section__input" disabled />
						<view class="section__title">内向</view>
						<input :value="fields['人民政府'] ?  fields['人民政府'] : ''" class="section__input" disabled />
						<view class="section__title">
							人民政府或者
						</view>
						<input :value="fields['市场监督管理局'] ?  fields['市场监督管理局'] : ''" class="section__input" disabled />
						<view class="section__title">
							市场监督
							管理局申请行政复议；也可以在
						</view>
						<input :value="fields['行政诉讼的时间'] ?  fields['行政诉讼的时间'] : ''" class="section__input" disabled />
						<view class="section__title">
							内依法向
						</view>
						<input :value="fields['法院'] ?  fields['法院'] : ''" class="section__input" disabled />
						<view class="section__title">
							法院提起行政诉讼
						</view>
					<view class="section">
						<view class="section__titl">联系人：</view>
						<input :value="fields['联系人'] ?  fields['联系人'] : ''" class="section__input" disabled />
					</view>
					<view class="section">
						<view class="section__titl">联系方式：</view>
						<input :value="fields['联系方式'] ?  fields['联系方式'] : ''" class="section__input" disabled />
					</view>
					
					<view class="section">
						<view class="section__title"> 日期：</view>
						<input :value="fields['日期'] ?  fields['日期'] : ''" class="section__input" disabled />
						
					</view>
					<view class="itemcontent">
						本文书一式(
						<input :value="fields['文书份数']?fields['文书份数']:''" disabled class="placeinpu" />
						)份,(<input :value="fields['送达份数']?fields['送达份数']:''"  class="placeinpu" />
						)份送达，一份归档,其他剩余(<input :value="fields['其他份数']?fields['其他份数']:''"  class="placeinpu" />
						)份
					</view>
				</view>
			</view>
		</view>
	</view>
</template>

<script>
	import api from "@/api/api.js"
	import commonInfo from "@/common/common.js"
	var token = null;
	export default {
		data() {
			return {
				showindex: 1,
				dataL: "",
				currentIndex: "",
				fields: null,
			}
		},
		onLoad: function(res) {
			uni.setNavigationBarTitle({
				title: res.name
			})
			let that = this;
			let name = commonInfo.userinfo.name 
			console.log(name)
			api.GetNowtoken(name, (res) => {
				console.log(res)
				token = res
			});
			api.getFormscree(res.id, res.recordId, (res) => {
				if (res) {
					let info = res;
					console.log(res)
					info['场所设施财物'] = info['场所设施财物'] && this.fillet(info['场所设施财物']);
					info['场所设施财物清单'] = info['场所设施财物清单'] && this.fillet(info['场所设施财物清单']);
					info['行政强制场所设施财物'] = info['行政强制场所设施财物'] && this.fillet(info['行政强制场所设施财物']);
					info['查封或扣押'] = info['查封或扣押'] && this.fillet(info['查封或扣押']);
					info['保存场所设施财物清单'] = info['保存场所设施财物清单'] && this.fillet(info['保存场所设施财物清单']);
					info['附件场所设施财物清单'] = info['附件场所设施财物清单'] && this.fillet(info['附件场所设施财物清单']);
					this.fields = info;
				}
			})
		},
		
		methods: {
			fillet: function(res) {
				if (res == '8361367595765681198') {
					return '符合'
				} else if (res == '-2066416451667277405') {
					return '基本符合'
				} else if (res == '6571312966818286323') {
					return '不符合'
				} else if (res == '986401131406182056') {
					return '通过'
				} else if (res == '-233736429269465346') {
					return '书面整改'
				} else if (res == '-8708609701263029876') {
					return '停业整顿'
				} else if (res == '8997802166051095014') {
					return '否'
				} else if (res == '-6831193320631809582') {
					return '是'
				} else if (res == '5885808606164896166') {
					return '已向你宣读'
				} else if (res == '6573754221301875061') {
					return '请核对'
				} else if (res == '1068839251742507953') {
					return '全部证据'
				} else if (res == '6513549339120258159') {
					return '部分证据'
				} else if (res == '3117111607399304046') {
					return '场所清单'
				} else if (res == '-3564747582551603596') {
					return '财物清单'
				} else if (res == '2944129172193822406') {
					return '设施清单'
				} else if (res == '6897086536934377384') {
					return '男'
				} else if (res == '-4637397066553733657') {
					return '女'
				}
				else if (res == '3495632856930011401') {
					return '设施'
				}
				else if (res == '-9102571236001362048') {
					return '财物'
				}
				else if (res == '7350172593853450270') {
					return '场所'
				}
				else if (res == '-456001630006194760') {
					return '扣押'
				}
				else if (res == '1472044003399387940') {
					return '查封'
				}
			},
		}
	}
</script>

<style>
	@import url("../../../static/css/CommonPunish.css");
</style>
