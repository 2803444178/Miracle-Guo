<template>
	<view>
		<view class="content">
			<form @submit="submit">
				<view class="itemcontent" v-if="fields">
					<view class="title-p">
						<input :value="fields['市'] ? fields['市'] : '' " disabled class="placeinput title" />
						市监<input :value="fields['监'] ? fields['监'] : ''" disabled class="placeinput title" />(
						<input :value="fields['市监号'] ? fields['市监号'] : ''" disabled class="placeinput title" />
						)<input :value="fields['号'] ? fields['号'] : ''" disabled class="placeinput title" />号
					</view>
					<view class="section">
						<view class="section__title">单位名称</view>
						<input :value="fields['单位名称'] ?  fields['单位名称'] : ''" class="section__input" disabled />
						<view class="section__title">经查，你（单位）</view>
						<input :value="fields['违法行为'] ?  fields['违法行为'] : ''" class="section__input" disabled />
						<view class="section__title">的行为，违反了</view>
						<input :value="fields['违反的规定'] ?  fields['违反的规定'] : ''" class="section__input" disabled />
						<view class="section__title">的规定。存在致使消费者或者其他经营者多付价款的情形。依据《
							中华人民共和国价格法》第四十一条、《价格违法行为行政处罚规
							定》第十六条、《市场监督管理行政处罚程序暂行规定》第五十三
							条的规定，现责令你（单位）自收到本通知书之日起</view>
						<input :value="fields['天数'] ?  fields['天数'] : ''" class="section__input" disabled />
						<view class="section__title">日内，
							将消费者或者其他经营者多付的价款</view>
						<input :value="fields['价款'] ?  fields['价款'] : ''" class="section__input" disabled />
						<view class="section__title">元退还给消费者或
							者其他经营者。消费者或者其他经营者难以查找的，应当公告查
							找。拒不退还或者逾期未退还的部分，本局将依法予以没收。消费
							者或者其他经营者要求退还时，由你（单位）依法承担民事责任。</view>
					</view>
					<view class="section">
						<view class="section__title"> 日期：</view>
						<view class="iconbox">
							<input :value="fields['日期'] ?  fields['日期'] : ''" class="section__input" disabled />
						</view>
					</view>
					<view class="itemcontent">
						本文书一式(
						<input :value="fields['文书总份数']?fields['文书份数']:''" disabled class="placeinpu" />
						)份,(<input :value="fields['送达份数']?fields['送达份数']:''" disabled class="placeinpu" />
						)份送达，一份归档,其他剩余(<input :value="fields['其他份数']?fields['其他份数']:''" disabled class="placeinpu" />
						)份
					</view>

				</view>
			</form>
		</view>
	</view>
</template>

<script>
	import api from "@/api/api.js"
	import commonInfo from "@/common/common.js"
	var token = null;
	export default {
		data() {
			return {
				showindex: 1,
				dataL: "",
				currentIndex: "",
				fields: null,
			}
		},
		onLoad: function(res) {
			uni.setNavigationBarTitle({
				title: res.name
			})
			let that = this;
			let name = commonInfo.userinfo.name
			console.log(name)
			api.GetNowtoken(name, (res) => {
				console.log(res)
				token = res
			});
			api.getFormscree(res.id, res.recordId, (res) => {
				this.fields = res;
			})
		},
	}
</script>

<style>
	@import url("../../../static/css/CommonPunish.css");
</style>
