<template>
	<view>
		<view class="content">
			<form @submit="submit" v-if="fields">
				<view class="totcontent" v-show=" showindex == 1 ">
					<view class="section">
						<view class="section__title">案件名称：</view>
						<input class="section__input" v-model="fields['案件名称'].value" placeholder-class="placesize" placeholder="案件名称"></input>
					</view>
					<view class="section">
						<view class="section__title">告知事项：</view>
						<view class="section__text" style="height: auto;">
							<view class="common-t">
								依据《市场监督管理行政处罚程序暂行规定》第七十四条第四项、第七十五条的规定，告知如下：
							</view>
							<view class="common-t">
								一、为便于及时收到市场监督管理部门的相关文书，保证案件调查的顺利进行，市场监督管理部门可以要求受送达人签署送达地址确认书，送达至受送达人确认的地址，即视为送达。
							</view>
							<view class="common-t">
								三、因受送达人提供的送达地址不准确、送达地址变更未书面告知市场监督管理部门，导致执法文书未能被受送达人实际接收的，直接送达的，执法文书留在该地址之日为送达之日；邮寄送达的，执法文书被退回之日为送达之日。
							</view>
							<view class="common-t">
								四、经受送达人同意，可以采用手机短信、传真、电子邮件、即时通讯账号等能够确认其收悉的电子方式送达执法文书（行政处罚决定书除外），手机短信、传真、电子邮件、即时通讯信息等到达受送达人特定系统的日期为送达日期。
							</view>
						</view>
					</view>
					<button class="btn" @tap="next(2)">下一步</button>
				</view>
				<view class="totcontent" v-show=" showindex == 2 ">
					<view class="section">
						<view class="section__title">送达地址及送达方式</view>
					</view>
					<view class="section">
						<view class="section__title">是否接收电子送达：</view>
						<radio-group class="cheackbox">
							<label class="cheackboxlist" @tap="radioChange(fields['是送达'])">
								<checkbox class="radioitem" value="1" /><text>是</text>
							</label>
							<label class="cheackboxlist" @tap="radioChange(fields['否送到'])">
								<checkbox class="radioitem" value="3" /><text>否</text>
							</label>
						</radio-group>
					</view>
					<view class="section">
						<view class="section">
							<view class="section__title">
								手机号码：
								<label class="cheackboxlist">
									<checkbox class="radioitem" value="1" @tap="radioChange(fields['手机号码选择'])" />
								</label>
							</view>
						</view>
						<input class="section__input" v-model="fields['手机号码'].value" placeholder-class="placesize" 
						 placeholder="手机号码"></input>
					</view>
					<view class="section">
						<view class="section">
							<view class="section__title">
								传真号码：
								<label class="cheackboxlist">
									<checkbox class="radioitem" value="1" @tap="radioChange(fields['传真号码选择'])" />
								</label>
							</view>
						</view>
						<input class="section__input" v-model="fields['传真号码'].value" placeholder-class="placesize"
						 placeholder="传真号码"></input>
					</view>
					<view class="section">
						<view class="section">
							<view class="section__title">
								电子邮件地址：
								<label class="cheackboxlist">
									<checkbox class="radioitem" value="1" @tap="radioChange(fields['选择电子邮件地址'])" />
								</label>
							</view>
						</view>
						<input class="section__input" v-model="fields['电子邮件地址'].value" placeholder-class="placesize" placeholder="电子邮件地址"></input>
					</view>
					<view class="section">
						<view class="section">
							<view class="section__title">
								即时通讯地址：
								<label class="cheackboxlist">
									<checkbox class="radioitem" value="1" @tap="radioChange(fields['选择即时通讯地址'])" />
								</label>
							</view>
						</view>
						<input class="section__input" v-model="fields['即时通讯地址'].value" placeholder-class="placesize" name="即时通讯地址"
						 placeholder="即时通讯地址"></input>
					</view>
					<view class="combtn">
						<button class="btn" @tap="pre(1)">上一步</button>
						<button class="btn" @tap="next(3)">下一步</button>
					</view>
				</view>
				<view class="totcontent" v-show=" showindex == 3 ">
					<view class="section">
						<view class="section__title">案件名称：</view>
						<input class="section__input" v-model="fields['案件名称'].value" placeholder-class="placesize" placeholder="案件名称"></input>
					</view>
					<view class="section">
						<view class="section__titlm">送达地址：</view>
						<input class="section__input" v-model="fields['送达地址'].value" placeholder-class="placesize" placeholder="送达地址"></input>
					</view>
					<view class="section">
						<view class="section__titlm">收件人：</view>
						<input class="section__input" v-model="fields['收件人'].value" placeholder-class="placesize" placeholder="收件人"></input>
					</view>

					<view class="section">
						<view class="section__titlm">收件人联系电话：</view>
						<input class="section__input" v-model="fields['收件人联系电话'].value" placeholder-class="placesize" placeholder="收件人联系电话"></input>
					</view>

					<view class="section">
						<view class="section__titlm">邮政编码：</view>
						<input class="section__input" v-model="fields['邮政编码'].value" placeholder-class="placesize" placeholder="邮政编码"></input>
					</view>
					<view class="combtn">
						<button class="btn" @tap="pre(2)">上一步</button>
						<button class="btn" @tap="next(4)">下一步</button>
					</view>
				</view>
				<view class="totcontent" v-show="showindex == 4">
					<view class="section">
						<view class="section__title">当事人确认：</view>
						<view class="common-t">
							本人已阅读（已向本人宣读）上述告知事项，清楚了解其内容及法律意义，并保证以上送达地址及送达方式准确、有效。
						</view>
					</view>

					<view class="section">
						<view class="section__title">当事人（委托代理人）签名、盖章：</view>
						<view class="section_canvas" @tap="gocanvas('当事人签名')">
							<view v-if="!signImage['当事人签名']" class="iconfont icon-iconzhengli_shouxieqianpi xiala"></view>
							<image :src="signImage['当事人签名']" class="qianfa" mode="aspectFit"></image>
						</view>
					</view>
					<view class="section">
						<view class="section__title"> 签名日期：</view>
						<view class="iconbox">
							<input class="section__input" @tap="toggleTab('picker','日期')" v-model="fields['日期'].value" disabled="true"
							 placeholder-class="placesize" placeholder="日期"></input>
							<view class="iconfont icon-riqi xiala"></view>
						</view>
					</view>
					<view class="section">
						<view class="section__title">备注：</view>
						<textarea class="section__text" v-model="fields['备注'].value" placeholder="备注" placeholder-class="placesize" />
						</view>
					<view class="combtn">
						<button class="btn" @tap="pre(3)">上一步</button>
						<button class="btn" form-type="submit" >提交</button>
					</view>
				</view>
			</form>
		</view>
		<!-- <w-picker mode="dateTime" :current="false" @confirm="onConfirme" :disabledAfter="false" ref="picker"></w-picker> -->
	</view>
</template>

<script>
	import api from "@/api/api.js";
	import commonInfo from "@/common/common.js";
	var token ;
	export default {
		data() {
			return {
				showindex: 1,
				timeTemp: '',
				dataL: "",
				nowdate: '',
				index: 0,
				fields:null,
				indexType: 0,
				//签名信息
				signImage: {
					"当事人签名": ""
				},
				// 企业信息
				enterpriseinfo: "",
				backbtn: true,
				key: null
			}
		},
		onLoad: function(res) {
			//设置标题
			uni.setNavigationBarTitle({
				title: res.title
			})
			this.title = res.title;
			let key = commonInfo.userinfo.qycase.ID + '' + res.title;
			this.key = key;
			let name = commonInfo.userinfo.name;
			//获取模板
			console.log(commonInfo.userinfo.qycase)
			api.GetNowtoken(name, (Tokendata) => {
				token = Tokendata
				if (res) {
					api.getFormdata(key, res.id, name, (res, fields) => {
						console.log(fields)
						api.initFields(fields, commonInfo.userinfo.qycase, 'xzzf09');
						res.token = Tokendata;
						this.dataL = res;
						this.fields = fields;
					})
				}
			});
			var that = this;
			uni.$on('update', function(data) {
				let arrobj = that.signImage;
				let name = data.name;
				let imgurl = data[data.name];
				let token = commonInfo.userinfo.token;
				let obj = that.dataL;
				api.Getsign(obj, name, imgurl, token, function(res) {
					that.dataL = res;
				})
				for (let i in arrobj) {
					if (arrobj[data.name] == "") {
						arrobj[data.name] = data[data.name]
					}
				}
			})
		},
		onBackPress: function() {
			var that = this;
			if (this.backbtn) {
				uni.showModal({
					title: '提示',
					content: '确定保存本次编辑？',
					success: function(res) {
						if (res.confirm) {
							let key = commonInfo.userinfo.qycase.ID + '' + that.title;
							console.log(that.dataL.data.values)
							uni.setStorageSync(key, that.dataL)
							that.backbtn = false;
							uni.navigateBack()
						} else if (res.cancel) {
							console.log('用户点击取消');
							that.backbtn = true;
						}
					}
				});
				return true
			} else {
				return false
			}
		},
		methods: {
			radioChange(evt) {
				let str = this.totalarr;
				if (evt.value == '') {
					evt.value = 1;
				} else {
					evt.value = '';
				}
			},
			gocanvas: function(name) {
				uni.navigateTo({
					url: "../xzzcan/xzzcan?name=" + name + ""
				})
			},
		
			toggleTab(str, index) {
				this.$refs[str].show();
				this.currentIndex = index;
			},
			onConfirme(val) {
				this.fields[this.currentIndex].value = val.result;
			},
			next: function(res) {
				this.showindex = res;
			},
			pre: function(res) {
				this.showindex = res;
			},
			submit: function(e) {
				/* 将案件来源登记表的信息缓存，以便于关联使用 */
				api.postFormdata(this.dataL, (res) => {
					console.log(res)
					if (res && res.code == '0') {
						uni.hideLoading();
						uni.showToast({
							title: "提交成功",
							icon: "success"
						})
						uni.removeStorage({
							key: this.key,
							success: function(res) {
								setTimeout(function() {
									uni.navigateTo({
										url: "../punsucess/punsucess"
									})
								}, 300)
							}
						});
					} else {
						uni.hideLoading();
						uni.showToast({
							title: "提交失败",
							icon: "none"
						})
					}
				}, (err) => {
					console.log(err)
					uni.showToast({
						title: "错误",
						icon: "none"
					})
				});
			}
		}
	}
</script>

<style>
	@import url("../../../static/css/CommonPunish.css");
</style>
