<template>
	<view>
		<view class="content" v-if="fields">
			<form @submit="submit">
				<view class="totcontent">
					<view class="section">
						<view class="section__title">案件名称：</view>
						<input class="section__input" :value="fields['案件名称'] ? fields['案件名称'] : '' " disabled></input>
					</view>
					<view class="section">
						<view class="section__title">告知事项：</view>
						<view class="section__text" style="height: auto;">
							<view class="common-t">
								依据《市场监督管理行政处罚程序暂行规定》第七十四条第四项、第七十五条的规定，告知如下：
							</view>
							<view class="common-t">
								一、为便于及时收到市场监督管理部门的相关文书，保证案件调查的顺利进行，市场监督管理部门可以要求受送达人签署送达地址确认书，送达至受送达人确认的地址，即视为送达。
							</view>
							<view class="common-t">
								三、因受送达人提供的送达地址不准确、送达地址变更未书面告知市场监督管理部门，导致执法文书未能被受送达人实际接收的，直接送达的，执法文书留在该地址之日为送达之日；邮寄送达的，执法文书被退回之日为送达之日。
							</view>
							<view class="common-t">
								四、经受送达人同意，可以采用手机短信、传真、电子邮件、即时通讯账号等能够确认其收悉的电子方式送达执法文书（行政处罚决定书除外），手机短信、传真、电子邮件、即时通讯信息等到达受送达人特定系统的日期为送达日期。
							</view>
						</view>
					</view>
					<view class="section">
						<view class="section__title">送达地址及送达方式</view>
					</view>
					<view class="section">
						<view class="section__title">是否接收电子送达：</view>
						<radio-group class="cheackbox">
							<label class="cheackboxlist">
								<checkbox class="radioitem" :checked="fields['是送达'] == 1" /><text>是</text>
							</label>
							<label class="cheackboxlist">
								<checkbox class="radioitem" :checked="fields['否送到'] == 1" /><text>否</text>
							</label>
						</radio-group>
					</view>
					<view class="section">
						<view class="section">
							<view class="section__title">
								手机号码：
								<label class="cheackboxlist">
									<checkbox class="radioitem" :checked="fields['手机号码选择'] == 1" />
								</label>
							</view>
						</view>
						<input class="section__input" :value="fields['手机号码'] ? fields['案件名称'] : ''" disabled></input>
					</view>
					<view class="section">
						<view class="section">
							<view class="section__title">
								传真号码：
								<label class="cheackboxlist">
									<checkbox class="radioitem" :checked="fields['传真号码选择'] == 1" />
								</label>
							</view>
						</view>
						<input class="section__input" :value="fields['传真号码'] ? fields['案件名称'] : ''" disabled></input>
					</view>
					<view class="section">
						<view class="section">
							<view class="section__title">
								电子邮件地址：
								<label class="cheackboxlist">
									<checkbox class="radioitem" :checked="fields['选择电子邮件地址'] == 1" />
								</label>
							</view>
						</view>
						<input class="section__input" :value="fields['电子邮件地址'] ? fields['案件名称'] : ''" disabled></input>
					</view>
					<view class="section">
						<view class="section">
							<view class="section__title">
								即时通讯地址：
								<label class="cheackboxlist">
									<checkbox class="radioitem" :checked="fields['选择即时通讯地址'] == 1" />
								</label>
							</view>
						</view>
						<input class="section__input" :value="fields['即时通讯地址'] ? fields['即时通讯地址'] : ''" disabled></input>
					</view>
					<view class="section">
						<view class="section__title">案件名称：</view>
						<input class="section__input" :value="fields['案件名称'] ? fields['案件名称'] : ''" disabled></input>
					</view>
					<view class="section">
						<view class="section__titlm">送达地址：</view>
						<input class="section__input" :value="fields['送达地址'] ? fields['送达地址'] : ''" disabled></input>
					</view>
					<view class="section">
						<view class="section__titlm">收件人：</view>
						<input class="section__input" :value="fields['收件人'] ? fields['收件人'] : ''" disabled></input>
					</view>

					<view class="section">
						<view class="section__titlm">收件人联系电话：</view>
						<input class="section__input" :value="fields['收件人联系电话'] ? fields['收件人联系电话'] : ''" disabled></input>
					</view>

					<view class="section">
						<view class="section__titlm">邮政编码：</view>
						<input class="section__input" :value="fields['邮政编码'] ? fields['邮政编码'] : ''" disabled></input>
					</view>
					<view class="section">
						<view class="section__title">当事人确认：</view>
						<view class="common-t">
							本人已阅读（已向本人宣读）上述告知事项，清楚了解其内容及法律意义，并保证以上送达地址及送达方式准确、有效。
						</view>
					</view>
					<view class="section">
						<view class="section__title">当事人（委托代理人）签名、盖章：：</view>
						<view class="section_canvas">
							<image :src="fields['当事人签名']" class="qianfa" mode="aspectFit"></image>
						</view>
					</view>
					<view class="section">
						<view class="section__title"> 签名日期：</view>
						<view class="iconbox">
							<input class="section__input" :value="fields['日期'] ? fields['日期'] : ''" disabled="true"></input>
						</view>
					</view>
					<view class="section">
						<view class="section__title">备注：</view>
						<textarea class="section__text" :value="fields['备注'] ? fields['备注'] : ''" disabled />
						</view>
				</view>
			</form>
		</view>
	</view>
</template>

<script>
	import api from "@/api/api.js"
	import commonInfo from "@/common/common.js"
	var token = null;
	export default {
		data() {
			return {
				showindex: 1,
				dataL: "",
				currentIndex: "",
				fields: null,
			}
		},
		onLoad: function(res) {
			uni.setNavigationBarTitle({
				title: res.name
			})
			let that = this;
			let name = commonInfo.userinfo.name
			api.GetNowtoken(name, (res) => {
				console.log(res)
				token = res
			});
			uni.showLoading({
				title : "加载中"
			})
			uni.request({
				url: "http://h5.shouyunchina.com:8002/DNServices/businessInfoServlet",
				method: "GET",
				data: {
					recordId: res.recordId,
					id: res.id
				},
				success: async (res) => {
					uni.hideLoading()
					if( res ){
						let {
							data: {
								values: values
							}
						} = res;
						if (res.data) {
							let info = res.data;
							info['当事人签名'] = info['当事人签名'] &&  await this.getimg(info['当事人签名']);
							console.log(info)
							this.fields = info;
						}
					}
				},
				fail: (err) => {
					console.log(err);
					uni.showToast({
						title:"请求失败",
						icon:"none"
					})
				}
			});
		},
		methods: {
			fillet: function(res) {
				if (res == '8361367595765681198') {
					return '符合'
				} else if (res == '-2066416451667277405') {
					return '基本符合'
				} else if (res == '6571312966818286323') {
					return '不符合'
				} else if (res == '986401131406182056') {
					return '通过'
				} else if (res == '-233736429269465346') {
					return '书面整改'
				} else if (res == '-8708609701263029876') {
					return '停业整顿'
				} else if (res == '8997802166051095014') {
					return '否'
				} else if (res == '-6831193320631809582') {
					return '是'
				} else if (res == '5885808606164896166') {
					return '已向你宣读'
				} else if (res == '6573754221301875061') {
					return '请核对'
				} else if (res == '1068839251742507953') {
					return '全部证据'
				} else if (res == '6513549339120258159') {
					return '部分证据'
				} else if (res == '3117111607399304046') {
					return '场所清单'
				} else if (res == '-3564747582551603596') {
					return '财物清单'
				} else if (res == '2944129172193822406') {
					return '设施清单'
				} else if (res == '6897086536934377384') {
					return '男'
				} else if (res == '-4637397066553733657') {
					return '女'
				}
				else if (res == '3495632856930011401') {
					return '设施'
				}
				else if (res == '-9102571236001362048') {
					return '财物'
				}
				else if (res == '7350172593853450270') {
					return '场所'
				}
				else if (res == '-456001630006194760') {
					return '扣押'
				}
				else if (res == '1472044003399387940') {
					return '查封'
				}
				else if (res == '-4807422774013443093') {
					return '立案'
				}
				else if (res == '-8528133649199512965') {
					return '不予立案'
				}
			},
			getimg: function(id) {
				console.log(id)
				return new Promise((resolve, reject) => {
					let name = commonInfo.userinfo.name
					api.GetNowtoken(name, (res) => {
						console.log(name)
						console.log(res)
						let url = "http://183.203.90.25:8888/seeyon/services/downloadService?token=" + res +
							"&fileId=" + id + "";
						resolve(url)
					});
				})
			},
		},
		filters: {
			fillet: function(res) {
				if (res == '8361367595765681198') {
					return '符合'
				} else if (res == '-2066416451667277405') {
					return '基本符合'
				} else if (res == '6571312966818286323') {
					return '不符合'
				} else if (res == '986401131406182056') {
					return '通过'
				} else if (res == '-233736429269465346') {
					return '书面整改'
				} else if (res == '-8708609701263029876') {
					return '停业整顿'
				} else if (res == '8997802166051095014') {
					return '否'
				} else if (res == '-6831193320631809582') {
					return '是'
				} else if (res == '5885808606164896166') {
					return '已向你宣读'
				} else if (res == '6573754221301875061') {
					return '请核对'
				} else if (res == '1068839251742507953') {
					return '全部证据'
				} else if (res == '6513549339120258159') {
					return '部分证据'
				} else if (res == '3117111607399304046') {
					return '场所清单'
				} else if (res == '-3564747582551603596') {
					return '财物清单'
				} else if (res == '2944129172193822406') {
					return '设施清单'
				}
			},
			fillurl: function(fileid) {
				var that = this;
				let url = "http://183.203.90.25:8888/seeyon/services/downloadService?token=" + token +
					"&fileId=" + fileid + "";
				return url
			}
		}
	}
</script>

<style>
	@import url("../../../static/css/CommonPunish.css");
</style>
