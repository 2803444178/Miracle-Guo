<template>
	<view>
		<view class="fheader">
			<view class="fhead">
				<view class="ftitle xiao" v-if="info.qylx == '食品销售'">销</view>
				<view class="ftitle can" v-else-if="info.qylx == '餐饮服务'">餐</view>
				<view class="ftitle sheng" v-else>生</view>
				<view class="fcontent">
					{{info.qyname}}
				</view>
			</view>
		</view>
		<view class="fcont">
			<view class="Basics">
				<view class="common_title">
					<view class="iconfont icon-shuxian"></view>
					<view>
						行政执法表
					</view>
				</view>
				<view class="content">
					<view class="item" @tap="details" data-id='201917' data-title="现场笔录">
						<view class="title">
							现场笔录
							<view class="iconfont icon-you" style="font-size: 24px;"></view>
						</view>
					</view>
					<view class="item" @tap="details" data-id='201919' data-title="立案/不予立案审批表">
						<view class="title">
							立案/不予立案审批表
							<view class="iconfont icon-you" style="font-size: 24px;"></view>
						</view>
					</view>
					<view class="item" @tap="details" data-id='xzzf09' data-title="当事人送达地址确认书">
						<view class="title">
							当事人送达地址确认书
							<view class="iconfont icon-you" style="font-size: 24px;"></view>
						</view>
					</view>
					<view class="item" @tap="details" data-id='xzzf10' data-title="询问通知书">
						<view class="title">
							询问通知书
							<view class="iconfont icon-you" style="font-size: 24px;"></view>
						</view>
					</view>
					<view class="item" @tap="details" data-id='xzzf11' data-title="询问笔录">
						<view class="title">
							询问笔录
							<view class="iconfont icon-you" style="font-size: 24px;"></view>
						</view>
					</view>
					<view class="item" @tap="details" data-id='xzzf15' data-title="先行登记保存证据通知书">
						<view class="title">
							先行登记保存证据通知书
							<view class="iconfont icon-you" style="font-size: 24px;"></view>
						</view>
					</view>
					<view class="item" @tap="details" data-id='xzzf16' data-title="解除先行登记保存证据通知书">
						<view class="title">
							解除先行登记保存证据通知书
							<view class="iconfont icon-you" style="font-size: 24px;"></view>
						</view>
					</view>

					<view class="item" @tap="details" data-id='xzzf17' data-title="实施行政强制措施决定书">
						<view class="title">
							实施行政强制措施决定书
							<view class="iconfont icon-you" style="font-size: 24px;"></view>
						</view>
					</view>
					<view class="item" @tap="details" data-id='xzzf18' data-title="延长行政强制措施期限决定书">
						<view class="title">
							延长行政强制措施期限决定书
							<view class="iconfont icon-you" style="font-size: 24px;"></view>
						</view>
					</view>
					<view class="item" @tap="details" data-id='xzzf19' data-title="解除行政强制措施决定书">
						<view class="title">
							解除行政强制措施决定书
							<view class="iconfont icon-you" style="font-size: 24px;"></view>
						</view>
					</view>
					<view class="item" @tap="details" data-id='xzzf20' data-title="场所/设施/财物清单">
						<view class="title">
							场所/设施/财物清单
							<view class="iconfont icon-you" style="font-size: 24px;"></view>
						</view>
					</view>
					<view class="item" @tap="details" data-id='xzzf21' data-title="抽样记录">
						<view class="title">
							抽样记录
							<view class="iconfont icon-you" style="font-size: 24px;"></view>
						</view>
					</view>
					<view class="item" @tap="details" data-id='201918' data-title="责令改正通知书">
						<view class="title">
							责令改正通知书
							<view class="iconfont icon-you" style="font-size: 24px;"></view>
						</view>
					</view>
					<view class="item" @tap="details" data-id='xzzf26' data-title="责令退款通知书">
						<view class="title">
							责令退款通知书
							<view class="iconfont icon-you" style="font-size: 24px;"></view>
						</view>
					</view>
					<view class="item" @tap="details" data-id='xzzf34' data-title="当场行政处罚决定书">
						<view class="title">
							当场行政处罚决定书
							<view class="iconfont icon-you" style="font-size: 24px;"></view>
						</view>
					</view>
					<view class="item" @tap="details" data-id='xzzf39' data-title="送达回证">
						<view class="title">
							送达回证
							<view class="iconfont icon-you" style="font-size: 24px;"></view>
						</view>
					</view>
				</view>
			</view>
		</view>
	</view>
</template>

<script>
	import api from "@/api/api.js";
	import commonInfo from "@/common/common.js";
	import FilsList from "@/component/other/FilsList.vue";
	export default {
		components: {
			FilsList
		},
		data() {
			return {
				info: "",
				formlist: "",
				forminfo: '' //案件来源登记信息
			}
		},
		onLoad: function(res) {
			if (commonInfo) {
				this.info = commonInfo.userinfo.qyinfo;
				api.getFormscree(res.id,'', (res) => {
					this.forminfo = res;
					console.log(res);
					//企业案件来源登记表的内容
					commonInfo.userinfo.qycase = res;
				});
			}
		},
		methods: {
			details: function(e) {
				let title = e.mp.currentTarget.dataset.title;
				let id = e.mp.currentTarget.dataset.id;
				uni.navigateTo({
					url: '' + id + '/' + id + '?id=' + id + '&&title=' + title + '&&info=' + this.info + ''
				})
			}

		}
	}
</script>

<style>
	@import url("../../static/icon/iconfont.css");

	view {
		box-sizing: border-box;
	}

	.fheader {
		background: #4b559d;
		height: 100upx;
		position: relative;
	}

	.fhead {
		background: #fff;
		width: 80%;
		height: 100upx;
		display: flex;
		margin: 0 auto;
		padding: 10upx 20upx;
		align-items: center;
		font-size: 36upx;
		font-weight: 600;
		position: absolute;
		left: 10%;
		top: 40upx;
		box-shadow: 0px 0px 5px #888888;
		border-radius: 10upx;
	}

	.ftitle {
		width: 60upx;
		height: 60upx;
		color: #fff;
		text-align: center;
		border-radius: 50%;
		line-height: 60upx;
	}

	.ftitle.xiao {
		background: #b296eb;
	}

	.ftitle.sheng {
		background: #699ee2;
	}

	.ftitle.can {
		background: #74d7a9;
	}

	.fcontent {
		padding-left: 20upx;
	}

	.fcont {
		padding: 10% 30upx 2%;
		font-size: 11px;
		color: #333;
	}

	.filelist {
		display: flex;
		font-size: 28upx;
		justify-content: space-between;
		align-items: center;
		padding: 20upx 0;
	}

	.filelist--hover {
		background-color: #f1f1f1;
	}

	.name {
		width: 72%;
	}

	.time {
		flex: 1;
		text-align: center;
	}


	.commonbtn {
		width: 440upx;
		height: 65upx;
		line-height: 65upx;
		margin-top: 70upx;
		background: #4b559d;
		font-size: 30upx;
	}

	.common_title {
		font-size: 30upx;
		display: flex;
		align-items: center;
		color: #333333;
		margin: 20upx 0;
		letter-spacing: 2upx;
		width: 100%;
		height: 40upx;
	}

	.common_title .iconfont {
		font-size: 36upx;
	}

	.item {
		padding: 20upx 0;
	}

	.title {
		font-size: 30upx;
		position: relative;
		display: flex;
		justify-content: space-between;
		align-items: center;
		line-height: 50upx;
	}
</style>
