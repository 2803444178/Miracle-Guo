<template>
	<view>
		<view class="fheader">
			<view class="fhead">
				<view class="ftitle xiao" v-if="info.qylx == '食品销售'">销</view>
				<view class="ftitle can" v-else-if="info.qylx == '餐饮服务'">餐</view>
				<view class="ftitle sheng" v-else>生</view>
				<view class="fcontent">
					{{info.qyname}}
				</view>
			</view>
		</view>

		<view class="fcont">
			<view class="Basics">
				<view class="common_title">
					<view class="iconfont icon-shuxian"></view>
					<view>
						新建表单
					</view>
				</view>
				<view class="content">
					<view class="item" @tap="details" data-id='xzzf01' data-title="案件来源登记表">
						<view class="title">
							案件来源登记表
							<view class="iconfont icon-you" style="font-size: 24px;"></view>
						</view>
					</view>
				</view>
			</view>
			<view class="Basics" v-if="formlist">
				<view class="common_title">
					<view class="iconfont icon-shuxian"></view>
					<view>
						历史案件列表
					</view>
				</view>
				<view class="content" >
					<view v-for="(item,index) in formlist" :key="index" class="filelist" hover-class="filelist--hover">
						<view class="name">
							{{item.SUBJECT}}
						</view>
						<view class="state">
							检查进度：{{item.STATE}}
							<text class="statebtn" @tap="golist(item.ID)">查看详情</text>
						</view>
					</view>
				</view>
				<view class="else">

				</view>
			</view>
		</view>
	</view>
</template>

<script>
	import api from "@/api/api.js";
	import commonInfo from "@/common/common.js";
	import MescrollMixin from "@/component/mescroll-uni/mescroll-mixins.js";
	import {
		apiSearch
	} from "@/api/mock.js"
	import FilsList from "@/component/other/FilsList.vue";
	export default {
		mixins: [MescrollMixin], // 使用mixin (在main.js注册全局组件)
		components: {
			FilsList
		},
		data() {
			return {
				info: "",
				formlist: ""
			}
		},
		onLoad: function() {
			if (commonInfo) {
				this.info = commonInfo.userinfo.qyinfo;
				console.log(commonInfo)
				let data = {};
				data.type = 'AdminEnforce';
				data.id = commonInfo.userinfo.qyinfo.qyid;
				uni.showLoading({
					title: "加载中"
				})
				api.getFromlist(data, (res) => {
					var list;
					if (res.code && res.code == "100001") {
						list = []
					} else {
						list = res;
						for (let i in list) {
							if (list[i].STATE == 0) {
								list[i].STATE = '进行中'
							} else if (list[i].STATE == 1) {
								list[i].STATE = '终止结束'
							} else if (list[i].STATE == 2) {
								list[i].STATE = '取消'
							} else if (list[i].STATE == 3) {
								list[i].STATE = '完成'
							} else if (list[i].STATE == 4) {
								list[i].STATE = '被删除'
							}
						}
					}
					this.formlist = list;
					uni.hideLoading()
				});
			}
		},
		methods: {
			details: function(e) {
				let title = e.mp.currentTarget.dataset.title;
				let id = e.mp.currentTarget.dataset.id;
				uni.navigateTo({
					url: '' + id + '/' + id + '?id=' + id + '&&title=' + title + '&&info=' + this.info + ''
				})
			},
			golist: function(item) {
				uni.navigateTo({
					url: "punish-list?id=" + item + ""
				})
			}

		}
	}
</script>

<style>
	view {
		box-sizing: border-box;
	}

	.fheader {
		background: #4b559d;
		height: 100upx;
		position: relative;
	}

	.fhead {
		background: #fff;
		width: 80%;
		height: 100upx;
		display: flex;
		margin: 0 auto;
		padding: 10upx 20upx;
		align-items: center;
		font-size: 36upx;
		font-weight: 600;
		position: absolute;
		left: 10%;
		top: 40upx;
		box-shadow: 0px 0px 5px #888888;
		border-radius: 10upx;
	}

	.ftitle {
		width: 60upx;
		height: 60upx;
		color: #fff;
		text-align: center;
		border-radius: 50%;
		line-height: 60upx;
	}

	.ftitle.xiao {
		background: #b296eb;
	}

	.ftitle.sheng {
		background: #699ee2;
	}

	.ftitle.can {
		background: #74d7a9;
	}

	.fcontent {
		padding-left: 20upx;
	}

	.fcont {
		padding: 10% 0 2%;
		font-size: 11px;
		color: #333;
	}

	.filelist {
		font-size: 28upx;
		padding: 20upx 40upx;
		position: relative;
		margin-bottom: 20upx;
		background: #fff;
		border-radius: 10upx;
		border: 1px #d6d6d6 solid;
	}

	.filelist--hover {
		background-color: #f1f1f1;
	}



	.name {
		line-height: 50upx;
		margin-bottom: 10upx;
	}

	.state {
		text-align: left;
		position: relative;
		line-height: 50upx;
		flex: 1;
	}

	.statebtn {
		padding: 0 10upx;
		border: 1px #d6d6d6 solid;
		position: absolute;
		right: 0;
		background: #4b559d;
		color: #FFFFFF;
		border-radius: 10upx;
		font-size: 24upx;
	}

	.common_title {
		font-size: 30upx;
		position: relative;
		padding: 0 30upx;
		display: flex;
		align-items: center;
		color: #333333;
		margin: 20upx 0;
		letter-spacing: 2upx;
		width: 100%;
		height: 40upx;
	}

	.common_title .iconfont {
		font-size: 36upx;
	}

	.content {
		padding: 0 20upx;
	}

	.item {
		padding: 30upx 0;
	}

	.title {
		font-size: 30upx;
		padding: 0 30upx;
		position: relative;
		display: flex;
		justify-content: space-between;
		align-items: center;
		line-height: 50upx;
	}
</style>
