<template>
	<view>
		<view class="content">
			<form @submit="submit">
				<view class="totcontent" v-if="fields">
					<view class="section">
						<view class="section__title">当事人：</view>
						<input class="section__input" :value="fields['当事人'] ? fields['当事人']  : '' " disabled />
					</view>
					<view class="section">
						<view class="section__title">主体资格证照名称：</view>
						<input class="section__input" :value="fields['主体资格证照名称'] ? fields['主体资格证照名称']  : '' " disabled />
					</view>
					<view class="section">
						<view class="section__title">统一社会信用代码：</view>
						<input class="section__input" :value="fields['统一社会信用代码'] ? fields['统一社会信用代码']  : '' " disabled />
					</view>
					<view class="section">
						<view class="section__title">住所：</view>
						<input class="section__input" :value="fields['住所'] ? fields['住所']  : '' " disabled />
					</view>
					<view class="section">
						<view class="section__title">法定代表人：</view>
						<input class="section__input" :value="fields['法定代表人'] ? fields['法定代表人']  : '' " disabled />
					</view>
					<view class="section">
						<view class="section__title">身份证号码：</view>
						<input class="section__input" :value="fields['身份证号码'] ? fields['身份证号码']  : '' " disabled />
					</view>
					<view class="section">
						<view class="section__title">联系电话：</view>
						<input class="section__input" :value="fields['联系电话'] ? fields['联系电话']  : '' " disabled />
					</view>
					<view class="section">
						<view class="section__title">其他联系方式（负责人）：</view>
						<input class="section__input" :value="fields['其他联系方式'] ? fields['其他联系方式']  : '' " disabled />
					</view>
					<view class="section">
						<view class="section__title">产品名称产品名称：</view>
						<input class="section__input" :value="fields['产品名称'] ? fields['产品名称']  : '' " disabled />
					</view>
					<view class="section">
						<view class="section__title">型号规格：</view>
						<input class="section__input" :value="fields['型号规格'] ? fields['型号规格']  : '' " disabled />
					</view>
					<view class="section">
						<view class="section__title">标称商标：</view>
						<input class="section__input" :value="fields['标称商标'] ? fields['标称商标']  : '' " disabled />
					</view>
					<view class="section">
						<view class="section__title">保质期：</view>
						<input class="section__input" :value="fields['保质期'] ? fields['保质期']  : '' " disabled />
					</view>
					<view class="section">
						<view class="section__title">标称生产者：</view>
						<input class="section__input" :value="fields['标称生产者'] ? fields['标称生产者']  : '' " disabled />
					</view>
					<view class="section">
						<view class="section__title">标称价格：</view>
						<input class="section__input" :value="fields['标称价格'] ? fields['标称价格']  : '' " disabled />
					</view>
					<view class="section">
						<view class="section__title">生产日期或出厂批号：</view>
						<input class="section__input" :value="fields['生产日期或出厂批号'] ? fields['生产日期或出厂批号']  : '' " disabled />
					</view>
					<view class="section">
						<view class="section__title">产品执行标准编号：</view>
						<input class="section__input" :value="fields['产品执行标准编号'] ? fields['产品执行标准编号']  : '' " disabled />
					</view>
					<view class="section">
						<view class="section__title">标称存储条件：</view>
						<input class="section__input" :value="fields['标称存储条件'] ? fields['标称存储条件']  : '' " disabled />
					</view>
					<view class="section">
						<view class="section__title">生产许可证编号：</view>
						<input class="section__input" :value="fields['生产许可证编号'] ? fields['生产许可证编号']  : '' " disabled />
					</view>
					<view class="section">
						<view class="section__title">标称产品等级：</view>
						<input class="section__input" :value="fields['标称产品等级'] ? fields['标称产品等级']  : '' " disabled />
					</view>
					<view class="section">
						<view class="section__title">包装方式：</view>
						<input class="section__input" :value="fields['包装方式'] ? fields['包装方式']  : '' " disabled />
					</view>
					<view class="section">
						<view class="section">
							<view class="section__title">
								按规定方式抽样：
								<label class="cheackboxlist">
									<checkbox class="radioitem" value="1" @tap="radioChange(fields['规定方式抽样'])" />
								</label>
							</view>
						</view>
						<input class="section__input" :value="fields['按规定方式抽样'] ? fields['按规定方式抽样']  : '' " disabled />
					</view>
					<view class="section">
						<view class="section">
							<view class="section__title">
								以其他方式抽样：
								<label class="cheackboxlist">
									<checkbox class="radioitem" value="1" @tap="radioChange(fields['其他方式抽样'])" />
								</label>
							</view>
						</view>
						<input class="section__input" :value="fields['以其他方式抽样'] ? fields['以其他方式抽样']  : '' " disabled />
					</view>
					<view class="section">
						<view class="section__title">抽取样品数量：</view>
						<input class="section__input" :value="fields['抽取样品数量'] ? fields['抽取样品数量']  : '' " disabled />
					</view>
					<view class="section">
						<view class="section__title">抽样基数：</view>
						<input class="section__input" :value="fields['抽样基数'] ? fields['抽样基数']  : '' " disabled />
					</view>
					<view class="section">
						<view class="section__title">抽取样品过程：</view>
						<input class="section__input" :value="fields['抽取样品过程'] ? fields['抽取样品过程']  : '' " disabled />
					</view>
					<view class="section">
						<view class="section__title">样品封样情况：</view>
						<input class="section__input" :value="fields['样品封样情况'] ? fields['样品封样情况']  : '' " disabled />
					</view>
					<view class="section">
						<view class="section__title">样品存储条件：</view>
						<input class="section__input" :value="fields['样品存储条件'] ? fields['样品存储条件']  : '' " disabled />
					</view>
					<view class="section">
						<view class="section__title">办案人员1：</view>
						<input class="section__input" :value="fields['办案人员1'] ? fields['办案人员1']  : '' " disabled />
					</view>
					<view class="section">
						<view class="section__title">执法证号1：</view>
						<input class="section__input" :value="fields['执法证号1'] ? fields['执法证号1']  : '' " disabled />
					</view>
					<view class="section">
						<view class="section__title">办案人员2：</view>
						<input class="section__input" :value="fields['办案人员2'] ? fields['办案人员2']  : '' " disabled />
					</view>
					<view class="section">
						<view class="section__title">执法证号2：</view>
						<input class="section__input" :value="fields['执法证号2'] ? fields['执法证号2']  : '' " disabled />
					</view>
					<view class="section">
						<view class="section__title">时间：</view>
						<input class="section__input" :value="fields['日期1'] ? fields['日期1']  : '' " disabled />
					</view>
					<view class="section">
						<view class="section__title">当事人签名或盖章：</view>
						<view class="section_canvas">
							<image :src="fields['当事人签名或盖章']" class="qianfa" mode="aspectFit"></image>
						</view>
					</view>
					<view class="section">
						<view class="section__title"> 时间：</view>
						<input class="section__input" :value="fields['日期2'] ? fields['日期2']  : '' " disabled />
					</view>
					<view class="section">
						<view class="section__title">受委托抽样人员签名或盖章：</view>
						<view class="section_canvas">
							<image :src="fields['受委托抽样人员签名或盖章']" class="qianfa" mode="aspectFit"></image>
						</view>
					</view>
					<view class="section">
						<view class="section__title"> 时间：</view>
						<input class="section__input" :value="fields['日期3'] ? fields['日期3']  : '' " disabled />
					</view>

					<view class="section">
						<view class="section__title">见证人签名或盖章：</view>
						<view class="section_canvas">
							<image :src="fields['见证人签名或盖章']" class="qianfa" mode="aspectFit"></image>
						</view>
					</view>
					<view class="section">
						<view class="section__title"> 时间：</view>
						<input class="section__input" :value="fields['日期4'] ? fields['日期4']  : '' " disabled />
					</view>
					<view class="section">
						<view class="section__title">备注：</view>
						<input class="section__input" :value="fields['备注'] ? fields['备注']  : '' " disabled />
					</view>
				</view>
			</form>
		</view>
	</view>
</template>

<script>
	import api from "@/api/api.js"
	import commonInfo from "@/common/common.js"
	var token = null;
	export default {
		data() {
			return {
				showindex: 1,
				dataL: "",
				nowdate: '',
				currentIndex: "",
				//签名信息
				signImage: {
					"被询问人签名": "",
				},
				fields: null
			}
		},
		onLoad: function(res) {
			uni.setNavigationBarTitle({
				title: res.name
			})
			let that = this;
			let name = commonInfo.userinfo.name
			api.GetNowtoken(name, (res) => {
				console.log(res)
				token = res
			});
			uni.showLoading({
				title: "加载中"
			})
			uni.request({
				url: "http://h5.shouyunchina.com:8002/DNServices/businessInfoServlet",
				method: "GET",
				data: {
					recordId: res.recordId,
					id: res.id
				},
				success: async (res) => {
					if (res && res.data) {
						let {
							data: {
								values: values
							}
						} = res;
						let info = res.data;
						info['当事人签名或盖章'] = info['当事人签名或盖章'] && await this.getimg(info['当事人签名或盖章']);
						info['受委托抽样人员签名或盖章'] = info['受委托抽样人员签名或盖章'] && await this.getimg(info['受委托抽样人员签名或盖章']);
						info['见证人签名或盖章'] = info['见证人签名或盖章'] && await this.getimg(info['见证人签名或盖章']);
						console.log(info)
						this.fields = info;
						uni.hideLoading()
					}

				},
				fail: (err) => {
					console.log(err);
					uni.showToast({
						title: "请求失败",
						icon: "none"
					})
				}
			});
		},

		methods: {
			fillet: function(res) {
				if (res == '8361367595765681198') {
					return '符合'
				} else if (res == '-2066416451667277405') {
					return '基本符合'
				} else if (res == '6571312966818286323') {
					return '不符合'
				} else if (res == '986401131406182056') {
					return '通过'
				} else if (res == '-233736429269465346') {
					return '书面整改'
				} else if (res == '-8708609701263029876') {
					return '停业整顿'
				} else if (res == '8997802166051095014') {
					return '否'
				} else if (res == '-6831193320631809582') {
					return '是'
				} else if (res == '5885808606164896166') {
					return '已向你宣读'
				} else if (res == '6573754221301875061') {
					return '请核对'
				} else if (res == '1068839251742507953') {
					return '全部证据'
				} else if (res == '6513549339120258159') {
					return '部分证据'
				} else if (res == '3117111607399304046') {
					return '场所清单'
				} else if (res == '-3564747582551603596') {
					return '财物清单'
				} else if (res == '2944129172193822406') {
					return '设施清单'
				} else if (res == '6897086536934377384') {
					return '男'
				} else if (res == '-4637397066553733657') {
					return '女'
				} else if (res == '3495632856930011401') {
					return '设施'
				} else if (res == '-9102571236001362048') {
					return '财物'
				} else if (res == '7350172593853450270') {
					return '场所'
				} else if (res == '-456001630006194760') {
					return '扣押'
				} else if (res == '1472044003399387940') {
					return '查封'
				} else if (res == '-4807422774013443093') {
					return '立案'
				} else if (res == '-8528133649199512965') {
					return '不予立案'
				}
			},
			getimg: function(id) {
				console.log(id)
				return new Promise((resolve, reject) => {
					let name = commonInfo.userinfo.name
					api.GetNowtoken(name, (res) => {
						console.log(name)
						console.log(res)
						let url = "http://183.203.90.25:8888/seeyon/services/downloadService?token=" + res +
							"&fileId=" + id + "";
						resolve(url)
					});
				})
			},
		},

	}
</script>

<style>
	@import url("../../../static/css/CommonPunish.css");
</style>
