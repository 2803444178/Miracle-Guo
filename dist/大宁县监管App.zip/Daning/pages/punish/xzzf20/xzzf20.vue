<template>
	<view>
		<view class="content" v-if="fields">
			<view class="totcontent" v-show="showindex == 1">
				<view class="section ">
					<view class="section__title">清单编号：</view>
					<view class="section__input ">
						<picker class="pickee" @change="bindTpye($event,fields['场所设施财物'],'1')" :range="fields['场所设施财物'].options"
						 range-key="label">
							<view class="uni-input">{{fields['场所设施财物'].options[index]?fields['场所设施财物'].options[index].label : '请选择'}}</view>
						</picker>
					</view>
				</view>
				<view class="section">
					<view class="section__title">文书编号：</view>
					<input class="section__input" placeholder-class="placesize" name="文书编号" placeholder="文书编号"></input>
				</view>
				<view class="section">
					<view class="section__title" style="display: flex;justify-content: space-between;">
						<text>序号</text>
						<text>标称名称</text>
						<text>场所地址</text>
						<text>单位</text>
						<text>数量</text>
						<text>备注</text>
					</view>
					<view v-for="(item,index) in dataitem" :key="index" style="display: flex;justify-content: space-between;">
						<text>{{item['序号']}}</text>
						<text>{{item['标称名称']}}</text>
						<text>{{item['规格']}}</text>
						<text>{{item['单位']}}</text>
						<text>{{item['数量']}}</text>
						<text>{{item['备注']}}</text>
					</view>
				</view>
				<form @submit="submit">
					<view class="section" v-for="(item,index) in dataList" :key="index">
						<view class="section__title">{{item.name}}：</view>
						<input class="section__input" placeholder-class="placesize" :name="item.indexitem " :placeholder="item.name"></input>
					</view>
					<view class="combtn">
						<button class="btn" form-type="submit">提交</button>
						<button class="btn" form-type="reset">重置</button>
						<button class="btn" @tap="next(2)">下一步</button>
					</view>
				</form>
			</view>
			<view class="totcontent" v-show="showindex == 2">
				<view class="section">
					<view class="section__title">当事人签字：</view>

					<view class="section_canvas" @tap="gocanvas('当事人签字')">
						<view v-if="!signImage['当事人签字']" class="iconfont icon-iconzhengli_shouxieqianpi xiala"></view>
						<image :src="signImage['当事人签字']" class="qianfa" mode="aspectFit"></image>
					</view>
				</view>

				<view class="section">
					<view class="section__title"> 签名日期：</view>
					<view class="iconbox">
						<input class="section__input" @tap="toggleTab('picker','签字日期')" v-model="fields['签字日期'].value" disabled="true"
						 placeholder-class="placesize" placeholder="签字日期"></input>
						<view class="iconfont icon-riqi xiala"></view>
					</view>
				</view>
				<view class="combtn">
					<button class="btn" @tap="pre(1)">上一步</button>
					<button class="btn" @tap="next(3)">下一步</button>
				</view>
			</view>
			<view class="totcontent" v-show="showindex == 3">
				<view class="section">
					<view class="section__title">执法人员签字：</view>
					<view class="section_canvas" @tap="gocanvas('执法人员签字')">
						<view v-if="!signImage['执法人员签字']" class="iconfont icon-iconzhengli_shouxieqianpi xiala"></view>
						<image :src="signImage['执法人员签字']" class="qianfa" mode="aspectFit"></image>
					</view>
				</view>
				<view class="section">
					<view class="section__title"> 签名日期：</view>
					<view class="iconbox">
						<input class="section__input" @tap="toggleTab('picker','执法人员签字日期')" v-model="fields['执法人员签字日期'].value" disabled="true"
						 placeholder-class="placesize" placeholder="执法人员签字日期"></input>
						<view class="iconfont icon-riqi xiala"></view>
					</view>
				</view>
				<view class="combtn">
					<button class="btn" @tap="pre(2)">上一步</button>
					<button class="btn" @tap="next(4)">下一步</button>
				</view>
			</view>
			<view class="totcontent" v-show="showindex == 4">
				<view class="section">
					<view class="section__title">见证人签字：</view>
					<view class="section_canvas" @tap="gocanvas('见证人签字')">
						<view v-if="!signImage['见证人签字']" class="iconfont icon-iconzhengli_shouxieqianpi xiala"></view>
						<image :src="signImage['见证人签字']" class="qianfa" mode="aspectFit"></image>
					</view>
				</view>
				<view class="section">
					<view class="section__title"> 签名日期：</view>
					<view class="iconbox">
						<input class="section__input" @tap="toggleTab('picker','见证人签字日期')" v-model="fields['见证人签字日期'].value" disabled="true"
						 placeholder-class="placesize" placeholder="见证人签字日期"></input>
						<view class="iconfont icon-riqi xiala"></view>
					</view>
					<view class="itemcontent">
						本文书一式(
						<input v-model="fields['份数'].value" placeholder-class="placesize" class="placeinpu" />
						)份,(<input v-model="fields['送达份数'].value" placeholder-class="placesize" class="placeinpu" />
						)份送达，一份归档,其他剩余(<input v-model="fields['份数处理'].value" placeholder-class="placesize" class="placeinpu" />
						)份
					</view>
				</view>
				<view class="combtn">
					<button class="btn" @tap="pre(3)">上一步</button>
					<button class="btn" @tap="submittt">提交</button>
				</view>
			</view>
			<w-picker mode="dateTime" hasSecond="true" :current="false" @confirm="onConfirme" :disabledAfter="false" ref="picker"></w-picker>
		</view>
	</view>
</template>

<script>
	import api from "@/api/api.js"
	import commonInfo from "@/common/common.js";
	var token;
	export default {
		data() {
			return {
				dataL: "",
				fields: null,
				nowdate: '',
				currentIndex: "",
				index: -1,
				showindex: 1,
				signImage: {
					"当事人签字": "",
					"执法人员签字": "",
					"见证人签字": "",
				},
				dataitem: [],
				dataList: [{
						name: "序号",
						indexitem: "序号"
					},
					{
						name: "标称名称/场所",
						indexitem: "标称名称"
					},
					{
						name: "规格（型号）/场所地址",
						indexitem: "规格"
					},
					{
						name: "单位",
						indexitem: "单位"
					},
					{
						name: "数量",
						indexitem: "数量"
					},
					{
						name: "备注",
						indexitem: "备注"
					}
				],
				backbtn: true,
				key:null
			}
		},
		onLoad: function(res) {
			//设置标题
			uni.setNavigationBarTitle({
				title: res.title
			})
			this.title = res.title;
			let key = commonInfo.userinfo.qycase.ID + '' + res.title;
			this.key = key;
			let name = commonInfo.userinfo.name;
			//获取模板
			console.log(commonInfo.userinfo.qycase)
			api.GetNowtoken(name, (Tokendata) => {
				token = Tokendata
				if (res) {
					api.getFormdata(key, res.id, name, (res, fields) => {
						console.log(fields)
						api.initFields(fields, commonInfo.userinfo.qycase, 'xzzf20');
						res.token = Tokendata;
						this.dataL = res;
						this.fields = fields;
					})
				}
			});
			var that = this;
			uni.$on('update', function(data) {
				let arrobj = that.signImage;
				let name = data.name;
				let imgurl = data[data.name];
				let token = commonInfo.userinfo.token;
				let obj = that.dataL;
				api.Getsign(obj, name, imgurl, token, function(res) {
					that.dataL = res;
				})
				for (let i in arrobj) {
					if (arrobj[data.name] == "") {
						arrobj[data.name] = data[data.name]
					}
				}
			})
		},
		onBackPress: function() {
			var that = this;
			if (this.backbtn) {
				uni.showModal({
					title: '提示',
					content: '确定保存本次编辑？',
					success: function(res) {
						if (res.confirm) {
							let key = commonInfo.userinfo.qycase.ID + '' + that.title;
							console.log(that.dataL.data.values)
							uni.setStorageSync(key, that.dataL)
							that.backbtn = false;
							uni.navigateBack()
						} else if (res.cancel) {
							console.log('用户点击取消');
							that.backbtn = true;
						}
					}
				});
				return true
			} else {
				return false
			}
		},
		methods: {
			toggleTab(str, index) {
				this.currentIndex = index;
				this.$refs[str].show();
			},
			onConfirme(val) {
				console.log(val)
				this.fields[this.currentIndex].value = val.result;
			},
			gocanvas: function(name) {
				uni.navigateTo({
					url: "../xzzcan/xzzcan?name=" + name + ""
				})
			},
			next: function(res) {
				this.showindex = res;
			},
			pre: function(res) {
				this.showindex = res;
			},
			bindTpye: function(e, field, intype) {
				console.log(intype)
				let name = field.name;
				let index = e.target.value
				let value = this.fields[name].options[index].value;
				field.value = value;
				if (intype == 1) {
					this.index = index;
				}
			},

			submit: function(e) {
				let result = e.detail.value;
				let num = this.dataitem.length + 1;
				this.fields['序号' + num].value = result['序号'];
				this.fields['标称名称' + num].value = result['标称名称'];
				this.fields['规格' + num].value = result['规格'];
				this.fields['单位' + num].value = result['单位'];
				this.fields['数量' + num].value = result['数量'];
				this.fields['备注' + num].value = result['备注'];
				if (this.dataitem.length >= 20) {
					uni.showToast({
						title: "数量超限",
						icon: "none"
					})
					return false
				} else {
					this.dataitem.push(e.detail.value)
				}
				this.formReset()
				console.log(this.dataList)

			},
			formReset: function(e) {
				console.log('清空数据')
			},

			submittt: function(e) {
				/* 将案件来源登记表的信息缓存，以便于关联使用 */
				api.postFormdata(this.dataL, (res) => {
					console.log(res)
					if (res && res.code == '0') {
						uni.hideLoading();
						uni.showToast({
							title: "提交成功",
							icon: "success"
						})
						uni.removeStorage({
							key: this.key,
							success: function(res) {
								setTimeout(function() {
									uni.navigateTo({
										url: "../punsucess/punsucess"
									})
								}, 300)
							}
						});
					} else {
						uni.hideLoading();
						uni.showToast({
							title: "提交失败",
							icon: "none"
						})
					}
				}, (err) => {
					console.log(err)
					uni.showToast({
						title: "错误",
						icon: "none"
					})
				});
			}
		},
	}
</script>

<style>
	@import url("../../../static/css/CommonPunish.css");
</style>
