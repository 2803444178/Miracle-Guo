<template>
	<view>
		<view class="content">
			<form @submit="submit" v-if="fields">
				<view class="totcontent"v-show=" showindex == 1 ">
					<view class="section">
						<view class="section__title">开始时间：</view>
						<view class="iconbox">
							<input class="section__input" @tap="toggleTab('picker','检查时间起')" v-model="fields['检查时间起'].value" disabled="true"
							 placeholder-class="placesize" placeholder="开始时间"></input>
							<view class="iconfont icon-riqi xiala"></view>
						</view>
					</view>
					<view class="section">
						<view class="section__title">结束时间：</view>
						<view class="iconbox">
							<input class="section__input" @tap="toggleTab('picker','检查时间终')" v-model="fields['检查时间终'].value" disabled="true"
							 placeholder-class="placesize" placeholder="结束时间"></input>
							<view class="iconfont icon-riqi xiala"></view>
						</view>
					</view>
					<view class="section">
						<view class="section__title">地点：</view>
						<input class="section__input" v-model="fields['询问地点'].value" placeholder-class="placesize" name="询问地点"
						 placeholder="地点"></input>
					</view>
					<view class="section">
						<view class="section__title">检查次数：</view>
						<input class="section__input" v-model="fields['第几次'].value" placeholder-class="placesize" placeholder="检查次数"></input>
					</view>
					<view class="section">
						<view class="section__title">询问人1：</view>
						<input class="section__input" v-model="fields['询问人'].value" placeholder-class="placesize" placeholder="询问人1"></input>
					</view>
					<view class="section ">
						<view class="section__title">执法证号1：</view>
						<input class="section__input" v-model="fields['执法证号1'].value" placeholder-class="placesize" placeholder="执法证号1"></input>
					</view>
					<view class="section">
						<view class="section__title">询问人2：</view>
						<input class="section__input" v-model="fields['询问人2'].value" placeholder-class="placesize" placeholder="询问人2"></input>
					</view>
					<view class="section ">
						<view class="section__title">执法证号2：</view>
						<input class="section__input" v-model="fields['执法证号2'].value" placeholder-class="placesize" placeholder="执法证号2"></input>
					</view>
					<button class="btn" @tap="next(2)">下一步</button>
				</view>
				<view class="totcontent" v-show=" showindex == 2 ">
					<!-- <view class="section">
						<view class="section__title">被询问人：</view>
						<input class="section__input" v-model="fields['被询问人'].value" placeholder-class="placesize" placeholder="被询问人"></input>
					</view> -->
					<view class="section">
						<view class="section__titl">性别：</view>
						<view class="iconbox">
							<picker class="pickee" @change="bindTpye($event,fields['性别'],'1')" :range="fields['性别'].options" range-key="label">
								<view class="section__input">{{fields['性别'].options[index]?fields['性别'].options[index].label : '请选择'}}</view>
							</picker>
							<view class="iconfont icon-xiala xiala"></view>
						</view>
					</view>
					<view class="section">
						<view class="section__title">身份证（其他有效证件）号码：</view>
						<input class="section__input" v-model="fields['身份证号码'].value" placeholder-class="placesize" name="身份证号码"
						 placeholder="身份证（其他有效证件）号码"></input>
					</view>
					<view class="section">
						<view class="section__title">工作单位：</view>
						<input class="section__input" v-model="fields['工作单位'].value" placeholder-class="placesize" placeholder="工作单位"></input>
					</view>
					<view class="section">
						<view class="section__title">职务：</view>
						<input class="section__input" v-model="fields['职务'].value" placeholder-class="placesize" placeholder="职务"></input>
					</view>
					<view class="section">
						<view class="section__title">联系电话：</view>
						<input class="section__input" v-model="fields['联系电话'].value" placeholder-class="placesize" placeholder="联系电话"></input>
					</view>
					<view class="section">
						<view class="section__title">其他联系方式：</view>
						<input class="section__input" v-model="fields['其他联系方式'].value" placeholder-class="placesize" placeholder="其他联系方式"></input>
					</view>
					<view class="section">
						<view class="section__title">联系地址：</view>
						<input class="section__input" v-model="fields['联系地址'].value" placeholder-class="placesize" placeholder="联系地址"></input>
					</view>
					<view class="combtn">
						<button class="btn" @tap="pre(1)">上一步</button>
						<button class="btn" @tap="next(3)">下一步</button>
					</view>
				</view>
				<view class="totcontent" v-show="showindex == 3">
					<view class="totcontent">
						<view class="itemcontent">
							检查人员：我们是<input type="text" v-model="fields['市场监管局名称'].value" class="placeinput" />
							的执法人员，现向你出示
							我们的执法证件，你是否看清楚？
						</view>
					</view>
					<view class="section ">
						<view class="section__title">当事人：</view>
						<view class="iconbox">
							<picker class="pickee" @change="bindTpye($event,fields['被询问人是否看清楚'],'2')" :range="fields['被询问人是否看清楚'].options"
							 range-key="label">
								<view class="section__input">{{fields['被询问人是否看清楚'].options[indexq]?fields['被询问人是否看清楚'].options[indexq].label : '请选择'}}</view>
							</picker>
							<view class="iconfont icon-xiala xiala"></view>
						</view>
					</view>
					<view class="totcontent">
						<view class="itemcontent">
							我们依法就
							<input v-model="fields['依法调查问题'].value" placeholder-class="placesize" class="placeinput" />
							有关问题进行调查，请予配合。依
							照法律规定，你有权进行陈述和申辩。如果你认为调查人员与本案有直
							接利害关系的，依法有申请回避的权利，你是否申请调查人员回避？
						</view>
					</view>
					<view class="section ">
						<view class="section__title">当事人：</view>
						<view class="iconbox">
							<picker class="pickee" @change="bindTpye($event,fields['是否申请回避'],'3')" :range="fields['是否申请回避'].options"
							 range-key="label">
								<view class="section__input">{{fields['是否申请回避'].options[indexw]?fields['是否申请回避'].options[indexw].label : '请选择'}}</view>
							</picker>
							<view class="iconfont icon-xiala xiala"></view>
						</view>
					</view>
					<view class="totcontent">
						<view class="itemcontent">
							问：你应当如实回答询问，并协助调查，不得阻挠。你是否明白？
						</view>
					</view>
					<view class="section ">
						<view class="section__title">当事人：</view>
						<view class="iconbox">
							<picker class="pickee" @change="bindTpye($event,fields['是否明白'],'4')" :range="fields['是否明白'].options" range-key="label">
								<view class="section__input">{{fields['是否明白'].options[indexe]?fields['是否明白'].options[indexe].label : '请选择'}}</view>
							</picker>
							<view class="iconfont icon-xiala xiala"></view>
						</view>
					</view>
					<view class="combtn">
						<button class="btn" @tap="pre(2)">上一步</button>
						<button class="btn" @tap="next(4)">下一步</button>
					</view>
				</view>
				<view class="totcontent" v-show=" showindex == 4 ">
					<view class="section">
						<view class="section__title">被询问人：</view>
						<input class="section__input" v-model="fields['被询问人2'].value" placeholder-class="placesize" placeholder="当事人"></input>
					</view>
					<view class="section">
						<view class="section__title"> 日期：</view>
						<view class="iconbox">
							<input class="section__input" @tap="toggleTab('picker','被询问人2日期')" v-model="fields['被询问人2日期'].value" disabled="true"
							 placeholder-class="placesize" placeholder="当事人时间"></input>
							<view class="iconfont icon-riqi xiala"></view>
						</view>
					</view>

					<view class="section">
						<view class="section__title">询问人3：</view>
						<input class="section__input" v-model="fields['询问人3'].value" placeholder-class="placesize" name="询问人3"
						 placeholder="询问人"></input>
					</view>
					<view class="section">
						<view class="section__title">询问人4：</view>
						<input class="section__input" v-model="fields['询问人4'].value" placeholder-class="placesize" name="询问人4"
						 placeholder="询问人"></input>
					</view>
					<view class="section">
						<view class="section__title"> 日期：</view>
						<view class="iconbox">
							<input class="section__input" @tap="toggleTab('picker','询问人日期')" v-model="fields['询问人日期'].value" disabled="true"
							 placeholder-class="placesize" placeholder="当事人时间"></input>
							<view class="iconfont icon-riqi xiala"></view>
						</view>
					</view>
					<view class="section">
						<view class="section__title">被询问内容：</view>
						<textarea class="section__text" v-model="fields['被询问内容'].value" placeholder-class="placesize"  placeholder="被询问内容"   />
						</view>
					

					<view class="totcontent">
						<view class="itemcontent">
							<view class="section__title">询问人：以上是本次询问情况的记录，请</view>
							<view class="iconbox">
								<picker class="pickee" @change="bindTpye($event,fields['请核对或已向你宣读'],'5')" :range="fields['请核对或已向你宣读'].options"
								 range-key="label">
									<view class="section__input">{{fields['请核对或已向你宣读'].options[indexr]?fields['请核对或已向你宣读'].options[indexr].label : '请选择'}}</view>
								</picker>
								<view class="iconfont icon-xiala xiala"></view>
							</view>
							<view class="section__title">。如果属实请签名。</view>
						
						</view>
					</view>

					<view class="section">
						<view class="section__title">被询问人签名签名：</view>
						<view class="section_canvas" @tap="gocanvas('被询问人签名')">
							<view v-if="!signImage['被询问人签名']" class="iconfont icon-iconzhengli_shouxieqianpi xiala"></view>
							<image :src="signImage['被询问人签名']" class="qianfa" mode="aspectFit"></image>
						</view>
					</view>
					<view class="section">
						<view class="section__title">被询问人：</view>
						<input class="section__input" v-model="fields['被询问人3'].value" placeholder-class="placesize" placeholder="当事人"></input>
					</view>
					<view class="section">
						<view class="section__title"> 日期：</view>
						<view class="iconbox">
							<input class="section__input" @tap="toggleTab('picker','域33')" v-model="fields['域33'].value" disabled="true"
							 placeholder-class="placesize" placeholder="当事人时间"></input>
							<view class="iconfont icon-riqi xiala"></view>
						</view>
					</view>
					<view class="section">
						<view class="section__title">询问人：</view>
						<input class="section__input" v-model="fields['询问人5'].value" placeholder-class="placesize" placeholder="询问人"></input>
					</view>
					<view class="section">
						<view class="section__title">询问人：</view>
						<input class="section__input" v-model="fields['询问人6'].value" placeholder-class="placesize" placeholder="询问人"></input>
					</view>
					<view class="section">
						<view class="section__title"> 日期：</view>

						<view class="iconbox">
							<input class="section__input" @tap="toggleTab('picker','询问人日期2')" v-model="fields['询问人日期2'].value" disabled="true"
							 placeholder-class="placesize" placeholder="询问人日期2"></input>
							<view class="iconfont icon-riqi xiala"></view>
						</view>
					</view>
					<view class="combtn">
						<button class="btn" @tap="pre(3)">上一步</button>
						<button class="btn" form-type="submit">提交</button>
					</view>
				</view>
			</form>
			<w-picker mode="dateTime" hasSecond="true" :current="false" @confirm="onConfirme" :disabledAfter="false" ref="picker"></w-picker>
		</view>
	</view>
</template>

<script>
	import api from "@/api/api.js"
	import commonInfo from "@/common/common.js";
	var token;
	export default {
		data() {
			return {
				showindex: 1,
				dataL: "",
				nowdate: '',
				currentIndex: "",
				//签名信息
				signImage: {
					"被询问人签名": "",
				},
				fields:null,
				// 企业信息
				GenderIndex: 0,
				index: -1,
				indexq: -1,
				indexw: -1,
				indexe: -1,
				indexr: -1,
				backbtn: true,
				key:null,
				
			}
		},
		onBackPress: function() {
			var that = this;
			if (this.backbtn) {
				uni.showModal({
					title: '提示',
					content: '确定保存本次编辑？',
					success: function(res) {
						if (res.confirm) {
							let key = commonInfo.userinfo.qycase.ID + '' + that.title;
							console.log(that.dataL.data.values)
							uni.setStorageSync(key, that.dataL)
							that.backbtn = false;
							uni.navigateBack()
						} else if (res.cancel) {
							console.log('用户点击取消');
							that.backbtn = true;
						}
					}
				});
				return true
			} else {
				return false
			}
		},
		onLoad: function(res) {
			//设置标题
			uni.setNavigationBarTitle({
				title: res.title
			})
			this.title = res.title;
			let key = commonInfo.userinfo.qycase.ID + '' + res.title;
			this.key = key;
			let name = commonInfo.userinfo.name;
			//获取模板
			console.log(commonInfo.userinfo.qycase)
			api.GetNowtoken(name, (Tokendata) => {
				token = Tokendata
				if (res) {
					api.getFormdata(key, res.id, name, (res, fields) => {
						console.log(fields)
						api.initFields(fields, commonInfo.userinfo.qycase, 'xzzf11');
						res.token = Tokendata;
						this.dataL = res;
						this.fields = fields;
					})
				}
			});
			var that = this;
			uni.$on('update', function(data) {
				let arrobj = that.signImage;
				let name = data.name;
				let imgurl = data[data.name];
				let token = commonInfo.userinfo.token;
				let obj = that.dataL;
				api.Getsign(obj, name, imgurl, token, function(res) {
					that.dataL = res;
				})
				for (let i in arrobj) {
					if (arrobj[data.name] == "") {
						arrobj[data.name] = data[data.name]
					}
				}
			})
		},

		methods: {
			next: function(res) {
				this.showindex = res;
			},
			pre: function(res) {
				this.showindex = res;
			},
			toggleTab(str, index) {
				console.log(index)
				this.$refs[str].show();
				this.currentIndex = index;
				console.log(this.fields)
			},
			onConfirme(val) {
				this.fields[this.currentIndex].value = val.result;
			},
			gocanvas: function(name) {
				uni.navigateTo({
					url: "../xzzcan/xzzcan?name=" + name + ""
				})
			},
			bindTpye: function(e, field, intype) {
				console.log(intype)
				let name = field.name;
				let index = e.target.value
				let value = this.fields[name].options[index].value;
				field.value = value;
				if (intype == 1) {
					this.index = index;
				} else if (intype == 2) {
					this.indexq = index
				} else if (intype == 3) {
					this.indexw = index
				} else if (intype == 4) {
					this.indexe = index
				} else if (intype == 5) {
					this.indexr = index
				}
			},
			submit: function(e) {
				/* 将案件来源登记表的信息缓存，以便于关联使用 */
				api.postFormdata(this.dataL, (res) => {
					console.log(res)
					if (res && res.code == '0') {
						uni.hideLoading();
						uni.showToast({
							title: "提交成功",
							icon: "success"
						})
						uni.removeStorage({
							key: this.key,
							success: function(res) {
								setTimeout(function() {
									uni.navigateTo({
										url: "../punsucess/punsucess"
									})
								}, 300)
							}
						});
					} else {
						uni.hideLoading();
						uni.showToast({
							title: "提交失败",
							icon: "none"
						})
					}
				}, (err) => {
					console.log(err)
					uni.showToast({
						title: "错误",
						icon: "none"
					})
				});
			}
		},
	}
</script>

<style>
	@import url("../../../static/css/CommonPunish.css");
</style>
