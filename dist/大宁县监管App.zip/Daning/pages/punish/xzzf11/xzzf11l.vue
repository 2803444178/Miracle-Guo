<template>
	<view>
		<view class="content">
			<view class="totcontent" v-if="fields">
				<view class="section">
					<view class="section__title">开始时间：</view>
					<view class="iconbox">
						<input :value="fields['检查时间起'] ?  fields['检查时间起'] : ''" class="section__input" disabled />
					</view>
				</view>
				<view class="section">
					<view class="section__title">结束时间：</view>
					<view class="iconbox">
						<input :value="fields['检查时间终'] ?  fields['检查时间终'] : ''" class="section__input" disabled />
					</view>
				</view>
				<view class="section">
					<view class="section__title">地点：</view>
					<input :value="fields['询问地点'] ?  fields['询问地点'] : ''" class="section__input" disabled />
				</view>
				<view class="section">
					<view class="section__title">检查次数：</view>
					<input :value="fields['第几次'] ?  fields['第几次'] : ''" class="section__input" disabled />
				</view>
				<view class="section">
					<view class="section__title">询问人1：</view>
					<input :value="fields['询问人'] ?  fields['询问人'] : ''" class="section__input" disabled />
				</view>
				<view class="section ">
					<view class="section__title">执法证号1：</view>
					<input :value="fields['执法证号1'] ?  fields['执法证号1'] : ''" class="section__input" disabled />
				</view>
				<view class="section">
					<view class="section__title">询问人2：</view>
					<input :value="fields['询问人2'] ?  fields['询问人2'] : ''" class="section__input" disabled />
				</view>
				<view class="section ">
					<view class="section__title">执法证号2：</view>
					<input :value="fields['执法证号2'] ?  fields['执法证号2'] : ''" class="section__input" disabled />
				</view>
				<view class="section">
					<view class="section__title">被询问人：</view>
					<input :value="fields['被询问人'] ?  fields['被询问人'] : ''" class="section__input" disabled />
				</view>
				<view class="section">
					<view class="section__titl">性别：</view>
					<input :value="fields['性别'] ?  fields['性别'] : ''" class="section__input" disabled />
				</view>
				<view class="section">
					<view class="section__title">身份证（其他有效证件）号码：</view>
					<input :value="fields['身份证号码'] ?  fields['身份证号码'] : ''" class="section__input" disabled />
				</view>
				<view class="section">
					<view class="section__title">工作单位：</view>
					<input :value="fields['工作单位'] ?  fields['工作单位'] : ''" class="section__input" disabled />
				</view>
				<view class="section">
					<view class="section__title">职务：</view>
					<input :value="fields['职务'] ?  fields['职务'] : ''" class="section__input" disabled />
				</view>
				<view class="section">
					<view class="section__title">联系电话：</view>
					<input :value="fields['联系电话'] ?  fields['联系电话'] : ''" class="section__input" disabled />
				</view>
				<view class="section">
					<view class="section__title">其他联系方式：</view>
					<input :value="fields['其他联系方式'] ?  fields['其他联系方式'] : ''" class="section__input" disabled />
				</view>
				<view class="section">
					<view class="section__title">联系地址：</view>
					<input :value="fields['联系地址'] ?  fields['联系地址'] : ''" class="section__input" disabled />
				</view>
				<view class="totcontent">
					<view class="itemcontent">
						检查人员：我们是<input type="text" :value="fields['市场监管局名称']? fields['市场监管局名称'] : ''" disabled class="placeinput" />
						的执法人员，现向你出示
						我们的执法证件，你是否看清楚？
					</view>
				</view>
				<view class="section ">
					<view class="section__title">当事人：</view>
					<input class="section__input" :value="fields['被询问人是否看清楚'] ">
				</view>
				<view class="totcontent">
					<view class="itemcontent">
						我们依法就
						<input :value="fields['依法调查问题'] ?  fields['依法调查问题'] : ''" class="section__input" disabled />
						有关问题进行调查，请予配合。依
						照法律规定，你有权进行陈述和申辩。如果你认为调查人员与本案有直
						接利害关系的，依法有申请回避的权利，你是否申请调查人员回避？
					</view>
				</view>
				<view class="section ">
					<view class="section__title">当事人：</view>
					<input class="section__input" disabled :value="fields['是否申请回避'] ">
				</view>
				<view class="totcontent">
					<view class="itemcontent">
						问：你应当如实回答询问，并协助调查，不得阻挠。你是否明白？
					</view>
				</view>
				<view class="section ">
					<view class="section__title">当事人：</view>
					<input class="section__input" disabled :value="fields['是否明白'] ">
				</view>

				<view class="section">
					<view class="section__title">被询问人：</view>
					<input class="section__input" disabled :value="fields['被询问人2']"></input>
				</view>
				<view class="section">
					<view class="section__title"> 日期：</view>
					<input :value="fields['被询问人2日期'] ?  fields['被询问人2日期'] : ''" class="section__input" disabled />
				</view>

				<view class="section">
					<view class="section__title">询问人3：</view>
					<input :value="fields['询问人3'] ?  fields['询问人3'] : ''" class="section__input" disabled />
				</view>
				<view class="section">
					<view class="section__title">询问人4：</view>
					<input :value="fields['询问人4'] ?  fields['询问人4'] : ''" class="section__input" disabled />
				</view>
				<view class="section">
					<view class="section__title"> 日期：</view>
					<input :value="fields['询问人日期'] ?  fields['询问人日期'] : ''" class="section__input" disabled />
				</view>
				<view class="section" style="padding: 10upx 0; border-bottom: none;">
					<textarea class="section_text" :value="fields['被询问内容']?  fields['被询问内容'] : ''" disabled /></textarea>
				</view>

				<view class="totcontent">
					<view class="itemcontent">
						询问人：以上是本次询问情况的记录，
						请
						<input :value="fields['请核对或已向你宣读'] ?  fields['请核对或已向你宣读'] : ''" class="section__input" disabled />
						。如果属实请
						签名。
					</view>
				</view>
				<view class="section">
					<view class="section__title">被询问人签名签名：</view>
					<view class="section_canvas">
						<image :src="fields['被询问人签名'] " class="qianfa" mode="aspectFit"></image>
					</view>
				</view>
				<view class="section">
					<view class="section__title">被询问人：</view>
					<input :value="fields['被询问人3'] ?  fields['被询问人3'] : ''" class="section__input" disabled />
				</view>
				<view class="section">
					<view class="section__title"> 日期：</view>
					<view class="iconbox">
						<input :value="fields['域33'] ?  fields['域33'] : ''" class="section__input" disabled />
					</view>
				</view>
				<view class="section">
					<view class="section__title">询问人：</view>
					<input :value="fields['询问人5'] ?  fields['询问人5'] : ''" class="section__input" disabled />
				</view>
				<view class="section">
					<view class="section__title">询问人：</view>
					<input :value="fields['询问人6'] ?  fields['询问人6'] : ''" class="section__input" disabled />
				</view>
				<view class="section">
					<view class="section__title"> 日期：</view>
					<input :value="fields['询问人日期2'] ?  fields['询问人日期2'] : ''" class="section__input" disabled />
				</view>
			</view>
		</view>
	</view>
</template>

<script>
	import api from "@/api/api.js"
	import commonInfo from "@/common/common.js"
	var token = null;
	export default {
		data() {
			return {
				showindex: 1,
				dataL: "",
				nowdate: '',
				currentIndex: "",
				//签名信息
				signImage: {
					"被询问人签名": "",
				},
				fields: null
			}
		},
		onLoad: function(res) {
			uni.setNavigationBarTitle({
				title: res.name
			})
			let that = this;
			let name = commonInfo.userinfo.name
			api.GetNowtoken(name, (res) => {
				console.log(res)
				token = res
			});
			uni.showLoading({
				title: "加载中"
			})
			uni.request({
				url: "http://h5.shouyunchina.com:8002/DNServices/businessInfoServlet",
				method: "GET",
				data: {
					recordId: res.recordId,
					id: res.id
				},
				success: async (res) => {
					if (res && res.data) {
						let {
							data: {
								values: values
							}
						} = res;
						let info = res.data;
						info['请核对或已向你宣读'] = info['请核对或已向你宣读'] && this.fillet(info['请核对或已向你宣读']);
						info['性别'] = info['性别'] && this.fillet(info['性别']);
						info['是否申请回避'] = info['是否申请回避'] && this.fillet(info['是否申请回避']);
						info['是否明白'] = info['是否明白'] && this.fillet(info['是否明白']);
						info['被询问人是否看清楚'] = info['被询问人是否看清楚'] && this.fillet(info['被询问人是否看清楚']);
						info['被询问人签名'] = info['被询问人签名'] && await this.getimg(info['被询问人签名']);
						console.log(info)
						this.fields = info;
						uni.hideLoading()
					}
				},
				fail: (err) => {
					console.log(err);
					uni.showToast({
						title: "请求失败",
						icon: "none"
					})
				}
			});
		},
		methods: {
			fillet: function(res) {
				if (res == '8361367595765681198') {
					return '符合'
				} else if (res == '-2066416451667277405') {
					return '基本符合'
				} else if (res == '6571312966818286323') {
					return '不符合'
				} else if (res == '986401131406182056') {
					return '通过'
				} else if (res == '-233736429269465346') {
					return '书面整改'
				} else if (res == '-8708609701263029876') {
					return '停业整顿'
				} else if (res == '8997802166051095014') {
					return '否'
				} else if (res == '-6831193320631809582') {
					return '是'
				} else if (res == '5885808606164896166') {
					return '已向你宣读'
				} else if (res == '6573754221301875061') {
					return '请核对'
				} else if (res == '1068839251742507953') {
					return '全部证据'
				} else if (res == '6513549339120258159') {
					return '部分证据'
				} else if (res == '3117111607399304046') {
					return '场所清单'
				} else if (res == '-3564747582551603596') {
					return '财物清单'
				} else if (res == '2944129172193822406') {
					return '设施清单'
				} else if (res == '6897086536934377384') {
					return '男'
				} else if (res == '-4637397066553733657') {
					return '女'
				} else if (res == '3495632856930011401') {
					return '设施'
				} else if (res == '-9102571236001362048') {
					return '财物'
				} else if (res == '7350172593853450270') {
					return '场所'
				} else if (res == '-456001630006194760') {
					return '扣押'
				} else if (res == '1472044003399387940') {
					return '查封'
				} else if (res == '-4807422774013443093') {
					return '立案'
				} else if (res == '-8528133649199512965') {
					return '不予立案'
				}
			},
			getimg: function(id) {
				console.log(id)
				return new Promise((resolve, reject) => {
					let name = commonInfo.userinfo.name
					api.GetNowtoken(name, (res) => {
						console.log(name)
						console.log(res)
						let url = "http://183.203.90.25:8888/seeyon/services/downloadService?token=" + res +
							"&fileId=" + id + "";
						resolve(url)
					});
				})
			},
		},

	}
</script>

<style>
	@import url("../../../static/css/CommonPunish.css");
</style>
