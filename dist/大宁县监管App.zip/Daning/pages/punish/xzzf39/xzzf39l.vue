<template>
	<view>
		<view class="content">
			<form @submit="submit">
				<view class="totcontent" v-if="fields">
					<view class="section">
						<view class="section__title">送达文书名称及文号：</view>
						<input class="section__input" :value="fields['送达文书名称及文号'] ? fields['送达文书名称及文号']  : '' " disabled></input>
					</view>
					<view class="section">
						<view class="section__title">受送达人：</view>
						<input class="section__input" :value="fields['受送达人'] ? fields['受送达人']  : '' " disabled></input>
					</view>
					<view class="section ">
						<view class="section__title">送达时间：</view>
						<input class="section__input" :value="fields['送达时间'] ? fields['送达时间']  : '' " disabled></input>
					</view>
					<view class="section">
						<view class="section__title">送达地点：</view>
						<input class="section__input" :value="fields['送达地点'] ? fields['送达地点']  : '' " disabled></input>
					</view>
					<view class="section">
						<view class="section__title">送达方式：</view>
						<input class="section__input" :value="fields['送达方式'] ? fields['送达方式']  : '' " disabled></input>
					</view>
					<view class="section">
						<view class="section__title">收件人签名或盖章：</view>
						<view class="section_canvas">
							<image :src="fields['收件人签名或盖章']" class="qianfa" mode="aspectFit"></image>
						</view>
					</view>
					<view class="section">
						<view class="section__title"> 签名日期：</view>
						<input class="section__input" :value="fields['收件人日期'] ? fields['收件人日期']  : '' " disabled></input>
					</view>
					<view class="section">
						<view class="section__title">送达人签名或盖章：</view>
						<view class="section_canvas">
							<image :src="fields['送达人签名或盖章']" class="qianfa" mode="aspectFit"></image>
						</view>
					</view>
					<view class="section">
						<view class="section__title"> 签名日期：</view>
						<input class="section__input" :value="fields['送达人日期'] ? fields['送达人日期']  : '' " disabled></input>
					</view>
					<view class="section">
						<view class="section__title">见证人签名或盖章：</view>
						<view class="section_canvas">
							<image :src="fields['见证人签名或盖章']" class="qianfa" mode="aspectFit"></image>
						</view>
					</view>
					<view class="section">
						<view class="section__title"> 签名日期：</view>
						<input class="section__input" :value="fields['见证人日期'] ? fields['见证人日期']  : '' " disabled></input>
					</view>
					<view class="section">
						<view class="section__title">备注：</view>
						<input class="section__input" :value="fields['备注'] ? fields['备注']  : '' " disabled></input>
					</view>
				</view>
			</form>
		</view>
	</view>
</template>

<script>
	import api from "@/api/api.js"
	import commonInfo from "@/common/common.js"
	var token = null;
	export default {
		data() {
			return {
				fields: null,
			}
		},
		onLoad: function(res) {
			uni.setNavigationBarTitle({
				title: res.name
			})
			let that = this;
			let name = commonInfo.userinfo.name
			api.GetNowtoken(name, (res) => {
				console.log(res)
				token = res
			});
			uni.showLoading({
				title: "加载中"
			})
			uni.request({
				url: "http://h5.shouyunchina.com:8002/DNServices/businessInfoServlet",
				method: "GET",
				data: {
					recordId: res.recordId,
					id: res.id
				},
				success: async (res) => {
					if (res && res.data) {
						let {
							data: {
								values: values
							}
						} = res;
						let info = res.data;
						info['收件人签名或盖章'] = info['收件人签名或盖章'] && await this.getimg(info['收件人签名或盖章']);
						info['送达人签名或盖章'] = info['送达人签名或盖章'] && await this.getimg(info['送达人签名或盖章']);
						info['见证人签名或盖章'] = info['见证人签名或盖章'] && await this.getimg(info['见证人签名或盖章']);
						console.log(info)
						this.fields = info;
						uni.hideLoading()
					}
				},
				fail: (err) => {
					console.log(err);
					uni.showToast({
						title: "请求失败",
						icon: "none"
					})
				}
			});
		},
		methods: {
			getimg: function(id) {
				console.log(id)
				return new Promise((resolve, reject) => {
					let name = commonInfo.userinfo.name
					api.GetNowtoken(name, (res) => {
						console.log(name)
						console.log(res)
						let url = "http://183.203.90.25:8888/seeyon/services/downloadService?token=" + res +
							"&fileId=" + id + "";
						resolve(url)
					});
				})
			},
		},
	}
</script>

<style>
	@import url("../../../static/css/CommonPunish.css");
</style>
