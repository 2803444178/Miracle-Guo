<template>
	<view>
		<view class="content">
			<form @submit="submit" v-if="fields">
				<view class="totcontent" v-show="showindex == 1">
					<view class="section">
						<view class="section__title">送达文书名称及文号：</view>
						<input class="section__input" v-model="fields['送达文书名称及文号'].value" placeholder-class="placesize" placeholder="送达文书名称及文号"></input>
					</view>
					<view class="section">
						<view class="section__title">受送达人：</view>
						<input class="section__input" v-model="fields['受送达人'].value" placeholder-class="placesize" placeholder="受送达人"></input>
					</view>
					<view class="section ">
						<view class="section__title">送达时间：</view>
						<view class="iconbox">
							<input class="section__input" @tap="toggleTab('picker','送达时间')" v-model="fields['送达时间'].value" disabled="true"
							 placeholder-class="placesize" placeholder="送达时间"></input>
							<view class="iconfont icon-riqi xiala"></view>
						</view>
					</view>
					<view class="section">
						<view class="section__title">送达地点：</view>
						<input class="section__input" v-model="fields['送达地点'].value" placeholder-class="placesize" placeholder="送达地点"></input>
					</view>
					<view class="section">
						<view class="section__title">送达方式：</view>
						<input class="section__input" v-model="fields['送达方式'].value" placeholder-class="placesize" placeholder="送达方式"></input>
					</view>
					<view class="combtn">
						<button class="btn" @tap="next(2)">下一步</button>
					</view>
				</view>
				<view class="totcontent" v-show="showindex == 2">
					<view class="section">
						<view class="section__title">收件人签名或盖章：</view>
						<view class="section_canvas" @tap="gocanvas('收件人签名或盖章')">
							<view v-if="!signImage['收件人签名或盖章']" class="iconfont icon-iconzhengli_shouxieqianpi xiala"></view>
							<image :src="signImage['收件人签名或盖章']" class="qianfa" mode="aspectFit"></image>
						</view>
					</view>
					<view class="section">
						<view class="section__title"> 签名日期：</view>
						<view class="iconbox">
							<input class="section__input" @tap="toggleTab('picker','收件人日期')" v-model="fields['收件人日期'].value" disabled="true"
							 placeholder-class="placesize" placeholder="签名日期"></input>
							<view class="iconfont icon-riqi xiala"></view>
						</view>
					</view>
					<view class="combtn">
						<button class="btn" @tap="pre(1)">上一步</button>
						<button class="btn" @tap="next(3)">下一步</button>
					</view>
				</view>
				<view class="totcontent" v-show="showindex == 3">
					<view class="section">
						<view class="section__title">送达人签名或盖章：</view>
						<view class="section_canvas" @tap="gocanvas('送达人签名或盖章')">
							<view v-if="!signImage['送达人签名或盖章']" class="iconfont icon-iconzhengli_shouxieqianpi xiala"></view>
							<image :src="signImage['送达人签名或盖章']" class="qianfa" mode="aspectFit"></image>
						</view>
					</view>
					<view class="section">
						<view class="section__title"> 签名日期：</view>
						<view class="iconbox">
							<input class="section__input" @tap="toggleTab('picker','送达人日期')" v-model="fields['送达人日期'].value" disabled="true"
							 placeholder-class="placesize" placeholder="签名日期"></input>
							<view class="iconfont icon-riqi xiala"></view>
						</view>
					</view>
					<view class="combtn">
						<button class="btn" @tap="pre(2)">上一步</button>
						<button class="btn" @tap="next(4)">下一步</button>
					</view>
				</view>
				<view class="totcontent" v-show="showindex == 4">
					<view class="section">
						<view class="section__title">见证人签名或盖章：</view>
						<view class="section_canvas" @tap="gocanvas('见证人签名或盖章')">
							<view v-if="!signImage['见证人签名或盖章']" class="iconfont icon-iconzhengli_shouxieqianpi xiala"></view>
							<image :src="signImage['见证人签名或盖章']" class="qianfa" mode="aspectFit"></image>
						</view>
					</view>
					<view class="section">
						<view class="section__title"> 签名日期：</view>
						<view class="iconbox">
							<input class="section__input" @tap="toggleTab('picker','见证人日期')" v-model="fields['见证人日期'].value" disabled="true"
							 placeholder-class="placesize" placeholder="签名日期"></input>
							<view class="iconfont icon-riqi xiala"></view>
						</view>
					</view>
					<view class="section">
						<view class="section__title">备注：</view>
						<textarea class="section__text" v-model="fields['备注'].value" placeholder="备注" placeholder-class="placesize" />
						</view>
					<view class="combtn">
						<button class="btn" @tap="pre(3)">上一步</button>
						<button class="btn" form-type="submit">提交</button>
					</view>
				</view>
			</form>
			<w-picker mode="date" :current="false" @confirm="onConfirme" :disabledAfter="false" ref="picker"></w-picker>
		</view>
	</view>
</template>

<script>
	import api from "@/api/api.js"
	import commonInfo from "@/common/common.js";
	var token;
	export default {
		data() {
			return {
				fields:null,
				timeTemp: '',
				dataL: "",
				showindex: 1,
				nowdate: '',
				currentIndex: "",
				signImage: {
					"收件人签名或盖章": "",
					"送达人签名或盖章": "",
					"见证人签名或盖章": "",
				},
				backbtn: true,

			}
		},
		onLoad: function(res) {
			//设置标题
			uni.setNavigationBarTitle({
				title: res.title
			})
			this.title = res.title;
			let key = commonInfo.userinfo.qycase.ID + '' + res.title;
			this.key = key;
			let name = commonInfo.userinfo.name;
			//获取模板
			console.log(commonInfo.userinfo.qycase)
			api.GetNowtoken(name, (Tokendata) => {
				token = Tokendata
				if (res) {
					api.getFormdata(key, res.id, name, (res, fields) => {
						console.log(fields)
						api.initFields(fields, commonInfo.userinfo.qycase, 'xzzf39');
						res.token = Tokendata;
						this.dataL = res;
						this.fields = fields;
					})
				}
			});
			var that = this;
			uni.$on('update', function(data) {
				let arrobj = that.signImage;
				let name = data.name;
				let imgurl = data[data.name];
				let token = commonInfo.userinfo.token;
				let obj = that.dataL;
				api.Getsign(obj, name, imgurl, token, function(res) {
					that.dataL = res;
				})
				for (let i in arrobj) {
					if (arrobj[data.name] == "") {
						arrobj[data.name] = data[data.name]
					}
				}
			})
		},
		onBackPress: function() {
			var that = this;
			if (this.backbtn) {
				uni.showModal({
					title: '提示',
					content: '确定保存本次编辑？',
					success: function(res) {
						if (res.confirm) {
							let key = commonInfo.userinfo.qycase.ID + '' + that.title;
							console.log(that.dataL.data.values)
							uni.setStorageSync(key, that.dataL)
							that.backbtn = false;
							uni.navigateBack()
						} else if (res.cancel) {
							console.log('用户点击取消');
							that.backbtn = true;
						}
					}
				});
				return true
			} else {
				return false
			}
		},

		methods: {
			toggleTab(str, index) {
				console.log(index)
				this.currentIndex = index;
				this.$refs[str].show();
			},
			next: function(res) {
				this.showindex = res;
			},
			pre: function(res) {
				this.showindex = res;
			},
			onConfirme(val) {
				this.fields[this.currentIndex].value = val.result;
			},
			gocanvas: function(name) {
				uni.navigateTo({
					url: "../xzzcan/xzzcan?name=" + name + ""
				})
			},
			submit: function(e) {
				/* 将案件来源登记表的信息缓存，以便于关联使用 */
				api.postFormdata(this.dataL, (res) => {
					console.log(res)
					if (res && res.code == '0') {
						uni.hideLoading();
						uni.showToast({
							title: "提交成功",
							icon: "success"
						})
						uni.removeStorage({
							key: this.key,
							success: function(res) {
								setTimeout(function() {
									uni.navigateTo({
										url: "../punsucess/punsucess"
									})
								}, 300)
							}
						});
					} else {
						uni.hideLoading();
						uni.showToast({
							title: "提交失败",
							icon: "none"
						})
					}
				}, (err) => {
					console.log(err)
					uni.showToast({
						title: "错误",
						icon: "none"
					})
				});
			}
		},
	}
</script>

<style>
	@import url("../../../static/css/CommonPunish.css");
</style>
