<template>
	<view>
		<view class="bgwarp">
			<view class="bglist"></view>
			<view class="bgbox">
				<view class="itemli" @tap="GoXie()">
					<image src="../../static/home/item1.png" mode="widthFix"></image>
					<view class="text">
						协同工作
					</view>
				</view>
				<view class="itemli" @tap="goenter()">
					<image src="../../static/home/item2.png" mode="widthFix"></image>
					<view class="text">
						知识社区
					</view>
				</view>
				<view class="itemli" @tap="goenter()">
					<image src="../../static/home/item3.png" mode="widthFix"></image>
					<view class="text">
						文化建设
					</view>
				</view>
				<view class="itemli" @tap="notice()">
					<image src="../../static/home/item4.png" mode="widthFix"></image>
					<view class="text">
						通知公告
					</view>
				</view>
				<view class="itemli" @tap="gopunish()">
					<image src="../../static/home/item5.png" mode="widthFix"></image>
					<view class="text">
						行政处罚
					</view>
				</view>
			</view>
		</view>
			
		<view class="content">
			<view class="Basics">
				<view class="common_title">
					<view class="iconfont icon-shuxian"></view>
					<view>
						基础档案
					</view>
				</view>
				<view class="Basics_img">
					<image src="../../static/home/base1.png" mode="widthFix" @tap="Swzhi()"></image>
					<image src="../../static/home/base2.png" mode="widthFix" @tap="Swji()"></image>
				</view>
			</view>
			<video src="http://60.222.222.19:83/pag/60.222.222.19/7302/001101/0/MAIN/TCP/live.m3u8" controls></video>
			
			<view class="Basics">
				<view class="common_title">
					<view class="iconfont icon-shuxian"></view>
					<view>
						企业档案
					</view>
				</view>
				<view class="commonbox coommonitem" v-if="foodinfo">
					<view class="comiterm">
						<view class="comhead">
							企业档案统计
						</view>
						<view class="comnum">
							{{foodinfo[0].number}}
						</view>
						<view class="comtype">
							餐饮企业
						</view>
						<view class="combtn" @tap="foodlist('enter','RepastService')">
							企业列表
						</view>
					</view>
					<view class="comiterm">
						<view class="comhead">
							企业档案统计
						</view>
						<view class="comnum">
							{{foodinfo[2].number}}
						</view>
						<view class="comtype">
							食品销售
						</view>
						<view class="combtn" @tap="foodlist('enter','FoodSales')">
							企业列表
						</view>
					</view>
					<view class="comiterm">
						<view class="comhead">
							企业档案统计
						</view>
						<view class="comnum">
							{{foodinfo[1].number}}
						</view>
						<view class="comtype">
							食品生产
						</view>
						<view class="combtn" @tap="foodlist('enter','FoodProduction')">
							企业列表
						</view>
					</view>
				</view>
			</view>
			<view class="Basics">
				<view class="common_title">
					<view class="iconfont icon-shuxian"></view>
					<view>
						统计分析
					</view>
				</view>
				<view class="Canvasbox">
					<view class="Canvas">
						<view class="top-warp">
							<app-tabs v-model="tabIndex" :tabs="tabs" @change="tabChange"></app-tabs>
						</view>
						<view class="canvasbox" v-show="tabIndex == 0 ">
							<view class="qiun-charts">
								<canvas canvas-id="canvasColumnA" id="canvasColumnA" class="charts" @touchstart="touchColumn"></canvas>
							</view>
						</view>
						<view class="canvasbox" v-show="tabIndex == 1 ">
							<view class="qiun-charts">
								<canvas canvas-id="canvasPiea" id="canvasPiea" class="charts" @touchstart="touchPie"></canvas>
							</view>
							<view class="qiun-charts">
								<canvas canvas-id="canvasColumnC" id="canvasColumnC" class="charts" @touchstart="touchColumn"></canvas>
							</view>
						</view>
						<view class="canvasbox" v-show="tabIndex == 2 ">
							<view class="qiun-charts">
								<canvas canvas-id="canvasPie" id="canvasPie" class="charts" @touchstart="touchPie"></canvas>
							</view>
						</view>
						<view class="canvasbox" v-show="tabIndex == 3 ">

							<view class="qiun-charts">
								<canvas canvas-id="canvasPieb" id="canvasPieb" class="charts" @touchstart="touchPie"></canvas>
							</view>
						</view>
					</view>
				</view>
			</view>
		</view>
	</view>
</template>

<script>
	import AppTabs from "@/component/other/index-app.vue";
	import url from "@/common/common.js"
	import api from "@/api/api.js";
	import uCharts from '@/js_sdk/u-charts/u-charts/u-charts.min.js';
	var _self;
	var canvaColumn = null;
	var canvaPie = null;
	export default {
		components: {
			AppTabs
		},
		data() {
			return {
				cWidth: '',
				cHeight: '',
				pixelRatio: 1,
				serverData: '',
				tabs: ['企业档案', '日常监管', '集体聚餐', '行政处罚'],
				tabIndex: 0, // 当前tab下标
				foodinfo: null, //企业档案
				ColumnA: null,
				ColumnB: null,
				ColumnC: null,
				ColumnD: null,
				ColumnE: null,
			}
		},
		onLoad(res) {
			_self = this;
			//#ifdef MP-ALIPAY
			uni.getSystemInfo({
				success: function(res) {
					if (res.pixelRatio > 1) {
						//正常这里给2就行，如果pixelRatio=3性能会降低一点
						//_self.pixelRatio =res.pixelRatio;
						_self.pixelRatio = 2;
					}
				}
			});
			//#endif
			this.cWidth = uni.upx2px(600);
			this.cHeight = uni.upx2px(400);
			try {
				const value = uni.getStorageSync('setUserData');
				if (value) {
					//获取用户名 username 例如:刘爱生
					let name = value.username;
					url.userinfo.name = name;
					let tokenurl = api.apiUrl + '/token';
					let dataobj = {
						loginName: name
					}
					let tokentype = 'POST'
					api.getToken(tokenurl, dataobj, tokentype, (res) => {
						this.token = res.id
						url.userinfo.token = res.id
					});
					//获取用户信息
					let userurl = api.apiUrle + '/getOrgMemberServlet';
					let dataobjj = {
						loginName: name
					}
					let userype = 'GET'
					api.getToken(userurl, dataobjj, userype, (res) => {
						url.userinfo.info = res;
						/* 	
							统计分类
							参数 type（EntInfo企业档案、CheckNumber检查次数、CheckResult检查结果、DinnerResult集体聚餐申报事由、DinnerNumber聚餐人数、行政处罚AdminPunish）
							levelID 区域ID （type为AdminPunish 不需要传入区域ID）
						 */
						let levelID = res.levelId;
						api.indexStatistics('EntInfo', levelID, (res) => {
							this.foodinfo = res;
							let ColumnA = {
								"categories": ["餐饮企业", "食品销售", "食品生产"],
								"series": [{
									"name": "企业档案类型统计",
									"data": [res[0].number, res[2].number, res[1].number]
								}]
							}
							this.showColumn("canvasColumnA", ColumnA);
							this.ColumnA = ColumnA;
						});
						//日常价监管检查次数
						api.indexStatistics('CheckNumber', levelID, (res) => {
							let ColumnB = {
								"series": [{
									"name": "餐饮企业",
									"data": res[0].number
								}, {
									"name": "食品销售",
									"data": res[1].number
								}]
							}
							this.ColumnB = ColumnB;
						});

						api.indexStatistics('CheckResult', levelID, (res) => {
							let ColumnC = {
								"categories": ["基本符合", "不符合", "符合"],
								"series": [{
									"name": "日常监管结果统计",
									"data": [res[0].number, res[2].number, res[1].number]
								}]
							}

							this.ColumnC = ColumnC;
						});

						api.indexStatistics('DinnerResult', levelID, (res) => {
							let ColumnD = {
								"series": [{
										"name": "结婚",
										"data": res[0].number
									}, {
										"name": "新建房",
										"data": res[1].number
									}, {
										"name": "丧事",
										"data": res[2].number
									},
									{
										"name": "其他",
										"data": res[3].number
									}
								]
							}
							this.ColumnD = ColumnD;
						});
						api.indexStatistics('AdminPunish', '', (res) => {
							console.log(res)
							let ColumnE = {
								"series": [{
									"name": "昕水市场监管所",
									"data": res[0].number
								}]
							}
							this.ColumnE = ColumnE;
						});


					});
				}
			} catch (e) {
				// error
			}

		},
		methods: {
			tabChange: function(res) {
				this.tabIndex = res;
				if (res == 0) {
					this.showColumn("canvasColumnA", this.ColumnA);
				} else if (res == 1) {
					this.showPie("canvasPiea", this.ColumnB);
					this.showColumn("canvasColumnC", this.ColumnC);
				} else if (res == 2) {
					this.showPie("canvasPie", this.ColumnD);
				} else {
					this.showPie("canvasPieb", this.ColumnE);
				}
			},
			GoXie: function(id) {
				uni.navigateTo({
					url: "../Coor/Coor"
				})
			},
			foodlist: function(colum, type) {
				let dataobjj = {
					entType: type,
				}
				uni.navigateTo({
					url: "../Enterprise/Filesearch/Fileresult/Fileresult?colum=" + colum + "&obj=" + JSON.stringify(
						dataobjj) + ""
				})
			},
			Swji: function(id) {
				uni.switchTab({
					url: "../collective/collective"
				})
			},
			Swzhi: function(id) {
				uni.switchTab({
					url: "../daily/daily"
				})
			},
			goenter: function() {
				uni.showToast({
					title: '暂未开放',
					icon: "none"
				})
			},
			gopunish: function() {
				uni.navigateTo({
					url: "../punish/qylist/qylist?colum=punlish"
				})
			},

			notice: function() {
				uni.navigateTo({
					url: "../news/news"
				})
			},
			showColumn(canvasId, chartData) {
				canvaColumn = new uCharts({
					$this: _self,
					canvasId: canvasId,
					type: 'column',
					legend: true,
					fontSize: 11,
					background: '#f0f2fe',
					pixelRatio: _self.pixelRatio,
					animation: true,
					categories: chartData.categories,
					series: chartData.series,
					xAxis: {
						disableGrid: true,
					},
					yAxis: {},
					dataLabel: true,
					width: _self.cWidth * _self.pixelRatio,
					height: _self.cHeight * _self.pixelRatio,
					extra: {
						column: {
							width: _self.cWidth * _self.pixelRatio * 0.45 / chartData.categories.length
						}
					}
				});
			},
			showPie(canvasId, chartData) {
				canvaPie = new uCharts({
					$this: _self,
					canvasId: canvasId,
					type: 'pie',
					fontSize: 11,
					legend: {
						show: true
					},
					background: '#FFFFFF',
					pixelRatio: _self.pixelRatio,
					series: chartData.series,
					animation: true,
					width: _self.cWidth * _self.pixelRatio,
					height: _self.cHeight * _self.pixelRatio,
					dataLabel: true,
					extra: {
						pie: {
							lableWidth: 15
						}
					},
				});
			},
			touchPie(e) {
				canvaPie.showToolTip(e, {
					format: function(item) {
						return item.name + ':' + item.data
					}
				});
			},

			touchColumn(e) {
				canvaColumn.showToolTip(e, {
					format: function(item, category) {
						if (typeof item.data === 'object') {
							return category + ' ' + item.name + ':' + item.data.value
						} else {
							return category + ' ' + item.name + ':' + item.data
						}
					}
				});
			},
			changeData() {
				canvaColumn.updateData({
					series: _self.serverData.ColumnB.series,
					categories: _self.serverData.ColumnB.categories
				});
			}
		}
	}
</script>

<style>
	@import url("../../static/icon/iconfont.css");

	.bglist {
		background: #4b559d;
		width: 100%;
		height: 200upx;
	}

	.bgbox {
		width: 700upx;
		height: 180upx;
		background: #fff;
		border-radius: 25upx;
		margin: 0 auto;
		margin-top: -110upx;
		display: flex;
		align-items: center;
		box-shadow: 0px 0px 5px #888888;
		padding: 0 20upx;
	}

	.bgbox .itemli {
		width: 20%;
		font-size: 24upx;
		display: flex;
		flex-direction: column;
		justify-content: center;
		align-items: center;
	}

	.bgbox .itemli image {
		display: block;
		width: 80upx;
		margin-bottom: 10upx;
	}

	.bgbox .itemli .text {
		color: #333;
	}

	.content {
		margin-top: 20upx;
	}

	.commonbox {
		background: #fff;
		margin-top: 20upx;
	}

	.common_title {
		font-size: 30upx;
		display: flex;
		align-items: center;
		color: #333333;
		margin: 20upx 0;
		letter-spacing: 2upx;
		width: 100%;
		height: 40upx;
		font-weight: 600;
	}

	.common_title .iconfont {
		font-size: 36upx;
	}

	.Basics_img {
		display: flex;
		justify-content: space-between;
		padding: 0 20upx;

	}

	.Canvasbox {
		padding: 20upx;
	}

	.Canvas {
		width: 100%;
		background: #f0f2fe;
		padding: 40upx 20upx 0;
	}

	.top-warp {
		padding-bottom: 40upx;
	}

	.Basics_img image {
		width: 300upx
	}

	.commonti {
		font-size: 30upx;
		font-weight: 600;
		color: #333333;
		text-align: center;
	}

	.coommonitem {
		white-space: nowrap;
		width: 100%;
		padding: 20upx;
		margin: 0 auto;
		display: flex;
		justify-content: space-between;
	}

	.comiterm {
		font-size: 26upx;
		width: 32%;
		margin-right: 20upx;
		border: 1px solid #4b559d;
		text-align: center;
		display: inline-block;
		padding: 30upx 15upx;
	}

	.comhead {
		font-size: 30upx;
		margin-bottom: 15upx;
	}

	.comnum {
		font-weight: 600;
		color: #4b559d;
		font-size: 32upx;
		margin-bottom: 15upx;
	}

	.comtype {
		font-weight: 600;
		color: #333;
		font-size: 32upx;
		margin-bottom: 15upx;
	}

	.combtn {
		width: 80%;
		margin: 0 auto;
		padding: 8upx 10upx;
		background: #4b559d;
		font-size: 24upx;
		color: #fff;
	}

	.qiun-padding {
		padding: 2%;
		width: 96%;
	}

	.qiun-wrap {
		display: flex;
		flex-wrap: wrap;
	}

	.qiun-rows {
		display: flex;
		flex-direction: row !important;
	}

	.qiun-columns {
		display: flex;
		flex-direction: column !important;
		position: relative;
	}

	.qiun-common-mt {
		margin-top: 10upx;
	}

	.qiun-bg-white {
		background: #FFFFFF;
	}

	.qiun-title-bar {
		width: 96%;
		padding: 10upx 2%;
		flex-wrap: nowrap;
	}

	.qiun-title-dot-light {
		border-left: 10upx solid #0ea391;
		padding-left: 10upx;
		font-size: 32upx;
		color: #000000
	}

	.qiun-charts {
		width: 100%;
		height: 400upx;
		position: relative;
	}

	.charts {
		width: 100%;
		height: 450upx;
	}

	.tongji {
		font-size: 50upx;
		color: #007AFF;
		position: absolute;
		right: 60upx;
		font-weight: 600;
		top: 150upx;
	}

	.tongji text {
		font-size: 40upx;
		color: #333333;
		margin-left: 40upx;
	}

	.canvasbox {
		width: 600upx;
		margin: 0 auto;
	}
</style>
