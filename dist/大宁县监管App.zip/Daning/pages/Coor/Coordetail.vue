<template>
	<view>
		<!-- 菜单 -->
		<view class="top-warp">
			<app-tabs v-model="tabIndex" :tabs="tabs" @change="tabChange"></app-tabs>
		</view>
		<!-- 如果每个子组件布局不一样, 可拆开写 (注意ref不可重复) : -->
		<mescroll-item ref="mescrollItem0" :i="0" :index="tabIndex"></mescroll-item>
		<mescroll-item ref="mescrollItem1" :i="1" :index="tabIndex"></mescroll-item>
	</view>
</template>

<script>
	import MescrollItem from "./Cooritem.vue";
	import MescrollMoreMixin from "@/component/mescroll-uni/mixins/mescroll-more.js";
	import AppTabs from "@/component/other/app-tabs.vue";

	export default {
		mixins: [MescrollMoreMixin], // 多个mescroll-body写在子组件时, 则使用mescroll-more.js补充子组件的页面生命周期
		components: {
			MescrollItem,
			AppTabs
		},
		data() {
			return {
				tabs: ['事项明细', '事项流程'],
				tabIndex: 0 // 当前tab下标
			}
		},
		methods: {
			emptyClick() {
				uni.showToast({
					title: '点击了按钮,具体逻辑自行实现'
				})
			},
			// 切换菜单
			tabChange() {
				console.log(333)
				this.goods = [] // 先置空列表,显示加载进度
				// this.mescroll.resetUpScroll() // 再刷新列表数据
			}
		}
	}
</script>

<style>
	.top-warp {
		z-index: 9990;
		position: fixed;
		/* css变量 */
		left: 0;
		width: 100%;
		background-color: white;
	}

	.top-warp .tip {
		font-size: 28upx;
		height: 60upx;
		line-height: 60upx;
		text-align: center;
	}
</style>
