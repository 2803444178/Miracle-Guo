const apiUrle = "http://h5.shouyunchina.com:8002/DNServices";
const apiUrl = "http://183.203.90.25:8002/v1/seeyon";
const apiUrl2 = "http://183.203.90.25:8001/daning";
// 用户登录的信息保存
const userinfo = {
	/* 企业信息 */
	qycase:'',
	qyinfo: "",
	token: "",
	info: "",
	adrssinfo: {

	},
	name: '',
	daily: '',
	salely: '',
	dailytype: "",
	faperson: false,
	zhiperson: false,
	total: {
		totalarr: [],
		arr: [],
		arrpro: [],
		pro: [],
		propro: [],
	},
}




export default {
	apiUrl,
	apiUrle,
	apiUrl2,
	userinfo
}
