<script>
	import url from "common/common.js"
	export default {
		onLaunch: function() {
			// #ifdef APP-PLUS
			// plus.runtime.getProperty(plus.runtime.appid, function(widgetInfo) {
			// 	var keversion = widgetInfo.version
			// 	uni.request({ 
			// 		url: 'http://60.222.220.223:30006/Test/upid',
			// 		success: (result)	 => {
			// 			var data = result.data.data;
			// 			var version = data.UpID;
			// 			if (keversion < verxsion) {
			// 				uni.showModal({
			// 					title: '更新提示',
			// 					content: '检测有新的版本，是否现在更新？',
			// 					success: function(res) {
			// 						if (res.confirm) {
			// 							uni.showLoading({
			// 								title: "下载中",
			// 								icon: "none"
			// 							})
			// 							uni.downloadFile({
			// 								url: data.UpURL,	
			// 								success: (downloadResult) => {
			// 									if (downloadResult.statusCode === 200) {
			// 										plus.runtime.install(downloadResult.tempFilePath, {
			// 											force: false
			// 										}, function() {
			// 											uni.showToast({
			// 												title: '下载成功',
			// 												duration: 2000,
			// 									  			icon: "none"
			// 											});
			// 											setTimeout(function() {
			// 												plus.runtime.restart();
			// 											}, 3000);
			// 										}, function(e) {
			// 											uni.showToast({
			// 												title: '下载失败',
			// 												duration: 2000,
			// 												icon: "none",
			// 											});
			// 										});
			// 									}
			// 								},
			// 								fail: function() {
			// 									uni.showToast({
			// 										title: '下载失败',
			// 										duration: 2000,
			// 										icon: "none",
			// 									});
			// 								}
			// 							});
			// 						} else if (res.cancel) {
			// 							console.log('用户点击取消');
			// 						}
			// 					}
			// 				});
			// 			}
			// 		}
			// 	});
			// });
			// #endif
		},
		onShow: function() {
			console.log('App Show')
			uni.getLocation({
				type: 'gcj02 ',
				success: function(res) {
					console.log(res)
					var point = new plus.maps.Point(res.longitude, res.latitude);
					plus.maps.Map.reverseGeocode(
						point, {},
						function(event) {
							var address = event.address; // 转换后的地理位置
							var point = event.coord; // 转换后的坐标信息
							var coordType = event.coordType; // 转换后的坐标系类型
							const proExp = ".+[省]",
								cityExp = ".+[市]",
								disExp = ".+[区]",
								strExp = ".+[街]";
							const province = address.match(new RegExp(proExp))[0]; // 省
							const city = address.match(new RegExp(cityExp))[0].replace(province, ""); // 市
							const district = address.match(new RegExp(disExp))[0].replace(province, "").replace(city, ""); // 区
							const stee = address.match(new RegExp(strExp))[0].replace(province, "").replace(city, "").replace(district,
								""); // 区

							url.userinfo.adrssinfo.longitude = res.longitude;
							url.userinfo.adrssinfo.latitude = res.latitude;
							url.userinfo.adrssinfo.address = address;
							url.userinfo.adrssinfo.country = "中国";
							url.userinfo.adrssinfo.province = province;
							url.userinfo.adrssinfo.city = city;
							url.userinfo.adrssinfo.town = district;
							url.userinfo.adrssinfo.street = stee;
						},
					);
				}
			});
		},
		onHide: function() {
			console.log('App Hide')
		}
	}
</script>

<style>
	@import url("./static/icon/iconfont.css");

	/*每个页面公共css */
	page {
		box-sizing: border-box;
	}

	view {
		box-sizing: border-box;
	}

	.content {
		padding: 20upx;
		background: #fff;
	}

	.headbox {
		width: 100%;
		height: 44px;
		padding: 20upx;
		display: -webkit-box;
		display: -webkit-flex;
		display: flex;
		overflow: hidden;
		justify-content: space-between;
		box-sizing: border-box;
		z-index: 998;
		transition-property: all;
		background: #FFFFFF;
		font-weight: 600;
		font-size: 18px;
	}
</style>
