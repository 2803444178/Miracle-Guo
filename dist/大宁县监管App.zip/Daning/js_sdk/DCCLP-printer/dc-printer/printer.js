/**
 * 打印本地图片和pdf文件。
 * @param {String}url 需要打印的文件的路径.
 * @param {int} type  配置打印信息的输出类型,为0,1,2
 */
function printInteraction(url,type) {
	try {
		var os = plus.os.name;
		if ('iOS' == os) {
			var UIPrintInteractionController = plus.ios.import('UIPrintInteractionController');
			var UIPrintInfo = plus.ios.import("UIPrintInfo");  
			var NSURL = plus.ios.import("NSURL");  
			
			var urlpath = NSURL.fileURLWithPath(plus.io.convertLocalFileSystemURL(url));  
			if ( UIPrintInteractionController.canPrintURL(urlpath) ){  
			    var printInfo = UIPrintInfo.printInfo();  
			    printInfo.setJobName("");  
			    printInfo.setOutputType(type);  
				// printInfo.setOrientation(0);
			    var printInteractionController = UIPrintInteractionController.sharedPrintController()  
			    printInteractionController.setPrintInfo(printInfo);  
			    printInteractionController.setShowsNumberOfCopies(false);  
			    printInteractionController.setPrintingItem(urlpath);  
			    printInteractionController.presentAnimatedcompletionHandler(true, null);  
			} else {  
				console.log("not support");
			}
		} else {

		}
	} catch (e) {
		console.error('error @printInteraction!!');
	}
}


module.exports = {
	printInteraction: printInteraction
}
