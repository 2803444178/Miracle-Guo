<script>
	import Vue from 'vue'
	export default {
		onLaunch: function() {
			// #ifdef APP-PLUS
			plus.screen.lockOrientation('landscape-primary'); //锁定
			plus.runtime.getProperty(plus.runtime.appid, function(widgetInfo) {
				var keversion = widgetInfo.version
				console.log(keversion)
			});
			// #endif
		},
		onShow: function() {
			console.log('App 开启');
		},
		onHide: function() {
			console.log('App 关闭')
		}
	}
</script>

<style>

</style>
