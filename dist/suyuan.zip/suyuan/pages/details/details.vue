<template>
	<view>
		<view>
			<view class="header school" v-if="backtype == 'school'">
				<view class="headtitle">
					<view>
						创建国家食品安全示范城市
					</view>
					<view>
						食品溯源展示
					</view>
				</view>
				<view class="tabitem">

				</view>
				<view class="leftbox">
					<view class="left">
						<image :src="'../../static/images/weather/'+ weather.wea_img+'.png'" mode="widthFix"></image>
					</view>
					<view class="right">
						<view class="b1">{{timeTemp|timeFormat}}</view>
						<view class="b2">{{weather.wea}} {{weather.tem}} ℃</view>
					</view>
				</view>
			</view>
			<view class="header food" v-else-if="backtype == 'food'">
				<view class="headtitle">
					<view>
						创建国家食品安全示范城市
					</view>
					<view>
						食品溯源展示
					</view>
				</view>
				<view class="tabitem">

				</view>
				<view class="leftbox">
					<view class="left">
						<image :src="'../../static/images/weather/'+ weather.wea_img+'.png'" mode="widthFix"></image>
					</view>
					<view class="right">
						<view class="b1">{{timeTemp|timeFormat}}</view>
						<view class="b2">{{weather.wea}} {{weather.tem}} ℃</view>
					</view>
				</view>
			</view>
			<view class="header nong" v-else-if="backtype == 'nong'">
				<view class="headtitle">
					<view>
						创建国家食品安全示范城市
					</view>
					<view>
						食品溯源展示
					</view>
				</view>
				<view class="tabitem">

				</view>
				<view class="leftbox">
					<view class="left">
						<image :src="'../../static/images/weather/'+ weather.wea_img+'.png'" mode="widthFix"></image>
					</view>
					<view class="right">
						<view class="b1">{{timeTemp|timeFormat}}</view>
						<view class="b2">{{weather.wea}} {{weather.tem}} ℃</view>
					</view>
				</view>
			</view>
			<view class="container school" v-if="backtype == 'school'" :data-type='backtype'>
				<view class="foodbox">
					<image class="back" @tap="back()" src="../../static/goBack.png" mode=""></image>
					<view class="home_title">
						<image class="line" src="../../static/line.png" mode="aspectFill"></image>
						检测信息
					</view>
					<view class="jianbox">
						<view class="imgname">
							<image :src="detectlist.product_icon" mode=""></image>
						</view>
						<view class="imgcontent">
							<view class="imgitem">
								<text>·检测类型：</text>
								有机磷与氨基甲酸酯
							</view>
							<view v-if="detectlist.cate_name == '蔬菜类' || detectlist.cate_name == '水果类' " class="imgitem">
								·检测结果：
								<text v-if=" detectlist.detect_result == null">未检测</text>
								<text v-else>{{detectlist.detect_result == "QUA"? '合格':"不合格" }}</text>
							</view>
							<view v-else class="imgitem" style="justify-content: flex-start; display: flex;">
								·检测报告：
								<view class="bb" v-if='detectlist.product_cert == "" '>无检测报告</view>
								<view v-else class="bb">
									<button class="bbe" style="background: #0096d5;" @tap="togglePopup('center', 'share',indexe)" type="primary">点击查看</button>
								</view>
							</view>
							<view class="imgitem">
								<text>·检测项目：</text>
								农残
							</view>
							<view class="imgitem">
								<text>·检测时间：</text>
								{{detectlist.detect_time === null  ? '暂无':detectlist.detect_time}}
							</view>
							<view class="imgitem">
								<text>·标准值：</text>
								{{detectlist.detect_standard_value === null  ? '50':detectlist.detect_standard_value }}%
							</view>
							<view class="imgitem">
								<text>·检测人：</text>
								{{detectlist.detect_person === null  ? '暂无':detectlist.detect_person }}
							</view>

							<view class="imgitem">
								<text>·实测值：</text>
								{{detectlist.detect_real_value === null  ? '未检测':detectlist.detect_real_value + '%' }}
							</view>
							<view class="imgitem">
								<text>·检测单位：</text>
								{{detectlist.buyer_name}}
							</view>
						</view>
						<view v-if=" detectlist.cate_name == '蔬菜类' || detectlist.cate_name == '水果类' ">
							<image v-if=" detectlist.detect_result == null" class="qua" src="../../static/unce.png" mode=""></image>
							<image v-else class="qua" :src=" detectlist.detect_result == 'QUA'?  '../../static/QUA.png':'../../static/UNQUA.png' "
							 mode=""></image>
						</view>
						<view v-else>
							<image class="qua" :src='detectlist.product_cert == "" ?  "../../static/njian.png":"../../static/ujian.png"'
							 mode=""></image>
						</view>
					</view>
					<view class="home_title">
						<image class="line" src="../../static/line.png" mode="aspectFill"></image>
						溯源信息
					</view>
					<view class=" jianbottom" style="background: #fff;">
						<swiper autoplay="true" circular="true" :current="tabIndex" class="swiper-box" style="flex: 1;" :duration="300"
						 @change="ontabchange">
							<swiper-item class="swiper-item">
								<view class="jianontent">
									<view class="imgitem">
										<text>供货商类型：</text>
										农户
									</view>
									<view class="imgitem">
										<text>负责人：</text>
										{{sourcelist.source_contact}}
									</view>
									<view class="imgitem">
										<text>供货商名称：</text>
										{{sourcelist.source_name}}
									</view>
									<view class="imgitem">
										<text>联系方式：</text>{{sourcelist.source_tel}}
									</view>
									<view class="imgitem">
										<text>供货商地址：</text>
										{{sourcelist.source_address}}
									</view>
									<view class="imgitem" style="justify-content: flex-start; display: flex;">
										<text>商家资质：</text>
										<button class="bbe" style="background: #0096d5;" @tap="togglePopup('center', 'source',indexe)" type="primary">点击查看</button>
									</view>
								</view>
							</swiper-item>
							<swiper-item class="swiper-item">
								<view class="jianontent">
									<view class="imgitem">
										<text>配送商类型：</text>
										农户
									</view>
									<view class="imgitem">
										<text>负责人：</text>
										{{distributor.distributor_legal_person}}
									</view>
									<view class="imgitem">
										<text>配送商名称：</text>
										{{distributor.distributor_name}}
									</view>
									<view class="imgitem">
										<text>联系方式：</text>{{distributor.distributor_tel}}
									</view>
									<view class="imgitem">
										<text>配送商地址：</text>
										{{distributor.distributor_address}}
									</view>
									<view class="imgitem" style="justify-content: flex-start; display: flex;">
										<text>商家资质：</text>
										<button class="bbe" style="background: #0096d5;" @tap="togglePopup('center', 'distributor',indexe)" type="primary">点击查看</button>
									</view>
								</view>
							</swiper-item>
							<swiper-item class="swiper-item">
								<view class="jianontent">
									<view class="imgitem">
										<text>采购商类型：</text>
										农户
									</view>
									<view class="imgitem">
										<text>负责人：</text>
										{{buyerlist.buyer_legal_person}}
									</view>
									<view class="imgitem">
										<text>采购商名称：</text>
										{{buyerlist.buyer_name}}
									</view>
									<view class="imgitem">
										<text>联系方式：</text>{{buyerlist.buyer_tel}}
									</view>
									<view class="imgitem">
										<text>采购商地址：</text>
										{{buyerlist.buyer_address}}
									</view>
									<view class="imgitem" style="justify-content: flex-start; display: flex;">
										<text>商家资质：</text>
										<button class="bbe" style="background: #0096d5;" @tap="togglePopup('center', 'buyer',indexe)" type="primary">点击查看</button>
									</view>
								</view>
							</swiper-item>
						</swiper>
					</view>
					<scroll-view id="tab-bar" class="scroll-h" :scroll-x="true" :show-scrollbar="false" :scroll-into-view="scrollInto">
						<view class="tabberbox">
							<view class="swib">
								<view v-for="(item,index) in tabBars" class="bgitem" v-if="index < 1" :class="tabIndex == index ? 'bgitemac' + index  : 'bgitem'+index"
								 :key="index" :data-current="index" @click="ontabtap">
									<image :src=" tabIndex == index ? item.acsrc : item.src " mode=""></image>
									<view class="bgp">
										{{item.name}}
									</view>
								</view>
								<view v-for="(item,index) in tabBars" v-if="index>0" class="bgitem leftp" :class="tabIndex == index ? 'bgitemac' + index  : 'bgitem'+index"
								 :key="index" :data-current="index" @click="ontabtap">
									<image :src=" tabIndex == index ? item.acsrc : item.src " mode=""></image>
									<view class="bgp">
										{{item.name}}
									</view>
								</view>
							</view>
						</view>
					</scroll-view>
				</view>
			</view>
			<view class="container food" v-if="backtype == 'food'" :data-type='backtype'>
				<view class="foodbox">
					<image class="back" @tap="back()" src="../../static/goBack.png" mode=""></image>
					<view class="home_title">
						<image class="line" src="../../static/line.png" mode="aspectFill"></image>
						检测信息
					</view>
					<view class="jianbox">
						<view class="imgname">
							<image :src="detectlist.product_icon" mode=""></image>
						</view>
						<view class="imgcontent">
							<view class="imgitem">
								<text>·检测类型：</text>
								有机磷与氨基甲酸酯
							</view>
							<view v-if="detectlist.cate_name == '蔬菜类' || detectlist.cate_name == '水果类' " class="imgitem">
								·检测结果：
								<text v-if=" detectlist.detect_result == null">未检测</text>
								<text v-else>{{detectlist.detect_result == "QUA"? '合格':"不合格" }}</text>
							</view>
							<view v-else class="imgitem" style="justify-content: flex-start; display: flex;">
								·检测报告：
								<view class="bb" v-if='detectlist.product_cert == "" '>无检测报告</view>
								<view v-else class="bb">
									<button class="bbe" style="background: #0096d5;" @tap="togglePopup('center', 'share',indexe)" type="primary">点击查看</button>
								</view>
							</view>
							<view class="imgitem">
								<text>·检测项目：</text>
								农残
							</view>
							<view class="imgitem">
								<text>·检测时间：</text>
								{{detectlist.detect_time === null  ? '暂无':detectlist.detect_time}}
							</view>
							<view class="imgitem">
								<text>·标准值：</text>
								{{detectlist.detect_standard_value === null  ? '50':detectlist.detect_standard_value }}%
							</view>
							<view class="imgitem">
								<text>·检测人：</text>
								{{detectlist.detect_person === null  ? '暂无':detectlist.detect_person }}
							</view>

							<view class="imgitem">
								<text>·实测值：</text>
								{{detectlist.detect_real_value === null  ? '未检测':detectlist.detect_real_value + '%' }}
							</view>
							<view class="imgitem">
								<text>·检测单位：</text>
								{{detectlist.buyer_name}}
							</view>
						</view>
						<view v-if=" detectlist.cate_name == '蔬菜类' || detectlist.cate_name == '水果类' ">
							<image v-if=" detectlist.detect_result == null" class="qua" src="../../static/unce.png" mode=""></image>
							<image v-else class="qua" :src=" detectlist.detect_result == 'QUA'?  '../../static/QUA.png':'../../static/UNQUA.png' "
							 mode=""></image>
						</view>
						<view v-else>
							<image class="qua" :src='detectlist.product_cert == "" ?  "../../static/njian.png":"../../static/ujian.png"'
							 mode=""></image>
						</view>
					</view>
					<view class="home_title">
						<image class="line" src="../../static/line.png" mode="aspectFill"></image>
						溯源信息
					</view>
					<view class=" jianbottom" style="background: #fff;">
						<swiper autoplay="true" circular="true" :current="tabIndex" class="swiper-box" style="flex: 1;" :duration="300"
						 @change="ontabchange">
							<swiper-item class="swiper-item">
								<view class="jianontent">
									<view class="imgitem">
										<text>供货商类型：</text>
										农户
									</view>
									<view class="imgitem">
										<text>负责人：</text>
										{{sourcelist.source_contact}}
									</view>
									<view class="imgitem">
										<text>供货商名称：</text>
										{{sourcelist.source_name}}
									</view>
									<view class="imgitem">
										<text>联系方式：</text>{{sourcelist.source_tel}}
									</view>
									<view class="imgitem">
										<text>供货商地址：</text>
										{{sourcelist.source_address}}
									</view>
									<view class="imgitem" style="justify-content: flex-start; display: flex;">
										<text>商家资质：</text>
										<button class="bbe" style="background: #0096d5;" @tap="togglePopup('center', 'source',indexe)" type="primary">点击查看</button>
									</view>
								</view>
							</swiper-item>
							<swiper-item class="swiper-item">
								<view class="jianontent">
									<view class="imgitem">
										<text>配送商类型：</text>
										农户
									</view>
									<view class="imgitem">
										<text>负责人：</text>
										{{distributor.distributor_legal_person}}
									</view>
									<view class="imgitem">
										<text>配送商名称：</text>
										{{distributor.distributor_name}}
									</view>
									<view class="imgitem">
										<text>联系方式：</text>{{distributor.distributor_tel}}
									</view>
									<view class="imgitem">
										<text>配送商地址：</text>
										{{distributor.distributor_address}}
									</view>
									<view class="imgitem" style="justify-content: flex-start; display: flex;">
										<text>商家资质：</text>
										<button class="bbe" style="background: #0096d5;" @tap="togglePopup('center', 'distributor',indexe)" type="primary">点击查看</button>
									</view>
								</view>
							</swiper-item>
							<swiper-item class="swiper-item">
								<view class="jianontent">
									<view class="imgitem">
										<text>采购商类型：</text>
										农户
									</view>
									<view class="imgitem">
										<text>负责人：</text>
										{{buyerlist.buyer_legal_person}}
									</view>
									<view class="imgitem">
										<text>采购商名称：</text>
										{{buyerlist.buyer_name}}
									</view>
									<view class="imgitem">
										<text>联系方式：</text>{{buyerlist.buyer_tel}}
									</view>
									<view class="imgitem">
										<text>采购商地址：</text>
										{{buyerlist.buyer_address}}
									</view>
									<view class="imgitem" style="justify-content: flex-start; display: flex;">
										<text>商家资质：</text>
										<button class="bbe" style="background: #0096d5;" @tap="togglePopup('center', 'buyer',indexe)" type="primary">点击查看</button>
									</view>
								</view>
							</swiper-item>
						</swiper>
					</view>
					<scroll-view id="tab-bar" class="scroll-h" :scroll-x="true" :show-scrollbar="false" :scroll-into-view="scrollInto">
						<view class="tabberbox">
							<view class="swib">
								<view v-for="(item,index) in tabBars" class="bgitem" v-if="index < 1" :class="tabIndex == index ? 'bgitemac' + index  : 'bgitem'+index"
								 :key="index" :data-current="index" @click="ontabtap">
									<image :src=" tabIndex == index ? item.acsrc : item.src " mode=""></image>
									<view class="bgp">
										{{item.name}}
									</view>
								</view>
								<view v-for="(item,index) in tabBars" v-if="index>0" class="bgitem leftp" :class="tabIndex == index ? 'bgitemac' + index  : 'bgitem'+index"
								 :key="index" :data-current="index" @click="ontabtap">
									<image :src=" tabIndex == index ? item.acsrc : item.src " mode=""></image>
									<view class="bgp">
										{{item.name}}
									</view>
								</view>
							</view>
						</view>
					</scroll-view>
				</view>
			</view>
			<view class="container nong" v-else-if="backtype == 'nong'" :data-type='backtype'>
				<view class="foodbox">
					<image class="back" @tap="back()" src="../../static/goBack.png" mode=""></image>
					<view class="home_title">
						<image class="line" src="../../static/line.png" mode="aspectFill"></image>
						检测信息
					</view>
					<view class="jianbox">
						<view class="imgname">
							<image :src="detectlist.product_icon" mode=""></image>
						</view>
						<view class="imgcontent">
							<view class="imgitem">
								<text>·检测类型：</text>
								有机磷与氨基甲酸酯
							</view>
							<view v-if="detectlist.cate_name == '蔬菜类' || detectlist.cate_name == '水果类' " class="imgitem">
								·检测结果：
								<text v-if=" detectlist.detect_result == null">未检测</text>
								<text v-else>{{detectlist.detect_result == "QUA"? '合格':"不合格" }}</text>
							</view>
							<view v-else class="imgitem" style="justify-content: flex-start; display: flex;">
								·检测报告：
								<view class="bb" v-if='detectlist.product_cert == "" '>无检测报告</view>
								<view v-else class="bb">
									<button class="bbe" style="background: #0096d5;" @tap="togglePopup('center', 'share',indexe)" type="primary">点击查看</button>
								</view>
							</view>
							<view class="imgitem">
								<text>·检测项目：</text>
								农残
							</view>
							<view class="imgitem">
								<text>·检测时间：</text>
								{{detectlist.detect_time === null  ? '暂无':detectlist.detect_time}}
							</view>
							<view class="imgitem">
								<text>·标准值：</text>
								{{detectlist.detect_standard_value === null  ? '50':detectlist.detect_standard_value }}%
							</view>
							<view class="imgitem">
								<text>·检测人：</text>
								{{detectlist.detect_person === null  ? '暂无':detectlist.detect_person }}
							</view>

							<view class="imgitem">
								<text>·实测值：</text>
								{{detectlist.detect_real_value === null  ? '未检测':detectlist.detect_real_value + '%' }}
							</view>
							<view class="imgitem">
								<text>·检测单位：</text>
								{{detectlist.buyer_name}}
							</view>
						</view>
						<view v-if=" detectlist.cate_name == '蔬菜类' || detectlist.cate_name == '水果类' ">
							<image v-if=" detectlist.detect_result == null" class="qua" src="../../static/unce.png" mode=""></image>
							<image v-else class="qua" :src=" detectlist.detect_result == 'QUA'?  '../../static/QUA.png':'../../static/UNQUA.png' "
							 mode=""></image>
						</view>
						<view v-else>
							<image class="qua" :src='detectlist.product_cert == "" ?  "../../static/njian.png":"../../static/ujian.png"'
							 mode=""></image>
						</view>
					</view>
					<view class="home_title">
						<image class="line" src="../../static/line.png" mode="aspectFill"></image>
						溯源信息
					</view>
					<view class=" jianbottom" style="background: #fff;">
						<swiper autoplay="true" circular="true" :current="tabIndex" class="swiper-box" style="flex: 1;" :duration="300"
						 @change="ontabchange">
							<swiper-item class="swiper-item">
								<view class="jianontent">
									<view class="imgitem">
										<text>供货商类型：</text>
										农户
									</view>
									<view class="imgitem">
										<text>负责人：</text>
										{{sourcelist.source_contact}}
									</view>
									<view class="imgitem">
										<text>供货商名称：</text>
										{{sourcelist.source_name}}
									</view>
									<view class="imgitem">
										<text>联系方式：</text>{{sourcelist.source_tel}}
									</view>
									<view class="imgitem">
										<text>供货商地址：</text>
										{{sourcelist.source_address}}
									</view>
									<view class="imgitem" style="justify-content: flex-start; display: flex;">
										<text>商家资质：</text>
										<button class="bbe" style="background: #0096d5;" @tap="togglePopup('center', 'source',indexe)" type="primary">点击查看</button>
									</view>
								</view>
							</swiper-item>
							<swiper-item class="swiper-item">
								<view class="jianontent">
									<view class="imgitem">
										<text>配送商类型：</text>
										农户
									</view>
									<view class="imgitem">
										<text>负责人：</text>
										{{distributor.distributor_legal_person}}
									</view>
									<view class="imgitem">
										<text>配送商名称：</text>
										{{distributor.distributor_name}}
									</view>
									<view class="imgitem">
										<text>联系方式：</text>{{distributor.distributor_tel}}
									</view>
									<view class="imgitem">
										<text>配送商地址：</text>
										{{distributor.distributor_address}}
									</view>
									<view class="imgitem" style="justify-content: flex-start; display: flex;">
										<text>商家资质：</text>
										<button class="bbe" style="background: #0096d5;" @tap="togglePopup('center', 'distributor',indexe)" type="primary">点击查看</button>
									</view>
								</view>
							</swiper-item>
							<swiper-item class="swiper-item">
								<view class="jianontent">
									<view class="imgitem">
										<text>采购商类型：</text>
										农户
									</view>
									<view class="imgitem">
										<text>负责人：</text>
										{{buyerlist.buyer_legal_person}}
									</view>
									<view class="imgitem">
										<text>采购商名称：</text>
										{{buyerlist.buyer_name}}
									</view>
									<view class="imgitem">
										<text>联系方式：</text>{{buyerlist.buyer_tel}}
									</view>
									<view class="imgitem">
										<text>采购商地址：</text>
										{{buyerlist.buyer_address}}
									</view>
									<view class="imgitem" style="justify-content: flex-start; display: flex;">
										<text>商家资质：</text>
										<button class="bbe" style="background: #0096d5;" @tap="togglePopup('center', 'buyer',indexe)" type="primary">点击查看</button>
									</view>
								</view>
							</swiper-item>
						</swiper>
					</view>
					<scroll-view id="tab-bar" class="scroll-h" :scroll-x="true" :show-scrollbar="false" :scroll-into-view="scrollInto">
						<view class="tabberbox">
							<view class="swib">
								<view v-for="(item,index) in tabBars" class="bgitem" v-if="index < 1" :class="tabIndex == index ? 'bgitemac' + index  : 'bgitem'+index"
								 :key="index" :data-current="index" @click="ontabtap">
									<image :src=" tabIndex == index ? item.acsrc : item.src " mode=""></image>
									<view class="bgp">
										{{item.name}}
									</view>
								</view>
								<view v-for="(item,index) in tabBars" v-if="index>0" class="bgitem leftp" :class="tabIndex == index ? 'bgitemac' + index  : 'bgitem'+index"
								 :key="index" :data-current="index" @click="ontabtap">
									<image :src=" tabIndex == index ? item.acsrc : item.src " mode=""></image>
									<view class="bgp">
										{{item.name}}
									</view>
								</view>
							</view>
						</view>
					</scroll-view>
				</view>
			</view>
			<!-- 底部分享弹窗 -->
			<uni-popup :show="showshare" :type="type" @change="change">
				<view class="itemcontinaer">
					<image :src="detectlist.product_cert == null? '../../static/noimg.jpg' : detectlist.product_cert  " mode="widthFix"></image>
					<uni-icons @click="close('share')" class="iconii" type="clear" color="#333" size="60" />
				</view>
			</uni-popup>
			<!-- 底部分享弹窗 -->
			<uni-popup :show="showbuyer" :type="type" @change="change">
				<view class="itemcontinaer">
					<image :src="buyerlist.buyer_health_cert == null? '../../static/noimg.jpg' : buyerlist.buyer_health_cert  " mode="widthFix"></image>
					<uni-icons @click="close('buyer')" class="iconii" type="clear" color="#333" size="60" />
				</view>
			</uni-popup>
			<!-- 底部分享弹窗 -->
			<uni-popup :show="showdistributor" :type="type" @change="change">
				<view class="itemcontinaer">
					<image :src="distributor.distributor_business_license == null? '../../static/noimg.jpg' : distributor.distributor_business_license  "
					 mode="widthFix"></image>
					<uni-icons @click="close('distributor')" class="iconii" type="clear" color="#333" size="60" />
				</view>
			</uni-popup>
			<!-- 底部分享弹窗 -->
			<uni-popup :show="showsource" :type="type" @change="change">
				<view class="itemcontinaer">
					<image :src="sourcelist.source_business_license == null? '../../static/noimg.jpg' : sourcelist.source_business_license  "
					 mode="widthFix"></image>
					<uni-icons @click="close('source')" class="iconii" type="clear" color="#333" size="60" />
				</view>
			</uni-popup>
			<uni-popup :show="showpopup" :type="type" @change="change"></uni-popup>
		</view>
	</view>
</template>

<script>
	import uniSection from '@/components/uni-section/uni-section.vue'
	import uniPopup from '@/components/uni-popup/uni-popup.vue'
	import uniIcons from '@/components/uni-icons/uni-icons.vue'
	export default {
		components: {
			uniSection,
			uniPopup,
			uniIcons
		},
		data() {
			return {
				title: '',
				index: 0,
				weather: '',
				list: '',
				timeTemp: '',
				tabIndex: 0,
				tabBars: [{
					src:'../../static/a1.png',
					acsrc:'../../static/a0.png',
					name: '我从哪里来',
					newsid: 0
				},
				{
					src:'../../static/b1.png',
					acsrc:'../../static/b0.png',
					name: '谁送的我',
					newsid: 0
				},
				{
					src:'../../static/c1.png',
					acsrc:'../../static/c0.png',
					name: '谁买的我',
					newsid: 0
				}],
				scrollInto: "",
				buyerlist: [], // 采购商
				sourcelist: [], //供应商
				distributor: [], //配送商
				detectlist: [],
				current: 0,
				showshare: false,
				showsource: false,
				showbuyer: false,
				showdistributor: false,
				showpopup: false,
				type: '',
				indexe: 0,
				backtype:''
			}
		},
		onLoad:function(res){
			var that = this;
			 this.weahter();
			try {
				const value = uni.getStorageSync('sutype');
				if (value) {
					this.backtype = value;
				}
			} catch (e) {
				// error
			}
			var timestamp;
			timestamp = new Date().getTime();
			that.timeTemp = timestamp
			setInterval(function() {
				timestamp = new Date().getTime();
				that.timeTemp = timestamp
			}, 1000)
			
			let jindex = res.index;
			try {
				const value = uni.getStorageSync('jiance');
				if (value) {
					this.detectlist = value[jindex];
					let buyid = value[jindex].buyer_guid
					let source_guid = value[jindex].source_guid
					let distributor_guid = value[jindex].distributor_guid
					// 采购商
					uni.request({
						url: 'http://60.222.220.223:30005/v1/public/buyer?buyer_guid=' + buyid + '',
						success: (res) => {
							this.buyerlist = res.data.data.buyer;
						},
						fail: () => {
							// 失败隐藏下拉加载状态
							mescroll.endErr()
						},
						complete: function() {
						}
					})
					//供应商
					uni.request({
						url: 'http://60.222.220.223:30005/v1/public/source',
						data: {
							source_guid: source_guid
						},
						success: (res) => {
							this.sourcelist = res.data.data.source;
						},
						fail: () => {
							// 失败隐藏下拉加载状态
							mescroll.endErr()
						}
					})
					//配送商
					uni.request({
						url: 'http://60.222.220.223:30005/v1/public/distributor',
						data: {
							distributor_guid: distributor_guid
						},
						success: (res) => {
							this.distributor = res.data.data.distributor;
						},
						fail: () => {
							// 失败隐藏下拉加载状态
							mescroll.endErr()
						}
					})
				}
			} catch (e) {
				// error
			}
		},
		filters: {
			timeFormat: function(arg, type = 'YYYY-MM-DD h:m:s') {
				if (arg.toString().length == 10) {
					arg = arg * 1000;
					//如果date为13位不需要乘1000
					//[js时间戳长度是13位]，php，java等时间戳长度为10位
				}
				var date = new Date(arg)
				var year = date.getFullYear(); //获取年
				var mouth = (date.getMonth() + 1 < 10 ? '0' + (date.getMonth() + 1) : date.getMonth() + 1); //月
				var day = (date.getDate() < 10 ? '0' + (date.getDate()) : date.getDate()); //日
				var hour = (date.getHours() < 10 ? '0' + date.getHours() : date.getHours()); //时
				var minute = (date.getMinutes() < 10 ? '0' + date.getMinutes() : date.getMinutes()); //分
				var second = (date.getSeconds() < 10 ? '0' + date.getSeconds() : date.getSeconds()); //秒
				var week; //星期
				if (date.getDay() == 0) week = "星期日"
				if (date.getDay() == 1) week = "星期一"
				if (date.getDay() == 2) week = "星期二"
				if (date.getDay() == 3) week = "星期三"
				if (date.getDay() == 4) week = "星期四"
				if (date.getDay() == 5) week = "星期五"
				if (date.getDay() == 6) week = "星期六"
				if (type == 'YYYY-MM-DD h:m:s') {
					return week + ' ' + hour + ':' + minute + ':' + second;
				}
				if (type == 'YYYY-MM-DD') {
					return year + '-' + mouth + '-' + day;
				}
				if (type == 'MM-DD') {
					return mouth + '-' + day;
				}
				if (type == 'MM-DD WEEK') {
					return mouth + '-' + day + ' ' + week;
				}
			}
		},
		methods: {
			//天气实时状况
			weahter: function() {
				var that = this;
				var timestamp;
				timestamp = new Date().getTime();
				that.timeTemp = timestamp
				setInterval(function() {
					timestamp = new Date().getTime();
					that.timeTemp = timestamp
				}, 1000)
				//获取天气心情
				uni.request({
					url: 'https://www.tianqiapi.com/api/', //仅为示例，并非真实接口地址。
					data: {
						version: 'v6',
						city: '运城',
						appid: '71254342',
						appsecret: 'aSe7JkVM'
					},
					success: (res) => {
						that.weather = res.data;
					}
				});
			},
			togglePopup(type, open, index) {
				this.index = index;
				this.type = type
				this['show' + open] = true
			},
			cancel(type) {
				this['show' + type] = false
			},
			change(e) {
				if (!e.show) {
					this.showshare = false
					this.showpopup = false
				}
			},
			close(type) {
				this['show' + type] = false
			},
			back:function(){
				uni.navigateBack()
			},
			ontabtap(e) {
				let index = e.target.dataset.current || e.currentTarget.dataset.current;
				this.switchTab(index);
			},
			ontabchange(e) {
				let index = e.target.current || e.detail.current;
				this.switchTab(index);
			},
			switchTab(index) {
				if (this.tabIndex === index) {
					return;
				}
				this.tabIndex = index;
				this.scrollInto = this.tabBars[index].id;
			},
		}
	}
</script>

<style type="text/css">
	@import url("../../common/css/style.css");
	@import url("../../common/css/details.css");

	.header.school {
		background: #0096d5;
	}

	.header.food {
		background: #f7601b;
	}

	.header.nong {
		background: #20b1b2;
	}

	.container {
		padding: 25px 100px;
		width: 100%;
		height: 900px;
		background: url(http://h5.shouyunchina.com:8018/static/school.png) no-repeat;
		background-size: 100% 100%;
	}

	.container.school {
		background: url(http://h5.shouyunchina.com:8018/static/school.png) no-repeat;
	}

	.container.food {
		background-image: linear-gradient(rgb(248, 207, 191), rgb(254, 246, 235))
	}

	.foodbox.food {
		background: #fff;
	}

	.container.nong {
		background: url(http://h5.shouyunchina.com:8018/static/nong.png) no-repeat;
	}
</style>
