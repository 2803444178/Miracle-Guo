<template>
	<view class="content">
		<view class="header school" v-if="backtype == 'school'">
			<view class="headtitle">
				<view>
					创建国家食品安全示范城市
				</view>
				<view>
					食品溯源展示
				</view>
			</view>
			<view class="leftbox">
				<view class="left" @tap="remogo">
					<image :src="'../../static/images/weather/'+ wethaer.wea_img+'.png'" mode="widthFix"></image>
				</view>
				<view class="right">
					<view class="b1">{{timeTemp|timeFormat}}</view>
					<view class="b2">{{wethaer.wea}} {{wethaer.tem}} ℃</view>
				</view>
			</view>
		</view>
		<view class="header food" v-else-if="backtype == 'food'">
			<view class="headtitle">
				<view>
					创建国家食品安全示范城市
				</view>
				<view>
					食品溯源展示
				</view>
			</view>
			<view class="leftbox">
				<view class="left" @tap="remogo">
					<image :src="'../../static/images/weather/'+ wethaer.wea_img+'.png'" mode="widthFix"></image>
				</view>
				<view class="right">
					<view class="b1">{{timeTemp|timeFormat}}</view>
					<view class="b2">{{wethaer.wea}} {{wethaer.tem}} ℃</view>
				</view>
			</view>
		</view>
		<view class="header nong" v-else-if="backtype == 'nong'">
			<view class="headtitle">
				<view>
					创建国家食品安全示范城市
				</view>
				<view>
					食品溯源展示
				</view>
			</view>
			<view class="leftbox">
				<view class="left" @tap="remogo">
					<image :src="'../../static/images/weather/'+ wethaer.wea_img+'.png'" mode="widthFix"></image>
				</view>
				<view class="right">
					<view class="b1">{{timeTemp|timeFormat}}</view>
					<view class="b2">{{wethaer.wea}} {{wethaer.tem}} ℃</view>
				</view>
			</view>
		</view>
		<view class="container school" v-if="backtype == 'school'">
			<swiper :display-multiple-items="3" :interval="3000" :duration="1000">
				<swiper-item>
					<view class="indexitem">
						<view class="indeximg">
							<image src="http://60.222.220.223:30005/upload/buyer/20200624/1592971839662419.jpg" mode="aspectFill"></image>
						</view>
						<view class="title">
							盐化中学
						</view>
						<view class="indexfood">
							<view class="indexborder school" @tap="gofoode('3C3DB758700DE0961F8EB6B1AF52BBFB')">
								点击进入
							</view>
						</view>
					</view>
				</swiper-item>
				<swiper-item>
					<view class="indexitem">
						<view class="indeximg">
							<image src="../../static/timg.jpg" mode="aspectFill"></image>
						</view>
						<view class="title">
							新绛二中
						</view>
						<view class="indexfood">
							<view class="indexborder school" @tap="gofoode('589545A991AD9425ED95E6AC5EA3D540')">
								点击进入
							</view>
						</view>
					</view>
				</swiper-item>
				<swiper-item>
					<view class="indexitem">
						<view class="indeximg">
							<image src="http://60.222.220.223:30005/upload/buyer/20200428/1588044662223271.jpg" mode="aspectFill"></image>
						</view>
						<view class="title">
							山西省新绛县海泉学校（高中部）
						</view>
						<view class="indexfood">
							<view class="indexborder school" @tap="gofoode('BF8D3C605C2D0BB85EA328AC7D9F6D79')">
								点击进入
							</view>
						</view>
					</view>
				</swiper-item>
				<swiper-item>
					<view class="indexitem">
						<view class="indeximg">
							<image src="http://60.222.220.223:30005/upload/buyer/20191230/1577676390944134.jpg" mode="aspectFill"></image>
						</view>
						<view class="title">
							运城市薛辽中学食堂
						</view>
						<view class="indexfood">
							<view class="indexborder school" @tap="gofoode('D37221ED5A73B18A9A7691C755CD7F4D')">
								点击进入
							</view>
						</view>
					</view>
				</swiper-item>
				<swiper-item>
					<view class="indexitem">
						<view class="indeximg">
							<image src="http://60.222.220.223:30005/upload/buyer/20200609/1591671529375636.jpg" mode="aspectFill"></image>
						</view>
						<view class="title">
							运城市盐湖区晋欧小学
						</view>
						<view class="indexfood">
							<view class="indexborder school" @tap="gofoode('63B34F999F8AD7541888FD8AF87B27C8')">
								点击进入
							</view>
						</view>
					</view>
				</swiper-item>
				<!-- <swiper-item v-for="(item,index) in adresslist" :key="index">
					<view class="indexitem">
						<view class="indeximg">
							<image :src="item.buyer_image == null ? '../../static/timg.jpg' : item.buyer_image " mode="aspectFill"></image>
						</view>
						<view class="title">
							{{item.buyer_name}}
						</view>
						<view class="indexfood">
							<view class="indexborder school" @tap="gofoode(item.buyer_guid)">
								点击进入
							</view>
						</view>
					</view>
				</swiper-item> -->
			</swiper>
			<view class="version">
				版本号：1.0.0
			</view>
			<view class="version">
				技术支持：首云科技
			</view>
		</view>
		<view class="container food" v-else-if="backtype == 'food'">
			<swiper :display-multiple-items="3" :interval="3000" :duration="1000" disable-touch=true>
				<swiper-item>
					<view class="indexitem">
						<view class="indeximg">
							<image src="../../static/timg.jpg" mode="aspectFill"></image>
						</view>
						<view class="title">
							海泉大酒店
						</view>
						<view class="indexfood">
							<view class="indexborder school" @tap="gofoode('67F781BF4FEC4A9134A3281B360C6C04')">
								点击进入
							</view>
						</view>
					</view>
				</swiper-item>
				<swiper-item>
					<view class="indexitem">
						<view class="indeximg">
							<image src="../../static/timg.jpg" mode="aspectFill"></image>
						</view>
						<view class="title">
							恒泽大酒店
						</view>
						<view class="indexfood">
							<view class="indexborder school" @tap="gofoode('CBDF8023E63BE116348F7AB7830DDDD9')">
								点击进入
							</view>
						</view>
					</view>
				</swiper-item>
				<!-- <swiper-item v-for="(item,index) in adresslist" :key="index">
					<view class="indexitem">
						<view class="indeximg">
							<image :src="item.buyer_image == null ? '../../static/timg.jpg' : item.buyer_image " mode="aspectFill"></image>
						</view>
						<view class="title">
							{{item.buyer_name}}
						</view>
						<view class="indexfood">
							<view class="indexborder food" @tap="gofoode(item.buyer_guid)">
								点击进入
							</view>
						</view>
					</view>
				</swiper-item> -->
			</swiper>
			<view class="version">
				版本号：1.0.0
			</view>
			<view class="version">
				技术支持：首云科技
			</view>
		</view>
		<view class="container nong" v-else-if="backtype == 'nong'">
			<swiper :display-multiple-items="3" :interval="3000" 	 :duration="1000">
				<!-- <swiper-item>
					<view class="indexitem">
						<view class="indeximg">
							<image src="http://60.222.220.223:30005/upload/buyer/20200310/1583824354635699.jpg" mode="aspectFill"></image>
						</view>
						<view class="title">
							山西永辉超市有限公司解放路分公司
						</view>
						<view class="indexfood">
							<view class="indexborder school" @tap="gofoode('D197997021CBB1CD0565F0EB93C55152')">
								点击进入
							</view>
						</view>
					</view>
				</swiper-item> -->
				<!-- <swiper-item>
					<view class="indexitem">
						<view class="indeximg">
							<image src="../../static/timg.jpg" mode="aspectFill"></image>
						</view>
						<view class="title">
							山西胖达鲜生商贸有限公司运城第一分公司
						</view>
						<view class="indexfood">
							<view class="indexborder school" @tap="gofoode('DA38BE223D81F4039F08D6E5E5179AFE')">
								点击进入
							</view>
						</view>
					</view>
				</swiper-item> -->
				
				<swiper-item v-for="(item,index) in adresslist" :key="index">
					<view class="indexitem">
						<view class="indeximg">
							<image :src="item.buyer_image == null ? '../../static/timg.jpg' : item.buyer_image " mode="aspectFill"></image>
						</view>
						<view class="title">
							{{item.buyer_name}}
						</view>
						<view class="indexfood">
							<view class="indexborder nong" @tap="gofoode(item.buyer_guid)">
								点击进入
							</view>
						</view>
					</view>
				</swiper-item>
			</swiper>
			<view class="version">
				版本号：1.0.0
			</view>
			<view class="version">
				技术支持：首云科技
			</view>
		</view>
	</view>
</template>

<script>
	import tkiQrcode from "@/components/tki-qrcode/tki-qrcode.vue"
	export default {
		components: {
			tkiQrcode
		},
		props: {
			height: {
				default: 140,
				type: Number
			},
			lineNum: {
				default: 3,
				type: Number
			}
		},
		data() {
			return {
				wethaer: '',
				type: '',
				timeTemp: '', //天气
				foodinfo: [], //食品溯源list
				list: [], //首页list
				dateList: [],
				adresslist: '',
				index: 0,
				homedata: '',
				sutype: 'school',
				backtype: ''
			}
		},
		async onLoad(res) {
			var that = this;
			try {
				const value = uni.getStorageSync('sutype');
				if (value) {
					this.backtype = value;
				}
			} catch (e) {
				// error
			}
			this.sutype = res.type;
			await that.adress(res.type);
			await that.weahter();
		},
		methods: {
			// 获取企业列表
			adress: function(type) {
				uni.request({
					url: 'http://60.222.220.223:30005/v1/public/buyers?page_size=99999', //仅为示例，并非真实接口地址。
					success: (res) => {
						let arrli = res.data.data.result
						let arr = [];
						if (type == 'school') {
							for (let i in arrli) {
								if (arrli[i].mess_type.includes('SCHOOL')) {
									arr.push(arrli[i])
								}
							}
							let arre = arr.filter(function(currentValue, index) {
								return (
									currentValue.buyer_name != '临猗县第三中学' &&
									currentValue.buyer_name != '夏县第二中学餐厅' &&
									currentValue.buyer_name != '夏县中学食堂' &&
									currentValue.buyer_name != '开发区幼儿园' &&
									currentValue.buyer_name != '康杰中学' &&
									currentValue.buyer_name != '山西省新绛县海泉学校（初中部）' &&
									currentValue.buyer_name != '山西省新绛县海泉学校（小学）' &&
									currentValue.buyer_name != '垣曲县移民初中'
								)
							})
							this.adresslist = arre;
						} else if (type == 'food') {
							for (let i in arrli) {
								if (arrli[i].buyer_type.includes('CATERING')) {
									arr.push(arrli[i])
								}
							}
							let arre = arr.filter(function(currentValue, index) {
								return (
									currentValue.buyer_name != '少强大盘鸡' &&
									currentValue.buyer_name != '高记手擀面店' &&
									currentValue.buyer_name != '晓明老贾食府' &&
									currentValue.buyer_name != '崔伟锋京城一品自助店' &&
									currentValue.buyer_name != '红胖子火锅' &&
									currentValue.buyer_name != '河东味道饭店' &&
									currentValue.buyer_name != '三和祥酒店' &&
									currentValue.buyer_name != '京味楼' &&
									currentValue.buyer_name != '临猗县东城刘红小吃店' &&
									currentValue.buyer_name != '高栋面馆' &&
									currentValue.buyer_name != '娲城王婆大虾'
								)
							})
							this.adresslist = arre;
						} else if (type == 'nong') {
							for (let i in arrli) {
								if (arrli[i].buyer_type.includes('MARKET')) {
									arr.push(arrli[i])
								}
							}
							let arre = arr.filter(function(currentValue, index) {
								return (
									currentValue.buyer_name != '运城市恒来源农贸市场管理有限公司'
								)
							})

							this.adresslist = arre;
						}
						var buyid = this.homedata.buyer_guid
					}
				});
			},
			//天气实时状况
			weahter: function() {
				var that = this;
				var timestamp;
				timestamp = new Date().getTime();
				that.timeTemp = timestamp
				setInterval(function() {
					timestamp = new Date().getTime();
					that.timeTemp = timestamp
				}, 1000)
				//获取天气心情
				uni.request({
					url: 'https://www.tianqiapi.com/api/', //仅为示例，并非真实接口地址。
					data: {
						version: 'v6',
						city: '运城',
						appid: '71254342',
						appsecret: 'aSe7JkVM'
					},
					success: (res) => {
						that.wethaer = res.data;
					}
				});
			},
			gofoode: function(id) {
				let type = this.sutype
				if (type == 'school') {
					try {
						uni.setStorageSync('school', id);
						uni.navigateTo({
							url: "../foode/foode?id=" + id + ""
						})
					} catch (e) {
						// error
					}
				} else if (type == 'food') {
					try {
						uni.setStorageSync('food', id);
						uni.navigateTo({
							url: "../foode/foode?id=" + id + ""
						})
					} catch (e) {
						// error
					}
				} else if (type == 'nong') {
					try {
						uni.setStorageSync('nong', id);
						uni.navigateTo({
							url: "../foode/foode?id=" + id + ""
						})
					} catch (e) {
						// error
					}
				}


			},
			govideo: function(id) {
				uni.navigateTo({
					url: "../video/video?id=" + id + ""
				})
			},
			remogo: function() {
				uni.navigateTo({
					url: "../video/video"
				})
			}
		},
		filters: {
			timeFormat: function(arg, type = 'YYYY-MM-DD h:m:s') {
				if (arg.toString().length == 10) {
					arg = arg * 1000;
					//如果date为13位不需要乘1000
					//[js时间戳长度是13位]，php，java等时间戳长度为10位
				}
				var date = new Date(arg)
				var year = date.getFullYear(); //获取年
				var mouth = (date.getMonth() + 1 < 10 ? '0' + (date.getMonth() + 1) : date.getMonth() + 1); //月
				var day = (date.getDate() < 10 ? '0' + (date.getDate()) : date.getDate()); //日
				var hour = (date.getHours() < 10 ? '0' + date.getHours() : date.getHours()); //时
				var minute = (date.getMinutes() < 10 ? '0' + date.getMinutes() : date.getMinutes()); //分
				var second = (date.getSeconds() < 10 ? '0' + date.getSeconds() : date.getSeconds()); //秒
				var week; //星期
				if (date.getDay() == 0) week = "星期日"
				if (date.getDay() == 1) week = "星期一"
				if (date.getDay() == 2) week = "星期二"
				if (date.getDay() == 3) week = "星期三"
				if (date.getDay() == 4) week = "星期四"
				if (date.getDay() == 5) week = "星期五"
				if (date.getDay() == 6) week = "星期六"
				if (type == 'YYYY-MM-DD h:m:s') {
					return week + ' ' + hour + ':' + minute + ':' + second;
				}
				if (type == 'YYYY-MM-DD') {
					return year + '-' + mouth + '-' + day;
				}
				if (type == 'MM-DD') {
					return mouth + '-' + day;
				}
				if (type == 'MM-DD WEEK') {
					return mouth + '-' + day + ' ' + week;
				}
			}
		}
	}
</script>

<style>
	@import url("../../common/css/style.css");
	@import url("../../common/css/index.css");

	.indexborder.school {
		color: #fff;
		background: #0096d5;
		border: 2px solid #0096d5;
	}

	.indexborder.food {
		color: #fff;
		background: #f7601b;
		border: 2px solid #f7601b;
	}

	.indexborder.nong {
		color: #fff;
		background: #20b1b2;
		border: 2px solid #20b1b2;
	}

	.header.school {
		background: #0096d5;
	}

	.header.food {
		background: #f7601b;
	}

	.header.nong {
		background: #20b1b2;
	}

	.container {
		padding: 25px 100px;
		width: 100%;
		height: 900px;
		background: url(http://h5.shouyunchina.com:8018/static/school.png) no-repeat;
		background-size: 100% 100%;
	}

	.container.school {
		background: url(http://h5.shouyunchina.com:8018/static/school.png) no-repeat;
		background-size: 100% 100%;
	}

	.container.food {
		background-image: linear-gradient(rgb(248, 207, 191), rgb(254, 246, 235))
	}

	.foodbox.food {
		background: #fff;
	}

	.container.nong {
		background: url(http://h5.shouyunchina.com:8018/static/nong.png) no-repeat;
		background-size: 100% 100%;
	}

	.content {
		display: flex;
		flex-direction: column;
		align-items: center;
		justify-content: center;
	}

	.logo {
		height: 200rpx;
		width: 200rpx;
		margin-top: 200rpx;
		margin-left: auto;
		margin-right: auto;
		margin-bottom: 50rpx;
	}

	.text-area {
		display: flex;
		justify-content: center;
	}

	.title {
		font-size: 36rpx;
		color: #8f8f94;
	}

	.uni-title {
		font-size: 50px;
		text-align: center;
		height: 80px;
		line-height: 80px;
		font-weight: 600;
		color: #fff;
	}

	.titlelist {
		font-size: 35px;
		text-align: center;
		height: 50px;
		line-height: 50px;
		margin-top: 15px;
	}
</style>
