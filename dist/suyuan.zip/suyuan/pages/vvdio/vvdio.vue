<template>
	<view class="content">
		<view class="header">
			<image class="back" @tap="back()" src="../../static/back.png" mode="widthFix"></image>
			<view class="headtitle">
				<view>
					创建国家食品安全示范城市
				</view>
				<view>
					食品溯源展示
				</view>
			</view>
			<view class="leftbox">
				<view class="left">
					<image :src="'../../static/images/weather/'+ wethaer.wea_img+'.png'" mode="widthFix"></image>
				</view>
				<view class="right">
					<view class="b1">{{timeTemp|timeFormat}}</view>
					<view class="b2">{{wethaer.wea}} {{wethaer.tem}} ℃</view>
				</view>
			</view>
		</view>
		<view class="container">
			<view class="videobox">
				<view class="video">
					<video src="rtmp://60.222.222.19:1935/live/pag/60.222.222.19/7302/001705/0/MAIN/TCP" controls></video>
				</view>
				<!-- <view class="jiedian rightbox">
					<h1>
						监控节点信息
					</h1>
					<view class="content">
						<view class="item">
							生产车间
						</view>
						<view class="item">
							生产车间
						</view>
						<view class="item">
							生产车间
						</view>
						<view class="item">
							生产车间
						</view>
					</view>
				</view> -->
			</view>

		</view>
	</view>
</template>

<script>
	export default {
		data() {
			return {
				wethaer: '',
				type: '',
				timeTemp: '', //天气
				foodinfo: [], //食品溯源list
				list: [], //首页list
				//首页id切换
				adresslist: '',
				index: 0,
				homedata: '',
				videosrc: ''
			}
		},
		async onLoad(res) {
			var that = this
			await that.weahter();
			if (res = "4B13E3CD7C2BBCB40A71E846289BB908") {
				this.videosrc = "rtmp://60.222.222.19:1935/live/pag/60.222.222.19/7302/001705/0/MAIN/TCP"
			}
		},
		methods: {
			//天气实时状况
			weahter: function() {
				var that = this;
				var timestamp;
				timestamp = new Date().getTime();
				that.timeTemp = timestamp
				setInterval(function() {
					timestamp = new Date().getTime();
					that.timeTemp = timestamp
				}, 1000)
				//获取天气心情
				uni.request({
					url: 'https://www.tianqiapi.com/api/', //仅为示例，并非真实接口地址。
					data: {
						version: 'v6',
						city: '运城',
						appid: '71254342',
						appsecret: 'aSe7JkVM'
					},
					success: (res) => {
						that.wethaer = res.data;
						try {
							uni.setStorageSync('weather', this.wethaer);
						} catch (e) {
							// error
						}
					}
				});
			},
			back: function() {
				uni.navigateBack()
			}
		},
		filters: {
			timeFormat: function(arg, type = 'YYYY-MM-DD h:m:s') {
				if (arg.toString().length == 10) {
					arg = arg * 1000;
					//如果date为13位不需要乘1000
					//[js时间戳长度是13位]，php，java等时间戳长度为10位
				}
				var date = new Date(arg)
				var year = date.getFullYear(); //获取年
				var mouth = (date.getMonth() + 1 < 10 ? '0' + (date.getMonth() + 1) : date.getMonth() + 1); //月
				var day = (date.getDate() < 10 ? '0' + (date.getDate()) : date.getDate()); //日
				var hour = (date.getHours() < 10 ? '0' + date.getHours() : date.getHours()); //时
				var minute = (date.getMinutes() < 10 ? '0' + date.getMinutes() : date.getMinutes()); //分
				var second = (date.getSeconds() < 10 ? '0' + date.getSeconds() : date.getSeconds()); //秒
				var week; //星期
				if (date.getDay() == 0) week = "星期日"
				if (date.getDay() == 1) week = "星期一"
				if (date.getDay() == 2) week = "星期二"
				if (date.getDay() == 3) week = "星期三"
				if (date.getDay() == 4) week = "星期四"
				if (date.getDay() == 5) week = "星期五"
				if (date.getDay() == 6) week = "星期六"
				if (type == 'YYYY-MM-DD h:m:s') {
					return week + ' ' + hour + ':' + minute + ':' + second;
				}
				if (type == 'YYYY-MM-DD') {
					return year + '-' + mouth + '-' + day;
				}
				if (type == 'MM-DD') {
					return mouth + '-' + day;
				}
				if (type == 'MM-DD WEEK') {
					return mouth + '-' + day + ' ' + week;
				}
			}
		}
	}
</script>

<style>
	@import url("../../common/css/style.css");
	@import url("../../common/css/index.css");
	@import url("../../common/css/video.css");

	video {
		width: 100%;
		height: 100%;
	}

	.back {
		width: 60px;
		height: 60px;
		position: absolute;
		left: 20px;
	}
	
</style>
