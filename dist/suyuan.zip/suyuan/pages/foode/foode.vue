<template>
	<view class="content">
		<view class="header school" v-if="backtype == 'school'">
			<image class="back" src="../../static/back.png" mode="widthFix" @tap="back('school')"></image>
			<view class="headtitle">
				<view>
					创建国家食品安全示范城市
				</view>
				<view>
					食品溯源展示
				</view>
			</view>
			<view class="leftbox">
				<image v-if="vasrc == 'vadio'" class="jian" src="../../static/jian.png" mode="aspectFill" @tap="govadio('')"></image>
				<view class="right">
					<view class="b11">检测日期查询</view>
					<picker class="section__input" @change="bindPickerChangep" :value="personindex" :range="dateList">
						<view class="b22">{{dateList[personindex]}}</view>
					</picker>
				</view>
				
			</view>
		</view>
		<view class="header food" v-else-if="backtype == 'food'">
			<image class="back" src="../../static/back.png" mode="widthFix" @tap="back('food')"></image>
			<view class="headtitle">
				<view>
					创建国家食品安全示范城市
				</view>
				<view>
					食品溯源展示
				</view>
			</view>
			<view class="leftbox">
				<view class="right">
					<view class="b11">检测日期查询</view>
					<picker class="section__input" @change="bindPickerChangep" :value="personindex" :range="dateList">
						<view class="b22">{{dateList[personindex]}}</view>
					</picker>
				</view>
				
			</view>
		</view>
		<view class="header nong" v-else-if="backtype == 'nong'">
			<image class="back" src="../../static/back.png" mode="widthFix" @tap="back('nong')"></image>
			<view class="headtitle">
				<view>
					创建国家食品安全示范城市
				</view>
				<view>
					食品溯源展示
				</view>
			</view>
			<view class="leftbox">
				<view class="right">
					<view class="b11">检测日期查询</view>
					<picker class="section__input" @change="bindPickerChangep" :value="personindex" :range="dateList">
						<view class="b22">{{dateList[personindex]}}</view>
					</picker>
				</view>
				
			</view>
		</view>
		<view class="container school" v-if="backtype == 'school'" :data-type='backtype'>
			<view class="foodbox">
				<view v-for="(item,index) in foodinfo" :key="index" class="fooditem" :id="index" @tap="godetails">
					<view class="foodimg">
						<image :src="item.product_mobile_icon" mode="widthFix"></image>
					</view>
					<view class="foodcontent">
						<view class="foodsp">
							样品名称：<text class="bb">{{item.product_name}}</text>
						</view>
						<view class="foodsp">
							样品来源：<text class="bb">{{item.source_name}}</text>
						</view>
						<view v-if="item.cate_name == '蔬菜类' || item.cate_name == '水果类' ">
							样品结果：<text v-if=" item.detect_result == null" class="bb">未检测</text>
							<text v-else class="bb">{{item.detect_result == "QUA"? '合格':"不合格" }}</text>
						</view>
						<view v-else>
							样品结果：<text class="bb">{{item.product_cert == "" ?  "无检测报告":"有检测报告"}}</text>
						</view>
					</view>
					<view v-if=" item.cate_name == '蔬菜类' || item.cate_name == '水果类' ">
						<image v-if=" item.detect_result == null" class="qua" src="../../static/unce.png" mode=""></image>
						<image v-else class="qua" :src=" item.detect_result == 'QUA'?  '../../static/QUA.png':'../../static/UNQUA.png' "
						 mode=""></image>
					</view>
					<view v-else>
						<image class="qua" :src='item.product_cert == "" ?  "../../static/njian.png":"../../static/ujian.png"' mode=""></image>
					</view>
				</view>
			</view>
		</view>
		<view class="container food" v-else-if="backtype == 'food'">
			<view class="foodbox food">
				<view v-for="(item,index) in foodinfo" :key="index" class="fooditem" :id="index" @tap="godetails">
					<view class="foodimg">
						<image :src="item.product_mobile_icon" mode="widthFix"></image>
					</view>
					<view class="foodcontent">
						<view class="foodsp">
							样品名称：<text class="bb">{{item.product_name}}</text>
						</view>
						<view class="foodsp">
							样品来源：<text class="bb">{{item.source_name}}</text>
						</view>
						<view v-if="item.cate_name == '蔬菜类' || item.cate_name == '水果类' ">
							样品结果：<text v-if=" item.detect_result == null" class="bb">未检测</text>
							<text v-else class="bb">{{item.detect_result == "QUA"? '合格':"不合格" }}</text>
						</view>
						<view v-else>
							样品结果：<text class="bb">{{item.product_cert == "" ?  "无检测报告":"有检测报告"}}</text>
						</view>
					</view>
					<view v-if=" item.cate_name == '蔬菜类' || item.cate_name == '水果类' ">
						<image v-if=" item.detect_result == null" class="qua" src="../../static/unce.png" mode=""></image>
						<image v-else class="qua" :src=" item.detect_result == 'QUA'?  '../../static/QUA.png':'../../static/UNQUA.png' "
						 mode=""></image>
					</view>
					<view v-else>
						<image class="qua" :src='item.product_cert == "" ?  "../../static/njian.png":"../../static/ujian.png"' mode=""></image>
					</view>
				</view>
			</view>
		</view>
		<view class="container nong" v-if="backtype == 'nong'">
			<view class="foodbox">
				<view v-for="(item,index) in foodinfo" :key="index" class="fooditem" :id="index" @tap="godetails">
					<view class="foodimg">
						<image :src="item.product_mobile_icon" mode="widthFix"></image>
					</view>
					<view class="foodcontent">
						<view class="foodsp">
							样品名称：<text class="bb">{{item.product_name}}</text>
						</view>
						<view class="foodsp">
							样品来源：<text class="bb">{{item.source_name}}</text>
						</view>
						<view v-if="item.cate_name == '蔬菜类' || item.cate_name == '水果类' ">
							样品结果：<text v-if=" item.detect_result == null" class="bb">未检测</text>
							<text v-else class="bb">{{item.detect_result == "QUA"? '合格':"不合格" }}</text>
						</view>
						<view v-else>
							样品结果：<text class="bb">{{item.product_cert == "" ?  "无检测报告":"有检测报告"}}</text>
						</view>
					</view>
					<view v-if=" item.cate_name == '蔬菜类' || item.cate_name == '水果类' ">
						<image v-if=" item.detect_result == null" class="qua" src="../../static/unce.png" mode=""></image>
						<image v-else class="qua" :src=" item.detect_result == 'QUA'?  '../../static/QUA.png':'../../static/UNQUA.png' "
						 mode=""></image>
					</view>
					<view v-else>
						<image class="qua" :src='item.product_cert == "" ?  "../../static/njian.png":"../../static/ujian.png"' mode=""></image>
					</view>
				</view>
			</view>
		</view>
	</view>
</template>

<script>
	import tkiQrcode from '@/components/tki-qrcode/tki-qrcode.vue'
	export default {
		components: {
			tkiQrcode
		},
		data() {
			return {
				ifShow: true,
				val: '', // 要生成的二维码值
				size: 50, // 二维码大小
				unit: 'upx', // 单位
				background: '#fff', // 背景色
				foreground: '#309286', // 前景色
				pdground: '#32dbc6', // 角标色
				icon: '', // 二维码图标
				iconsize: 40, // 二维码图标大小
				lv: 3, // 二维码容错级别 ， 一般不用设置，默认就行
				onval: true, // val值变化时自动重新生成二维码
				loadMake: true, // 组件加载完成后自动生成二维码
				src: '', // 二维码生成后的图片地址或base64
				foodinfo: [], //食品溯源list
				list: [], //首页list
				dateList: [],
				personindex: 0,
				//首页id切换
				index: 0,
				foodinfolength: 0,
				buid: '',
				backtype: '',
				vasrc: ''
			}
		},
		async onLoad(res) {
			var that = this
			try {
				const value = uni.getStorageSync('sutype');
				if (value) {
					this.backtype = value;
					// 判断类型，school  学校食堂
					if (value == 'school') {
						try {
							const value = uni.getStorageSync('school');
							if (value) {
								if (value == '4B13E3CD7C2BBCB40A71E846289BB908') {
									this.vasrc = "vadio"
								}
								this.buid = value;
								this.val = "http://yczhsybd.yczhcs.cn:20199/suyuan/mobile.html?id=" + res.id + ""
								that.ajaxjian(value);
							} else {
								that.ajaxjian('0117063D3C3E466184287C0C9DC4C767');
								this.val = "http://yczhsybd.yczhcs.cn:20199/suyuan/mobile.html?id=0117063D3C3E466184287C0C9DC4C767"
							}
						} catch (e) {
							// error
						}
					} else if (value == 'food') {
						try {
							const value = uni.getStorageSync('food');
							if (value) {
								this.buid = value;
								this.val = "http://yczhsybd.yczhcs.cn:20199/suyuan/mobile.html?id=" + res.id + ""
								that.ajaxjian(value);
							} else {
								that.ajaxjian('C21E3B5FB3B8EDD5A876E33AC5799D9C');
								this.val = "http://yczhsybd.yczhcs.cn:20199/suyuan/mobile.html?id=C21E3B5FB3B8EDD5A876E33AC5799D9C"
							}
						} catch (e) {
							// error
						}
					} else if (value == 'nong') {
						try {
							const value = uni.getStorageSync('nong');
							if (value) {
								this.buid = value;
								this.val = "http://yczhsybd.yczhcs.cn:20199/suyuan/mobile.html?id=" + res.id + ""
								that.ajaxjian(value);
							} else {
								that.ajaxjian('1C65845FD9703B2BDAAC8BC396BD4995');
								this.val = "http://yczhsybd.yczhcs.cn:20199/suyuan/mobile.html?id=1C65845FD9703B2BDAAC8BC396BD4995"
							}
						} catch (e) {
							// error
						}
					}
				}
			} catch (e) {
				// error
			}
		},
		methods: {
			//天气实时状况
			ajaxjian: function(buyid) {
				//判断是否存在缓存
				var that = this;
				try {
					uni.request({
						url: 'http://60.222.220.223:30005/v1/public/detect',
						data: {
							buyer_guid: buyid,
							page_size: 9999,
							order_status: 502
						},
						success: (data) => {
							var list = data.data.data.result;
							uni.setStorage({
								key: 'jiance',
								data: list,
								success: function() {

								}
							});
							if (list.length != 0) {
								that.jianchu(list)
							} else {
								this.foodinfo = [];
							}
						},
						fail: () => {

						}
					})
				} catch (e) {
					// error
				}
			},
			jianchu: function(value) {
				var that = this;
				var dateList = [];
				// var newDate = /\d{4}-\d{1,2}-\d{1,2}/g.exec(last_time)
				// 获取所有的检测时间
				for (var i = 0; i < value.length; i++) {
					if (dateList.indexOf(/\d{4}-\d{1,2}-\d{1,2}/g.exec(value[i].order_arrival_start_time)[0]) == -1) {
						dateList.push(/\d{4}-\d{1,2}-\d{1,2}/g.exec(value[i].order_arrival_start_time)[0])
					}
				}
				that.dateList = dateList;
				var arre = [];
				var arrelist = [];
				arre.push(dateList[0])
				for (let i in value) {
					for (let j in arre) {
						if (value[i].order_arrival_start_time.includes(arre[j])) {
							arrelist.push(value[i])
							that.list = arrelist;
						}
					}
				}
				//显示最贱三天的
				var arr = [];
				var arrlist = [];
				arr.push(dateList[0])
				var result = [];
				for (let i in value) {
					for (let j in arr) {
						if (value[i].order_arrival_start_time.includes(arr[j])) {
							arrlist.push(value[i])
						}
					}
				}
				that.foodinfolength = arrlist.length
				that.foodinfo = arrlist;
			},
			godetails: function(e) {
				let index = e.currentTarget.id
				uni.navigateTo({
					url: "../details/details?&&index=" + index + ""
				})
			},
			qrR(res) {
				this.src = res
			},
			bindPickerChangep: function(e) {
				this.personindex = e.target.value
				let index = e.target.value
				let buyid = this.buid
				let newtime = this.dateList[index];
				uni.request({
					url: 'http://60.222.220.223:30005/v1/public/detect',
					data: {
						buyer_guid: this.buid,
						order_place_time_start: newtime,
						order_place_time_end: newtime,
						order_status: 502
					},
					success: (res) => {
						let value = res.data.data.result
						uni.setStorage({
							key: 'jiance',
							data: value,
							success: function() {

							}
						});
						this.foodinfo = value;
					}
				});
			},
			back: function(type) {
				uni.navigateTo({
					url: "../index/index?type=" + type + ""
				})
			},
			govadio:function(){
				uni.navigateTo({
					url: "../vvdio/vvdio"
				})
			}
		},
	}
</script>

<style>
	@import url("../../common/css/style.css");
	@import url("../../common/css/index.css");
	@import url("../../common/css/food.css");

	.header.school {
		background: #0096d5;
	}

	.header.food {
		background: #f7601b;
	}

	.header.nong {
		background: #20b1b2;
	}

	.container {
		padding: 25px 100px;
		width: 100%;
		height: 900px;
		background-size: 100% 100%;
	}

	

	.container.food {
		background-image: linear-gradient(rgb(248, 207, 191), rgb(254, 246, 235))
	}

	.foodbox.food {
		background: #fff;
	}

	.container.nong {
		background-size: 100% 100%;
		background: url(http://h5.shouyunchina.com:8018/static/nong.png) no-repeat;
	}

	.erweima {
		width: 150px;
		height: 150px;
	}

	.erweima image {
		width: 100%;
		height: 100%;
		display: block;
	}

	.back {
		width: 60px;
		height: 60px;
		position: absolute;
		left: 20px;
		top: 60px
	}

	.switabbox {
		width: 160px;
		height: 160px;
		position: fixed;
		bottom: 20px;
		right: 60px;
		background: inherit;
	}

	.switab {
		display: block;
		width: 100%;
		height: 100%;
	}
</style>
