<template>
	<view class="content">
		<view class="header">
			<view class="headtitle">
				<view>
					创建国家食品安全示范城市
				</view>
				<view>
					食品溯源展示
				</view>
			</view>
			<view class="leftbox">
				<view class="left">
					<image :src="'../../static/images/weather/'+ wethaer.wea_img+'.png'" mode="widthFix"></image>
				</view>
				<view class="right">
					<view class="b1">{{timeTemp|timeFormat}}</view>
					<view class="b2">{{wethaer.wea}} {{wethaer.tem}} ℃</view>
				</view>
			</view>
		</view>
		<view class="indexbox">
			<swiper :display-multiple-items="3" :interval="3000" :duration="1000">
				<swiper-item>
					<view class="indexitem">
						<view class="indeximg">
							<image src="../../static/timg.jpg" mode="aspectFill"></image>
						</view>
						<view class="title">
							学校食堂
						</view>
						<view class="indexfood">
							<view class="indexborder" @tap="godetails('school')">
								点击进入
							</view>
						</view>
					</view>
				</swiper-item>
				<swiper-item>
					<view class="indexitem">
						<view class="indeximg">
							<image src="../../static/timg.jpg" mode="aspectFill"></image>
						</view>
						<view class="title">
							社会餐饮
						</view>
						<view class="indexfood">
							<view class="indexborder" @tap="godetails('food')">
								点击进入
							</view>
						</view>
					</view>
				</swiper-item>
				<swiper-item>
					<view class="indexitem">
						<view class="indeximg">
							<image src="../../static/timg.jpg" mode="aspectFill"></image>
						</view>
						<view class="title">
							农贸市场
						</view>
						<view class="indexfood">
							<view class="indexborder" @tap="godetails('nong')">
								点击进入
							</view>
						</view>
					</view>
				</swiper-item>
			</swiper>
		</view>
		<view class="version">
			版本号：1.0.0
		</view>
		<view class="version">
			技术支持：首云科技
		</view>
	</view>
	</view>
</template>

<script>
	import tkiQrcode from "@/components/tki-qrcode/tki-qrcode.vue"
	export default {
		components: {
			tkiQrcode
		},
		props: {
			height: {
				default: 140,
				type: Number
			},
			lineNum: {
				default: 3,
				type: Number
			}
		},
		data() {
			return {
				wethaer: '',
				type: '',
				timeTemp: '', //天气
				foodinfo: [], //食品溯源list
				list: [], //首页list
				dateList: [],
				adresslist: '',
				index: 0,
				homedata: '',
			}
		},
		async onLoad() {
			var that = this
			await that.weahter();
		},
		methods: {
			//天气实时状况
			weahter: function() {
				var that = this;
				var timestamp;
				timestamp = new Date().getTime();
				that.timeTemp = timestamp
				setInterval(function() {
					timestamp = new Date().getTime();
					that.timeTemp = timestamp
				}, 1000)
				//获取天气心情
				uni.request({
					url: 'https://www.tianqiapi.com/api/', //仅为示例，并非真实接口地址。
					data: {
						version: 'v6',
						city: '运城',
						appid: '71254342',
						appsecret: 'aSe7JkVM'
					},
					success: (res) => {
						that.wethaer = res.data;
					}
				});
			},
			godetails: function(res) {
				try {
					uni.setStorageSync('sutype', res);
					uni.reLaunch({
						url: "../index/index?type=" + res + ""
					})
				} catch (e) {
					// error
				}
			}
		},
		filters: {
			timeFormat: function(arg, type = 'YYYY-MM-DD h:m:s') {
				if (arg.toString().length == 10) {
					arg = arg * 1000;
					//如果date为13位不需要乘1000
					//[js时间戳长度是13位]，php，java等时间戳长度为10位
				}
				var date = new Date(arg)
				var year = date.getFullYear(); //获取年
				var mouth = (date.getMonth() + 1 < 10 ? '0' + (date.getMonth() + 1) : date.getMonth() + 1); //月
				var day = (date.getDate() < 10 ? '0' + (date.getDate()) : date.getDate()); //日
				var hour = (date.getHours() < 10 ? '0' + date.getHours() : date.getHours()); //时
				var minute = (date.getMinutes() < 10 ? '0' + date.getMinutes() : date.getMinutes()); //分
				var second = (date.getSeconds() < 10 ? '0' + date.getSeconds() : date.getSeconds()); //秒
				var week; //星期
				if (date.getDay() == 0) week = "星期日"
				if (date.getDay() == 1) week = "星期一"
				if (date.getDay() == 2) week = "星期二"
				if (date.getDay() == 3) week = "星期三"
				if (date.getDay() == 4) week = "星期四"
				if (date.getDay() == 5) week = "星期五"
				if (date.getDay() == 6) week = "星期六"
				if (type == 'YYYY-MM-DD h:m:s') {
					return week + ' ' + hour + ':' + minute + ':' + second;
				}
				if (type == 'YYYY-MM-DD') {
					return year + '-' + mouth + '-' + day;
				}
				if (type == 'MM-DD') {
					return mouth + '-' + day;
				}
				if (type == 'MM-DD WEEK') {
					return mouth + '-' + day + ' ' + week;
				}
			}
		}
	}
</script>

<style>
	@import url("../../common/css/style.css");
	@import url("../../common/css/index.css");

	.indexborder {
		color: #fff;
		background: #0096d5;
	}

	.content {
		display: flex;
		flex-direction: column;
		align-items: center;
		justify-content: center;
	}

	.logo {
		height: 200rpx;
		width: 200rpx;
		margin-top: 200rpx;
		margin-left: auto;
		margin-right: auto;
		margin-bottom: 50rpx;
	}

	.text-area {
		display: flex;
		justify-content: center;
	}

	.title {
		font-size: 36rpx;
		color: #8f8f94;
	}

	.uni-title {
		font-size: 50px;
		text-align: center;
		height: 80px;
		line-height: 80px;
		font-weight: 600;
		color: #fff;
	}

	.titlelist {
		font-size: 35px;
		text-align: center;
		height: 50px;
		line-height: 50px;
		margin-top: 15px;
	}
</style>
