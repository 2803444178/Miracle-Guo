<template>
	<view class="wrap">
		<view class="goodsList" @touchstart="touchstart()">
			<view id="box" class="box">
				<view v-for="(item,index) in list" class="menuitem" :id="index" @tap="godetails">
					<view class="goodsimg">
						<image :src="item.product_mobile_icon" mode="aspectFit"></image>
					</view>
					<view class="goodsinfo">
						<view class="goodsp">
							检测样品：<text class="goodsb">{{item.product_name}}</text>
						</view>
						<view class="goodsp">
							检测结果：<text class="goodsb">{{item.detect_result == "QUA"? '合格':"不合格" }}</text>
						</view>
					</view>
					<image class="qua" :src=" item.detect_result == 'QUA'?  '../../static/QUA.png':'../../static/UNQUA.png'" mode="widthFix"></image>
				</view>
			</view>
		</view>
	</view>
</template>
<script>
	export default {
		name: 'Marquee',
		props: ['list'], // 父组件传入数据， 数组形式 [ "连雨不知春去"，"一晴方觉夏深"]
		data() {
			return {
				animationData: {},
				distance: '' //滑动的距离
			}
		},
		onLoad: function() {

		},
		methods: {
			move() {
				var _self = this;
				console.log(_self.list)
				let length = _self.list.length;
				let dur = 1000 * length;
				var animation = uni.createAnimation({
					duration: dur
				})

				uni.getSystemInfo({
					success: function(res) { // res - 各种参数
						console.log(res.windowWidth); // 屏幕的宽度 
						let info = uni.createSelectorQuery().select(".box");
						info.boundingClientRect(function(data) { //data - 各种参数
							console.log(data.height) // 获取元素宽度
							let height = data.height;
							_self.animation = animation
							animation.translateY(-1000).step();
							setInterval(function() {
								_self.animationData = animation.export()
							}, 1000)
						}).exec()
					}
				});

			},
			godetails: function(e) {
				let index = e.currentTarget.id;
				uni.navigateTo({
					url: "../details/details?&&index=" + index + ""
				})
			},
		},
		// 把父组件传入的arr转化成字符串
		mounted: function() {
			this.move()
		},
		// 更新的时候运动
		updated: function() {

		}
	}
</script>
<style scoped>
	.container {
		padding: 30px 100px;
		width: 100%;
		height: 845px;
		display: flex;

	}

	.contentleft {
		width: 1080px;
	}

	.contentright {
		width: 585px;
		margin-left: 50px;

		height: 100%;
		flex: 1;
	}


	.vaiel {
		width: 100%;
		flex: 1;
		height: 645px;
		margin-bottom: 25px;
		border-radius: 25px;
	}

	.vaiel image {
		width: 100%;
		height: 100%;
		display: block;
		border-radius: 25px;
	}

	.vaielbox {
		width: 100%;
		height: 106px;
		border: 4px solid #f7601b;
		font-size: 45px;
		text-align: center;
		line-height: 106px;
		color: #f7601b;
		border-radius: 25px;
	}


	.rightbox {
		width: 100%;
		margin: 0 auto;
		height: 100%;

	}

	h1 {
		font-size: 40px;
		text-align: center;
		color: #fff;
		background: #f7601b;
		width: 100%;
		display: flex;
		align-items: center;
		justify-content: center;
		margin: 0 auto;
		height: 100px;
		border-top-left-radius: 25px;
		border-top-right-radius: 25px;
		border: 4px solid #f7601b;

	}

	.goodsList {
		background: #fff;
		width: 100%;
		overflow: hidden;
		height: 667px;
		padding: 25px;
		border-bottom: 4px solid #f7601b;
		border-left: 4px solid #f7601b;
		border-right: 4px solid #f7601b;
		box-sizing: border-box;
	}


	.goodsList::-webkit-scrollbar {
		display: none;
	}

	.goodsList .menuitem {
		width: 500px;
		height: 140px;
		display: flex;
		margin: 0 auto;
		align-items: center;
		margin-bottom: 30px;
		padding: 20px 40px;
		box-shadow: 0px 0px 5px -1px #333;
		position: relative;
		box-sizing: border-box;
	}

	.goodsList .menuitem:last-child {
		margin-bottom: 0;
	}

	.goodsimg {
		width: 120px;
		height: 120px;
		border: 2px solid #f7601b;
		border-radius: 100%;
		display: flex;
		justify-content: center;
		align-items: center;
		margin-right: 35px;
	}

	.goodsimg image {
		width: 90%;
		height: 90%;
	}

	.qua {
		position: absolute;
		width: 100px;
		height: 100px;
		right: 0;
		bottom: 0;
	}

	.goodsinfo {
		flex: 1;
		width: 100%;
		height: 100%;
		font-size: 26px;
		display: flex;
		flex-wrap: wrap;
		align-content: space-around;
	}

	.goodsinfo .goodsp {
		width: 100%;
		color: #333;
		font-weight: 600;
	}

	.goodsinfo .goodsb {
		color: #595757;
		font-weight: normal;
	}

	.goods {
		font-size: 48px;
		font-weight: 600;

	}

	.pirce {
		font-size: 32px;
		font-weight: 600;
		color: red;
		text-align: right;
	}

	.erweima {
		width: 150px;
		height: 150px;
	}

	.erweima image {
		width: 100%;
		height: 100%;
		display: block;
	}

	.marquee_top {
		transition: all 1.5s;
		margin-top: -170px
	}

	.marqueetop {
		transition: all 1.5s;
		margin-top: -340px
	}


	.showitem {
		font-size: 36px;
		color: #fff;
		text-align: center;
		padding: 15px;
	}

	.showitemactive {
		background: #2C405A;
		color: #fff;
	}

	.adressbox {
		overflow: scroll;
	}
</style>
